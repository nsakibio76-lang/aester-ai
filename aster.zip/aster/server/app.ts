// Wires config → database → services → HTTP server. Used by index.ts and by tests (which pass a fake provider/config).

import http from "node:http";
import type { AddressInfo } from "node:net";
import type { Config } from "./config.ts";
import { openDb } from "./db.ts";
import type { Db } from "./db.ts";
import { AppError } from "./errors.ts";
import * as log from "./log.ts";
import { createChatService } from "./chat/service.ts";
import { createMemoryService } from "./memory/service.ts";
import { createProvider } from "./providers/index.ts";
import type { AIProvider } from "./providers/types.ts";
import { createConversationRepo } from "./repo/conversations.ts";
import { createMemoryRepo } from "./repo/memories.ts";
import { createAttachmentRepo, createMessageRepo } from "./repo/messages.ts";
import { createSettingsRepo } from "./repo/settings.ts";
import { createAuth } from "./http/auth.ts";
import { buildRouter } from "./http/routes.ts";
import { applySecurityHeaders, assertHostAllowed, assertSameOrigin } from "./http/security.ts";
import { serveStatic } from "./http/static.ts";
import { sendError, sendJson } from "./http/util.ts";

export interface App {
  server: http.Server;
  db: Db;
  config: Config;
  listen(): Promise<{ host: string; port: number; url: string }>;
  close(): Promise<void>;
}

export function createApp(config: Config, overrides: { provider?: AIProvider } = {}): App {
  const db = openDb(config.dbPath);
  const conversations = createConversationRepo(db);
  const messages = createMessageRepo(db);
  const attachments = createAttachmentRepo(db);
  const memoryRepo = createMemoryRepo(db);
  const settings = createSettingsRepo(db);
  const memory = createMemoryService(memoryRepo, { maxMemories: config.maxMemories });
  const provider = overrides.provider ?? createProvider(config);
  const auth = createAuth(config, db);
  const chat = createChatService({ config, db, provider, conversations, messages, attachments, settings, memory });
  const router = buildRouter({ config, db, auth, provider, conversations, messages, attachments, memoryRepo, memory, settings, chat });

  const recovered = messages.recoverStreaming();
  if (recovered) log.info(`recovered ${recovered} interrupted repl${recovered === 1 ? "y" : "ies"}`);
  const purgeUploads = () => attachments.purgeUnattachedBefore(new Date(Date.now() - 24 * 3600 * 1000).toISOString());
  purgeUploads();
  const purgeTimer = setInterval(purgeUploads, 3600 * 1000);
  purgeTimer.unref();

  const server = http.createServer(async (req, res) => {
    const started = Date.now();
    let routeLabel = "static";
    try {
      applySecurityHeaders(res, config);
      assertHostAllowed(req, config);
      const url = new URL(req.url ?? "/", "http://localhost");
      const method = req.method ?? "GET";

      if (url.pathname === "/api" || url.pathname.startsWith("/api/")) {
        routeLabel = "api";
        const m = router.match(method, url.pathname);
        if (!m) throw new AppError("not_found", "Unknown API endpoint.");
        if ("allow" in m) { res.setHeader("allow", m.allow.join(", ")); throw new AppError("invalid_request", "Method not allowed.", { status: 405 }); }
        assertSameOrigin(req);
        if (!m.route.isPublic && !auth.isAuthenticated(req)) throw new AppError("unauthenticated", "Please sign in.", { status: 401 });
        await m.route.handler({ req, res, url, params: m.params });
        return;
      }
      // Static UI. When a password is set the shell itself is public (it only renders the login form); all data is behind /api.
      const served = await serveStatic(req, res, config.publicDir, url.pathname);
      if (!served) { res.writeHead(405, { allow: "GET, HEAD" }); res.end(); }
    } catch (e) {
      sendError(res, e);
    } finally {
      if (!res.writableEnded && !res.headersSent) { /* handled by sendError */ }
      res.once("close", () => log.info(`${req.method} ${routeLabel === "api" ? (req.url ?? "").split("?")[0]!.replace(/\/[A-Za-z0-9_-]{12}(?=\/|$)/g, "/:id") : "(static)"} ${res.statusCode} ${Date.now() - started}ms`));
    }
  });
  server.requestTimeout = 0; // streaming responses & large uploads; header/idle timeouts still apply
  server.headersTimeout = 30_000;
  server.keepAliveTimeout = 10_000;
  server.on("clientError", (_err, socket) => { if (socket.writable) socket.end("HTTP/1.1 400 Bad Request\r\n\r\n"); });

  return {
    server, db, config,
    listen: () => new Promise((resolve, reject) => {
      server.once("error", reject);
      server.listen(config.port, config.host, () => {
        const a = server.address() as AddressInfo;
        const host = a.family === "IPv6" ? `[${a.address}]` : a.address;
        resolve({ host: a.address, port: a.port, url: `http://${host}:${a.port}` });
      });
    }),
    close: () => new Promise((resolve) => {
      clearInterval(purgeTimer);
      server.closeAllConnections();
      server.close(() => { try { db.close(); } catch { /* already closed */ } resolve(); });
    }),
  };
}

export { sendJson };
