// Chat orchestration: one "turn" = (optionally store the user message) → build context → stream the model,
// running tools in a loop → persist the assistant message → (first exchange) generate a title.
//
// prepare() does all validation and DB mutation synchronously and may throw an AppError (the HTTP layer turns that
// into a normal JSON error). run() then streams events and never throws.

import type { Config } from "../config.ts";
import type { Db } from "../db.ts";
import { tx } from "../db.ts";
import { AppError, notFound, validation } from "../errors.ts";
import * as log from "../log.ts";
import type { AIProvider, ProviderMessage, ProviderRequest, ContentBlock, Usage } from "../providers/types.ts";
import { completeText } from "../providers/types.ts";
import type { ConversationRepo } from "../repo/conversations.ts";
import type { AttachmentRepo, MessageRepo } from "../repo/messages.ts";
import type { SettingsRepo } from "../repo/settings.ts";
import type { Conversation, Message, Mode, ToolEvent } from "../repo/types.ts";
import { MODES } from "../repo/types.ts";
import type { MemoryService } from "../memory/service.ts";
import { runTool, toolDefs } from "../tools/index.ts";
import type { ToolContext } from "../tools/index.ts";
import { estimateTokens, sleep, truncate } from "../util.ts";
import { buildContext } from "./context.ts";
import { buildDynamicPrompt, STATIC_PROMPT } from "./prompt.ts";

export type Emit = (event: string, data: unknown) => void;

export interface ChatRequest {
  action: "send" | "regenerate" | "edit";
  conversationId: string | null;
  message: string;
  attachmentIds: string[];
  messageId: string | null;
  mode: Mode | null;
  memoryEnabled: boolean | null;
  model: string | null;
  tz: string | null;
}

export interface ChatDeps {
  config: Config;
  db: Db;
  provider: AIProvider;
  conversations: ConversationRepo;
  messages: MessageRepo;
  attachments: AttachmentRepo;
  settings: SettingsRepo;
  memory: MemoryService;
}

export interface Turn {
  conversation: Conversation;
  userMessage: Message | null;
  assistantMessage: Message;
  run(emit: Emit, signal: AbortSignal): Promise<void>;
}

const MAX_TOOL_ROUNDS = 6;
const MODEL_RE = /^[A-Za-z0-9._:\-/]{1,100}$/;

export function parseChatRequest(body: unknown, cfg: Config): ChatRequest {
  if (typeof body !== "object" || body === null || Array.isArray(body)) throw validation("Request body must be a JSON object.");
  const b = body as Record<string, unknown>;
  const action = b.action === undefined ? "send" : b.action;
  if (action !== "send" && action !== "regenerate" && action !== "edit") throw validation("Unknown action.");
  const optStr = (k: string, max: number): string | null => {
    const v = b[k];
    if (v === undefined || v === null) return null;
    if (typeof v !== "string" || v.length > max) throw validation(`Invalid ${k}.`);
    return v;
  };
  const conversationId = optStr("conversationId", 64);
  const messageId = optStr("messageId", 64);
  const message = typeof b.message === "string" ? b.message : b.message === undefined || b.message === null ? "" : (() => { throw validation("message must be text."); })();
  if (message.length > cfg.maxMessageChars) throw validation(`Message is too long (max ${cfg.maxMessageChars} characters).`);
  let attachmentIds: string[] = [];
  if (b.attachmentIds !== undefined && b.attachmentIds !== null) {
    if (!Array.isArray(b.attachmentIds) || b.attachmentIds.some((x) => typeof x !== "string" || x.length > 64)) throw validation("Invalid attachmentIds.");
    attachmentIds = [...new Set(b.attachmentIds as string[])];
    if (attachmentIds.length > cfg.maxAttachments) throw validation(`You can attach at most ${cfg.maxAttachments} files per message.`);
  }
  let mode: Mode | null = null;
  if (b.mode !== undefined && b.mode !== null) {
    if (!MODES.includes(b.mode as Mode)) throw validation("Invalid mode.");
    mode = b.mode as Mode;
  }
  let memoryEnabled: boolean | null = null;
  if (b.memoryEnabled !== undefined && b.memoryEnabled !== null) {
    if (typeof b.memoryEnabled !== "boolean") throw validation("memoryEnabled must be true or false.");
    memoryEnabled = b.memoryEnabled;
  }
  const model = optStr("model", 100);
  if (model && !MODEL_RE.test(model)) throw validation("Invalid model id.");
  const tz = optStr("tz", 64);
  if (action === "send" && !message.trim() && attachmentIds.length === 0) throw validation("Message can't be empty.");
  if (action === "edit" && !message.trim()) throw validation("Edited message can't be empty.");
  if ((action === "edit" || action === "regenerate") && !messageId) throw validation("messageId is required.");
  if ((action === "edit" || action === "regenerate") && !conversationId) throw validation("conversationId is required.");
  return { action, conversationId, message, attachmentIds, messageId, mode, memoryEnabled, model, tz };
}

function fallbackTitle(text: string, hasAttachment: boolean): string {
  const t = text.replace(/\$+/g, "").replace(/[#*_`>]/g, "").replace(/\s+/g, " ").trim();
  if (!t) return hasAttachment ? "Question from an attachment" : "New conversation";
  const words = t.split(" ").slice(0, 7).join(" ");
  return truncate(words, 50);
}

function cleanTitle(raw: string): string {
  const line = raw.split("\n").map((s) => s.trim()).find(Boolean) ?? "";
  return truncate(line.replace(/^(title:\s*)/i, "").replace(/^["'“”‘’`*#\s]+|["'“”‘’`*.\s]+$/g, ""), 60);
}

export function createChatService(deps: ChatDeps) {
  const { config, db, provider, conversations, messages, attachments, settings, memory } = deps;
  const active = new Set<string>();

  function prepare(req: ChatRequest): Turn {
    const s = settings.get();
    const model = req.model || s.model || config.defaultModel;
    let conv!: Conversation;
    let userMessage: Message | null = null;
    let assistant!: Message;

    if (req.conversationId && !conversations.get(req.conversationId)) throw notFound("Conversation");
    if (req.conversationId && active.has(req.conversationId))
      throw new AppError("invalid_request", "Aster is still answering in this conversation. Stop it or wait for it to finish.", { status: 409 });

    tx(db, () => {
      if (req.action === "send") {
        conv = req.conversationId
          ? conversations.require(req.conversationId)
          : conversations.create({ mode: req.mode ?? "auto", memoryEnabled: req.memoryEnabled ?? true });
        for (const id of req.attachmentIds) {
          if (!attachments.meta(id)) throw validation("An attachment is missing or expired. Upload it again.");
          if (!attachments.isUnattached(id)) throw validation("An attachment was already used in another message.");
        }
        if (req.conversationId && req.mode && req.mode !== conv.mode) conv = conversations.update(conv.id, { mode: req.mode });
        userMessage = messages.insert({ conversationId: conv.id, role: "user", content: req.message.trim() });
        attachments.attach(req.attachmentIds, userMessage.id);
        userMessage = messages.get(userMessage.id)!;
      } else {
        conv = conversations.require(req.conversationId!);
        if (req.mode && req.mode !== conv.mode) conv = conversations.update(conv.id, { mode: req.mode });
        const target = messages.get(req.messageId!);
        if (!target || messages.conversationOf(target.id) !== conv.id) throw notFound("Message");
        const seq = messages.seqOf(target.id)!;
        if (req.action === "edit") {
          if (target.role !== "user") throw validation("Only your own messages can be edited.");
          messages.deleteFromSeq(conv.id, seq + 1);
          messages.update(target.id, { content: req.message.trim() });
          userMessage = messages.get(target.id)!;
        } else {
          if (target.role !== "assistant") throw validation("Only assistant replies can be regenerated.");
          messages.deleteFromSeq(conv.id, seq);
          const hasUser = messages.list(conv.id).some((m) => m.role === "user");
          if (!hasUser) throw validation("There is no message to answer.");
        }
      }
      assistant = messages.insert({ conversationId: conv.id, role: "assistant", content: "", status: "streaming", model });
      conversations.touch(conv.id);
      conv = conversations.get(conv.id)!;
    });

    active.add(conv.id);
    const convId = conv.id;
    return {
      conversation: conv,
      userMessage,
      assistantMessage: assistant,
      run: (emit, signal) => runTurn({ convId, assistantId: assistant.id, model, tz: req.tz, userMessage }, emit, signal)
        .finally(() => active.delete(convId)),
    };
  }

  async function runTurn(
    t: { convId: string; assistantId: string; model: string; tz: string | null; userMessage: Message | null },
    emit: Emit, signal: AbortSignal,
  ): Promise<void> {
    let conv = conversations.require(t.convId);
    const assistantBase = messages.get(t.assistantId)!;
    const s = settings.get();
    emit("start", { conversation: conv, userMessage: t.userMessage, assistantMessage: assistantBase });

    let text = "";
    const toolEvents: ToolEvent[] = [];
    const usage: Usage = { inputTokens: 0, outputTokens: 0 };
    let stopReason: string | null = null;
    let failure: AppError | null = null;
    let lastFlush = Date.now();
    const flush = (force = false) => {
      if (force || Date.now() - lastFlush > 1500) { messages.update(t.assistantId, { content: text }); lastFlush = Date.now(); }
    };

    try {
      if (!provider.isConfigured())
        throw new AppError("not_configured", "No Anthropic API key is configured on the server. Set ANTHROPIC_API_KEY in .env and restart Aster.", { status: 503 });

      const history = messages.list(t.convId).filter((m) => m.id !== t.assistantId);
      const lastUser = [...history].reverse().find((m) => m.role === "user");
      const memories = conv.memoryEnabled ? memory.retrieve(lastUser?.content ?? "") : [];
      const dynamic = buildDynamicPrompt({ now: new Date(), tz: t.tz ?? undefined, settings: s, mode: conv.mode, memoryEnabled: conv.memoryEnabled, memories, trimmedCount: 0 });
      const reserve = estimateTokens(STATIC_PROMPT.length + dynamic.length) + config.maxOutputTokens + 3000;
      const built = buildContext(history, attachments, { budget: Math.max(2000, config.maxContextTokens - reserve), maxTextBytes: config.maxTextBytes });
      const system = [
        { text: STATIC_PROMPT, cache: true },
        { text: built.trimmed > 0 ? buildDynamicPrompt({ now: new Date(), tz: t.tz ?? undefined, settings: s, mode: conv.mode, memoryEnabled: conv.memoryEnabled, memories, trimmedCount: built.trimmed }) : dynamic },
      ];
      const msgs: ProviderMessage[] = built.messages;
      if (!msgs.length) throw validation("There is nothing to send to the model.");

      const toolCtx: ToolContext = {
        conversationId: t.convId, memoryEnabled: conv.memoryEnabled, autoMemory: s.autoMemory, memory, conversations,
        onMemory: (action, m) => emit("memory", { action, memory: m }),
        onConversation: (c) => { conv = c; emit("conversation", { conversation: c }); },
      };

      for (let round = 0; round < MAX_TOOL_ROUNDS; round++) {
        const req: ProviderRequest = { model: t.model, system, messages: msgs, tools: toolDefs(toolCtx.memoryEnabled), maxTokens: config.maxOutputTokens };
        let roundText = "";
        let toolUses: { id: string; name: string; input: Record<string, unknown> }[] = [];
        let endReason = "end_turn";
        for (let attempt = 0; ; attempt++) {
          let started = false;
          roundText = ""; toolUses = [];
          try {
            for await (const ev of provider.stream(req, signal)) {
              if (ev.type === "text") {
                started = true;
                if (roundText === "" && round > 0 && text && !text.endsWith("\n")) { text += "\n\n"; emit("delta", { text: "\n\n" }); }
                roundText += ev.text; text += ev.text;
                emit("delta", { text: ev.text });
                flush();
              } else if (ev.type === "tool_use") {
                started = true;
                toolUses.push({ id: ev.id, name: ev.name, input: ev.input });
              } else {
                endReason = ev.stopReason;
                usage.inputTokens += ev.usage.inputTokens;
                usage.outputTokens += ev.usage.outputTokens;
              }
            }
            break;
          } catch (e) {
            if (e instanceof AppError && e.retryable && !started && attempt < config.maxRetries && !signal.aborted) {
              const wait = e.retryAfterMs ?? config.retryBaseMs * 2 ** attempt + Math.floor(Math.random() * 250);
              emit("status", { kind: "retry", message: `${e.message} Retrying (${attempt + 1}/${config.maxRetries})…`, retryInMs: wait });
              await sleep(wait, signal);
              continue;
            }
            throw e;
          }
        }
        stopReason = endReason;
        if (endReason === "refusal") throw new AppError("refusal", "The model declined to answer this request. Try rephrasing it.", { status: 200 });
        if (endReason !== "tool_use" || toolUses.length === 0) break;

        const assistantBlocks: ContentBlock[] = [];
        if (roundText) assistantBlocks.push({ type: "text", text: roundText });
        for (const u of toolUses) assistantBlocks.push({ type: "tool_use", id: u.id, name: u.name, input: u.input });
        msgs.push({ role: "assistant", content: assistantBlocks });
        const results: ContentBlock[] = [];
        for (const u of toolUses) {
          emit("tool", { id: u.id, name: u.name, phase: "start" });
          const out = runTool(u.name, u.input, toolCtx);
          const ev: ToolEvent = { id: u.id, name: u.name, summary: out.summary, ok: !out.isError };
          toolEvents.push(ev);
          emit("tool", { id: u.id, name: u.name, phase: "result", summary: out.summary, ok: !out.isError });
          results.push({ type: "tool_result", toolUseId: u.id, content: out.content, isError: out.isError });
        }
        msgs.push({ role: "user", content: results });
        if (round === MAX_TOOL_ROUNDS - 1) stopReason = "tool_loop_limit";
      }
    } catch (e) {
      if (signal.aborted) failure = new AppError("aborted", "Generation stopped.", { status: 499 });
      else if (e instanceof AppError) failure = e;
      else { log.error("unexpected chat failure", e); failure = new AppError("server", "Something went wrong on the server while generating the reply.", { status: 500 }); }
    }

    const aborted = signal.aborted || failure?.code === "aborted";
    const status = aborted ? "stopped" : failure ? "error" : "complete";
    messages.update(t.assistantId, {
      content: text, status, model: t.model, stopReason, toolEvents,
      usage: usage.inputTokens || usage.outputTokens ? usage : null,
      error: status === "error" && failure ? { code: failure.code, message: failure.message } : null,
    });
    conversations.touch(t.convId);

    if (status === "error" && failure) emit("error", { code: failure.code, message: failure.message, retryable: failure.retryable || ["rate_limit", "overloaded", "network", "timeout", "server"].includes(failure.code) });
    else if (status === "complete") emit("done", { assistantMessage: messages.get(t.assistantId), stopReason });

    // Title: AI-generated after the first successful exchange, otherwise a quick fallback so the sidebar isn't blank.
    try {
      conv = conversations.get(t.convId) ?? conv;
      if (conv.titleSource === "default") {
        const firstUser = messages.list(t.convId).find((m) => m.role === "user");
        const hasAtt = (firstUser?.attachments.length ?? 0) > 0;
        let title = fallbackTitle(firstUser?.content ?? "", hasAtt);
        let source: "auto" | "default" = "default";
        if (status === "complete" && !signal.aborted && provider.isConfigured() && firstUser) {
          const ai = await generateTitle(firstUser.content || "(image or file attachment)", text, signal);
          if (ai) { title = ai; source = "auto"; }
        }
        if (title && title !== conv.title) {
          conv = conversations.update(t.convId, { title, titleSource: source });
          emit("title", { conversationId: t.convId, title });
        }
      }
    } catch (e) {
      if (!signal.aborted) log.warn("title generation skipped");
      void e;
    }
  }

  async function generateTitle(userText: string, assistantText: string, signal: AbortSignal): Promise<string | null> {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 20000);
    try {
      const { text } = await completeText(provider, {
        model: config.titleModel,
        system: [{ text: "You write short conversation titles. Reply with ONLY a title of 2 to 6 words that captures the topic. No quotes, no trailing punctuation, no markdown. Use the same language as the user." }],
        messages: [{ role: "user", content: [{ type: "text", text: `User: ${truncate(userText, 600)}\n\nAssistant: ${truncate(assistantText, 600)}\n\nTitle:` }] }],
        maxTokens: 30,
      }, AbortSignal.any([signal, ctl.signal]));
      const t = cleanTitle(text);
      return t || null;
    } catch {
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  return { prepare, isActive: (id: string) => active.has(id), activeCount: () => active.size };
}
export type ChatService = ReturnType<typeof createChatService>;
