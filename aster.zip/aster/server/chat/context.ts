// Converts stored messages (+attachments) into provider messages, and trims history to fit the context budget.

import type { Message } from "../repo/types.ts";
import type { AttachmentRepo } from "../repo/messages.ts";
import type { ContentBlock, ProviderMessage } from "../providers/types.ts";
import { estimateTokens } from "../util.ts";

const IMAGE_TOKENS = 1600;

export interface BuiltContext { messages: ProviderMessage[]; trimmed: number; estimatedTokens: number }

function userBlocks(m: Message, attachments: AttachmentRepo, maxTextBytes: number): ContentBlock[] {
  const blocks: ContentBlock[] = [];
  for (const a of attachments.forMessageWithData(m.id)) {
    const buf = Buffer.from(a.data);
    if (a.kind === "image") blocks.push({ type: "image", mediaType: a.mime, data: buf.toString("base64") });
    else if (a.kind === "pdf") blocks.push({ type: "document", mediaType: "application/pdf", data: buf.toString("base64"), title: a.name });
    else {
      let text = new TextDecoder("utf-8").decode(buf.subarray(0, maxTextBytes));
      if (buf.byteLength > maxTextBytes) text += "\n…[file truncated]";
      blocks.push({ type: "text", text: `<attached_file name=${JSON.stringify(a.name)}>\n${text}\n</attached_file>` });
    }
  }
  if (m.content.trim()) blocks.push({ type: "text", text: m.content });
  return blocks;
}

function blockTokens(b: ContentBlock): number {
  switch (b.type) {
    case "text": return estimateTokens(b.text.length);
    case "image": return IMAGE_TOKENS;
    case "document": return Math.min(60000, Math.ceil((b.data.length * 0.75) / 120));
    case "tool_use": return estimateTokens(JSON.stringify(b.input).length) + 20;
    case "tool_result": return estimateTokens(b.content.length) + 10;
  }
}

/**
 * @param history  messages in order, EXCLUDING the in-progress assistant message
 * @param budget   max estimated input tokens for history (system prompt/tools reserved by caller)
 */
export function buildContext(history: Message[], attachments: AttachmentRepo, opts: { budget: number; maxTextBytes: number }): BuiltContext {
  const raw: ProviderMessage[] = [];
  for (const m of history) {
    if (m.role === "assistant") {
      // Keep partial text from stopped replies; skip empty/errored-without-text ones.
      if (!m.content.trim()) continue;
      raw.push({ role: "assistant", content: [{ type: "text", text: m.content }] });
    } else {
      const blocks = userBlocks(m, attachments, opts.maxTextBytes);
      if (!blocks.length) continue;
      raw.push({ role: "user", content: blocks });
    }
  }
  // Merge consecutive same-role messages (e.g. after a failed turn) so roles alternate.
  const merged: ProviderMessage[] = [];
  for (const m of raw) {
    const last = merged[merged.length - 1];
    if (last && last.role === m.role) last.content = [...last.content, ...m.content];
    else merged.push({ role: m.role, content: [...m.content] });
  }
  // The API needs the first message to be from the user.
  while (merged.length && merged[0]!.role !== "user") merged.shift();

  const cost = (m: ProviderMessage) => m.content.reduce((s, b) => s + blockTokens(b), 0);
  let total = merged.reduce((s, m) => s + cost(m), 0);
  let trimmed = 0;
  // Drop oldest messages (always keeping the final user message) until under budget; stay user-first.
  while (total > opts.budget && merged.length > 1) {
    total -= cost(merged.shift()!);
    trimmed++;
    while (merged.length > 1 && merged[0]!.role !== "user") { total -= cost(merged.shift()!); trimmed++; }
  }
  return { messages: merged, trimmed, estimatedTokens: total };
}
