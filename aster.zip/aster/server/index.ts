// Aster server entry point:  node server/index.ts   (Node >= 22.18 runs TypeScript natively)

import fs from "node:fs";
import { createApp } from "./app.ts";
import { loadConfig } from "./config.ts";
import * as log from "./log.ts";

if (fs.existsSync(".env")) {
  try { process.loadEnvFile(".env"); } catch (e) { log.error("could not read .env", e); process.exit(1); }
}

let config;
try {
  config = loadConfig();
} catch (e) {
  console.error(`\nConfiguration error: ${(e as Error).message}\n`);
  process.exit(1);
}

const app = createApp(config);
try {
  const { url } = await app.listen();
  log.info(`Aster ${config.version} listening on ${url}`);
  log.info(`provider=${config.provider} model=${config.defaultModel} apiKey=${config.apiKey ? "configured" : "MISSING (set ANTHROPIC_API_KEY)"} password=${config.password ? "on" : "off"}`);
  log.info(`data: ${config.dbPath}`);
} catch (e) {
  const err = e as NodeJS.ErrnoException;
  console.error(err.code === "EADDRINUSE" ? `\nPort ${config.port} is already in use. Set ASTER_PORT to another port.\n` : `\nCould not start the server: ${err.message}\n`);
  process.exit(1);
}

let stopping = false;
const stop = async (sig: string) => {
  if (stopping) return;
  stopping = true;
  log.info(`${sig} received, shutting down`);
  await app.close();
  process.exit(0);
};
process.on("SIGINT", () => void stop("SIGINT"));
process.on("SIGTERM", () => void stop("SIGTERM"));
process.on("unhandledRejection", (e) => log.error("unhandled rejection", e));
