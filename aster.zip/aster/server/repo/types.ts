// Public data shapes (mirror docs/API.md).

export type Mode = "auto" | "math" | "study";
export type TitleSource = "default" | "auto" | "user";
export type MessageStatus = "complete" | "streaming" | "stopped" | "error";
export type MemorySource = "auto" | "explicit" | "manual";

export const MODES: Mode[] = ["auto", "math", "study"];
export const CATEGORIES = [
  "personal", "preferences", "education", "learning_goals", "interests",
  "ambitions", "projects", "context", "communication",
] as const;
export type Category = (typeof CATEGORIES)[number];

export interface Conversation {
  id: string; title: string; titleSource: TitleSource; mode: Mode;
  memoryEnabled: boolean; archived: boolean; createdAt: string; updatedAt: string;
  snippet?: string;
}
export interface Attachment { id: string; name: string; kind: "image" | "pdf" | "text"; mime: string; size: number; url: string }
export interface ToolEvent { id: string; name: string; summary: string; ok: boolean }
export interface Message {
  id: string; role: "user" | "assistant"; content: string; status: MessageStatus;
  error: { code: string; message: string } | null; model: string | null; stopReason: string | null;
  createdAt: string; attachments: Attachment[]; toolEvents: ToolEvent[];
  usage: { inputTokens: number; outputTokens: number } | null;
}
export interface Memory {
  id: string; category: Category; content: string; source: MemorySource;
  createdAt: string; updatedAt: string; lastUsedAt: string | null; conversationId: string | null;
}
export interface Settings {
  theme: "system" | "light" | "dark"; autoMemory: boolean; model: string | null;
  responseStyle: "concise" | "balanced" | "detailed";
  explainLevel: "auto" | "beginner" | "intermediate" | "advanced";
  language: string; customInstructions: string;
}
