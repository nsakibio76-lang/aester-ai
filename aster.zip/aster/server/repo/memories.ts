import type { Db } from "../db.ts";
import type { Category, Memory, MemorySource } from "./types.ts";
import { newId, nowIso } from "../util.ts";

type Row = {
  id: string; category: string; content: string; source: string; created_at: string; updated_at: string;
  last_used_at: string | null; conversation_id: string | null;
};
const toMemory = (r: Row): Memory => ({
  id: r.id, category: r.category as Category, content: r.content, source: r.source as MemorySource,
  createdAt: r.created_at, updatedAt: r.updated_at, lastUsedAt: r.last_used_at, conversationId: r.conversation_id,
});

export function createMemoryRepo(db: Db) {
  return {
    list(opts: { q?: string; category?: string } = {}): Memory[] {
      const where: string[] = [], vals: string[] = [];
      if (opts.category) { where.push("category=?"); vals.push(opts.category); }
      if (opts.q && opts.q.trim()) {
        where.push("content LIKE ? ESCAPE '\\'");
        vals.push(`%${opts.q.trim().replace(/[\\%_]/g, (m) => "\\" + m)}%`);
      }
      const sql = `SELECT * FROM memories ${where.length ? "WHERE " + where.join(" AND ") : ""} ORDER BY updated_at DESC, rowid DESC`;
      return (db.prepare(sql).all(...vals) as Row[]).map(toMemory);
    },
    get(id: string): Memory | null {
      const r = db.prepare("SELECT * FROM memories WHERE id=?").get(id) as Row | undefined;
      return r ? toMemory(r) : null;
    },
    create(m: { category: Category; content: string; source: MemorySource; conversationId?: string | null }): Memory {
      const id = newId(), now = nowIso();
      db.prepare(
        "INSERT INTO memories (id,category,content,source,created_at,updated_at,last_used_at,conversation_id) VALUES (?,?,?,?,?,?,NULL,?)",
      ).run(id, m.category, m.content, m.source, now, now, m.conversationId ?? null);
      return this.get(id)!;
    },
    update(id: string, p: { content?: string; category?: Category }): Memory | null {
      const sets: string[] = ["updated_at=?"], vals: string[] = [nowIso()];
      if (p.content !== undefined) { sets.push("content=?"); vals.push(p.content); }
      if (p.category !== undefined) { sets.push("category=?"); vals.push(p.category); }
      const ch = db.prepare(`UPDATE memories SET ${sets.join(",")} WHERE id=?`).run(...vals, id).changes;
      return ch ? this.get(id) : null;
    },
    delete(id: string): boolean {
      return db.prepare("DELETE FROM memories WHERE id=?").run(id).changes > 0;
    },
    deleteAll(): number {
      return Number(db.prepare("DELETE FROM memories").run().changes);
    },
    touch(ids: string[]): void {
      const st = db.prepare("UPDATE memories SET last_used_at=? WHERE id=?");
      const now = nowIso();
      for (const id of ids) st.run(now, id);
    },
    count(): number {
      return (db.prepare("SELECT COUNT(*) AS n FROM memories").get() as { n: number }).n;
    },
  };
}
export type MemoryRepo = ReturnType<typeof createMemoryRepo>;
