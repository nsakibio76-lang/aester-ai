import type { Db } from "../db.ts";
import type { Settings } from "./types.ts";
import { validation } from "../errors.ts";
import { safeJson } from "../util.ts";

export const DEFAULT_SETTINGS: Settings = {
  theme: "system", autoMemory: true, model: null, responseStyle: "balanced",
  explainLevel: "auto", language: "", customInstructions: "",
};

const ENUMS: Record<string, readonly string[]> = {
  theme: ["system", "light", "dark"],
  responseStyle: ["concise", "balanced", "detailed"],
  explainLevel: ["auto", "beginner", "intermediate", "advanced"],
};

/** Validate a partial Settings object; throws a 422 `validation` AppError on bad input. */
export function validateSettingsPatch(input: unknown): Partial<Settings> {
  if (typeof input !== "object" || input === null || Array.isArray(input)) throw validation("Settings must be a JSON object.");
  const o = input as Record<string, unknown>;
  const out: Partial<Settings> = {};
  for (const [k, v] of Object.entries(o)) {
    switch (k) {
      case "theme": case "responseStyle": case "explainLevel":
        if (typeof v !== "string" || !ENUMS[k]!.includes(v)) throw validation(`Invalid value for ${k}.`);
        (out as Record<string, unknown>)[k] = v; break;
      case "autoMemory":
        if (typeof v !== "boolean") throw validation("autoMemory must be true or false.");
        out.autoMemory = v; break;
      case "model":
        if (v === null || v === "") { out.model = null; break; }
        if (typeof v !== "string" || !/^[A-Za-z0-9._:\-/]{1,100}$/.test(v)) throw validation("Invalid model id.");
        out.model = v; break;
      case "language":
        if (typeof v !== "string" || v.length > 60 || /[\u0000-\u001f]/.test(v)) throw validation("Invalid language.");
        out.language = v.trim(); break;
      case "customInstructions":
        if (typeof v !== "string" || v.length > 2000) throw validation("Custom instructions must be at most 2000 characters.");
        out.customInstructions = v; break;
      default:
        throw validation(`Unknown setting "${k}".`);
    }
  }
  return out;
}

export function createSettingsRepo(db: Db) {
  return {
    get(): Settings {
      const rows = db.prepare("SELECT key,value FROM settings").all() as { key: string; value: string }[];
      const s: Settings = { ...DEFAULT_SETTINGS };
      for (const r of rows) {
        if (r.key in DEFAULT_SETTINGS) (s as unknown as Record<string, unknown>)[r.key] = safeJson(r.value, (DEFAULT_SETTINGS as unknown as Record<string, unknown>)[r.key]);
      }
      return s;
    },
    update(patch: Partial<Settings>): Settings {
      const st = db.prepare("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
      for (const [k, v] of Object.entries(patch)) st.run(k, JSON.stringify(v));
      return this.get();
    },
    reset(): void {
      db.prepare("DELETE FROM settings").run();
    },
  };
}
export type SettingsRepo = ReturnType<typeof createSettingsRepo>;
