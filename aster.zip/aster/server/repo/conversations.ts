import type { Db } from "../db.ts";
import type { Conversation, Mode, TitleSource } from "./types.ts";
import { escapeHtml, newId, nowIso } from "../util.ts";
import { notFound } from "../errors.ts";

type Row = {
  id: string; title: string; title_source: string; mode: string; memory_enabled: number;
  archived: number; created_at: string; updated_at: string;
};

const toConv = (r: Row): Conversation => ({
  id: r.id, title: r.title, titleSource: r.title_source as TitleSource, mode: r.mode as Mode,
  memoryEnabled: r.memory_enabled === 1, archived: r.archived === 1,
  createdAt: r.created_at, updatedAt: r.updated_at,
});

/** Turn user input into a safe FTS5 query: every word quoted, prefix-matched, AND-ed. */
export function ftsQuery(q: string): string | null {
  const words = q.toLowerCase().match(/[\p{L}\p{N}]+/gu)?.slice(0, 8) ?? [];
  if (!words.length) return null;
  return words.map((w) => `"${w}"*`).join(" ");
}

const OPEN = "\u0001", CLOSE = "\u0002";
function markSnippet(s: string): string {
  return escapeHtml(s).split(OPEN).join("<mark>").split(CLOSE).join("</mark>");
}

export function createConversationRepo(db: Db) {
  return {
    create(input: { title?: string; mode?: Mode; memoryEnabled?: boolean } = {}): Conversation {
      const id = newId(), now = nowIso();
      db.prepare(
        `INSERT INTO conversations (id,title,title_source,mode,memory_enabled,archived,created_at,updated_at)
         VALUES (?,?,?,?,?,0,?,?)`,
      ).run(id, input.title?.trim() || "New conversation", input.title?.trim() ? "user" : "default",
        input.mode ?? "auto", input.memoryEnabled === false ? 0 : 1, now, now);
      return this.get(id)!;
    },
    get(id: string): Conversation | null {
      const r = db.prepare("SELECT * FROM conversations WHERE id=?").get(id) as Row | undefined;
      return r ? toConv(r) : null;
    },
    require(id: string): Conversation {
      const c = this.get(id);
      if (!c) throw notFound("Conversation");
      return c;
    },
    update(id: string, patch: Partial<{ title: string; titleSource: TitleSource; archived: boolean; memoryEnabled: boolean; mode: Mode }>, touch = false): Conversation {
      this.require(id);
      const sets: string[] = [], vals: (string | number)[] = [];
      if (patch.title !== undefined) { sets.push("title=?"); vals.push(patch.title); }
      if (patch.titleSource !== undefined) { sets.push("title_source=?"); vals.push(patch.titleSource); }
      if (patch.archived !== undefined) { sets.push("archived=?"); vals.push(patch.archived ? 1 : 0); }
      if (patch.memoryEnabled !== undefined) { sets.push("memory_enabled=?"); vals.push(patch.memoryEnabled ? 1 : 0); }
      if (patch.mode !== undefined) { sets.push("mode=?"); vals.push(patch.mode); }
      if (touch) { sets.push("updated_at=?"); vals.push(nowIso()); }
      if (sets.length) db.prepare(`UPDATE conversations SET ${sets.join(",")} WHERE id=?`).run(...vals, id);
      return this.get(id)!;
    },
    touch(id: string): void {
      db.prepare("UPDATE conversations SET updated_at=? WHERE id=?").run(nowIso(), id);
    },
    delete(id: string): boolean {
      return db.prepare("DELETE FROM conversations WHERE id=?").run(id).changes > 0;
    },
    list(opts: { archived: boolean; q?: string; limit: number; offset: number }): { conversations: Conversation[]; hasMore: boolean } {
      const arch = opts.archived ? 1 : 0;
      const fts = opts.q ? ftsQuery(opts.q) : null;
      if (opts.q && opts.q.trim()) {
        // Title matches + message-body matches (with highlighted snippet), newest activity first.
        const found = new Map<string, Conversation>();
        const like = `%${opts.q.trim().replace(/[\\%_]/g, (m) => "\\" + m)}%`;
        const titleRows = db.prepare(
          "SELECT * FROM conversations WHERE archived=? AND title LIKE ? ESCAPE '\\' ORDER BY updated_at DESC LIMIT 200",
        ).all(arch, like) as Row[];
        for (const r of titleRows) {
          const c = toConv(r);
          const idx = c.title.toLowerCase().indexOf(opts.q.trim().toLowerCase());
          c.snippet = idx >= 0
            ? escapeHtml(c.title.slice(0, idx)) + "<mark>" + escapeHtml(c.title.slice(idx, idx + opts.q.trim().length)) + "</mark>" + escapeHtml(c.title.slice(idx + opts.q.trim().length))
            : escapeHtml(c.title);
          found.set(c.id, c);
        }
        if (fts) {
          const rows = db.prepare(
            `SELECT c.*, snippet(messages_fts, 0, '${OPEN}', '${CLOSE}', '…', 14) AS snip
             FROM messages_fts JOIN messages m ON m.rowid = messages_fts.rowid
             JOIN conversations c ON c.id = m.conversation_id
             WHERE messages_fts MATCH ? AND c.archived = ? ORDER BY rank LIMIT 300`,
          ).all(fts, arch) as (Row & { snip: string })[];
          for (const r of rows) {
            if (found.has(r.id)) continue;
            const c = toConv(r);
            c.snippet = markSnippet(r.snip);
            found.set(c.id, c);
          }
        }
        const all = [...found.values()].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
        const page = all.slice(opts.offset, opts.offset + opts.limit);
        return { conversations: page, hasMore: opts.offset + opts.limit < all.length };
      }
      const rows = db.prepare(
        "SELECT * FROM conversations WHERE archived=? ORDER BY updated_at DESC LIMIT ? OFFSET ?",
      ).all(arch, opts.limit + 1, opts.offset) as Row[];
      return { conversations: rows.slice(0, opts.limit).map(toConv), hasMore: rows.length > opts.limit };
    },
    all(): Conversation[] {
      return (db.prepare("SELECT * FROM conversations ORDER BY created_at").all() as Row[]).map(toConv);
    },
    count(): number {
      return (db.prepare("SELECT COUNT(*) AS n FROM conversations").get() as { n: number }).n;
    },
  };
}
export type ConversationRepo = ReturnType<typeof createConversationRepo>;
