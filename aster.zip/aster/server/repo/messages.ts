import type { Db } from "../db.ts";
import type { Attachment, Message, MessageStatus, ToolEvent } from "./types.ts";
import { newId, nowIso, safeJson } from "../util.ts";
import { createHash } from "node:crypto";

type MRow = {
  id: string; conversation_id: string; seq: number; role: "user" | "assistant"; content: string; status: string;
  error_json: string | null; model: string | null; stop_reason: string | null; tool_events_json: string | null;
  usage_json: string | null; created_at: string;
};
type ARow = { id: string; message_id: string | null; name: string; kind: string; mime: string; size: number };

const toAttachment = (r: ARow): Attachment => ({
  id: r.id, name: r.name, kind: r.kind as Attachment["kind"], mime: r.mime, size: r.size, url: `/api/attachments/${r.id}`,
});

export interface MessagePatch {
  content?: string; status?: MessageStatus; error?: { code: string; message: string } | null;
  model?: string | null; stopReason?: string | null; toolEvents?: ToolEvent[];
  usage?: { inputTokens: number; outputTokens: number } | null;
}

export function createAttachmentRepo(db: Db) {
  const META = "id,message_id,name,kind,mime,size";
  return {
    create(a: { name: string; kind: Attachment["kind"]; mime: string; data: Uint8Array }): Attachment {
      const id = newId();
      const sha = createHash("sha256").update(a.data).digest("hex");
      db.prepare(
        "INSERT INTO attachments (id,message_id,name,kind,mime,size,sha256,data,created_at) VALUES (?,NULL,?,?,?,?,?,?,?)",
      ).run(id, a.name, a.kind, a.mime, a.data.byteLength, sha, a.data, nowIso());
      return this.meta(id)!;
    },
    meta(id: string): Attachment | null {
      const r = db.prepare(`SELECT ${META} FROM attachments WHERE id=?`).get(id) as ARow | undefined;
      return r ? toAttachment(r) : null;
    },
    row(id: string): (ARow & { data: Uint8Array }) | null {
      return (db.prepare(`SELECT ${META},data FROM attachments WHERE id=?`).get(id) as (ARow & { data: Uint8Array }) | undefined) ?? null;
    },
    isUnattached(id: string): boolean {
      const r = db.prepare("SELECT message_id FROM attachments WHERE id=?").get(id) as { message_id: string | null } | undefined;
      return !!r && r.message_id === null;
    },
    attach(ids: string[], messageId: string): void {
      const st = db.prepare("UPDATE attachments SET message_id=? WHERE id=? AND message_id IS NULL");
      for (const id of ids) st.run(messageId, id);
    },
    deleteUnattached(id: string): boolean {
      return db.prepare("DELETE FROM attachments WHERE id=? AND message_id IS NULL").run(id).changes > 0;
    },
    forMessageWithData(messageId: string): (ARow & { data: Uint8Array })[] {
      return db.prepare(`SELECT ${META},data FROM attachments WHERE message_id=? ORDER BY created_at, rowid`).all(messageId) as (ARow & { data: Uint8Array })[];
    },
    purgeUnattachedBefore(iso: string): number {
      return Number(db.prepare("DELETE FROM attachments WHERE message_id IS NULL AND created_at < ?").run(iso).changes);
    },
    count(): number {
      return (db.prepare("SELECT COUNT(*) AS n FROM attachments").get() as { n: number }).n;
    },
    allWithData(): (ARow & { data: Uint8Array })[] {
      return db.prepare(`SELECT ${META},data FROM attachments ORDER BY created_at`).all() as (ARow & { data: Uint8Array })[];
    },
  };
}
export type AttachmentRepo = ReturnType<typeof createAttachmentRepo>;

export function createMessageRepo(db: Db) {
  const attachmentsFor = (convId: string): Map<string, Attachment[]> => {
    const rows = db.prepare(
      `SELECT a.id,a.message_id,a.name,a.kind,a.mime,a.size FROM attachments a
       JOIN messages m ON m.id=a.message_id WHERE m.conversation_id=? ORDER BY a.created_at, a.rowid`,
    ).all(convId) as ARow[];
    const map = new Map<string, Attachment[]>();
    for (const r of rows) {
      const list = map.get(r.message_id!) ?? [];
      list.push(toAttachment(r));
      map.set(r.message_id!, list);
    }
    return map;
  };
  const toMessage = (r: MRow, atts: Attachment[]): Message => ({
    id: r.id, role: r.role, content: r.content, status: r.status as MessageStatus,
    error: safeJson(r.error_json, null), model: r.model, stopReason: r.stop_reason, createdAt: r.created_at,
    attachments: atts, toolEvents: safeJson<ToolEvent[]>(r.tool_events_json, []),
    usage: safeJson(r.usage_json, null),
  });

  return {
    insert(m: { conversationId: string; role: "user" | "assistant"; content: string; status?: MessageStatus; model?: string | null }): Message {
      const id = newId();
      const seq = ((db.prepare("SELECT COALESCE(MAX(seq),0) AS s FROM messages WHERE conversation_id=?").get(m.conversationId) as { s: number }).s) + 1;
      db.prepare(
        "INSERT INTO messages (id,conversation_id,seq,role,content,status,model,created_at) VALUES (?,?,?,?,?,?,?,?)",
      ).run(id, m.conversationId, seq, m.role, m.content, m.status ?? "complete", m.model ?? null, nowIso());
      return this.get(id)!;
    },
    get(id: string): Message | null {
      const r = db.prepare("SELECT * FROM messages WHERE id=?").get(id) as MRow | undefined;
      if (!r) return null;
      const atts = (db.prepare("SELECT id,message_id,name,kind,mime,size FROM attachments WHERE message_id=? ORDER BY created_at, rowid").all(id) as ARow[]).map(toAttachment);
      return toMessage(r, atts);
    },
    conversationOf(id: string): string | null {
      const r = db.prepare("SELECT conversation_id FROM messages WHERE id=?").get(id) as { conversation_id: string } | undefined;
      return r?.conversation_id ?? null;
    },
    seqOf(id: string): number | null {
      const r = db.prepare("SELECT seq FROM messages WHERE id=?").get(id) as { seq: number } | undefined;
      return r?.seq ?? null;
    },
    list(convId: string): Message[] {
      const atts = attachmentsFor(convId);
      const rows = db.prepare("SELECT * FROM messages WHERE conversation_id=? ORDER BY seq").all(convId) as MRow[];
      return rows.map((r) => toMessage(r, atts.get(r.id) ?? []));
    },
    update(id: string, p: MessagePatch): void {
      const sets: string[] = [], vals: (string | number | null)[] = [];
      if (p.content !== undefined) { sets.push("content=?"); vals.push(p.content); }
      if (p.status !== undefined) { sets.push("status=?"); vals.push(p.status); }
      if (p.error !== undefined) { sets.push("error_json=?"); vals.push(p.error ? JSON.stringify(p.error) : null); }
      if (p.model !== undefined) { sets.push("model=?"); vals.push(p.model); }
      if (p.stopReason !== undefined) { sets.push("stop_reason=?"); vals.push(p.stopReason); }
      if (p.toolEvents !== undefined) { sets.push("tool_events_json=?"); vals.push(JSON.stringify(p.toolEvents)); }
      if (p.usage !== undefined) { sets.push("usage_json=?"); vals.push(p.usage ? JSON.stringify(p.usage) : null); }
      if (sets.length) db.prepare(`UPDATE messages SET ${sets.join(",")} WHERE id=?`).run(...vals, id);
    },
    /** Delete the message with this seq and everything after it (attachments cascade). */
    deleteFromSeq(convId: string, seq: number): number {
      return Number(db.prepare("DELETE FROM messages WHERE conversation_id=? AND seq>=?").run(convId, seq).changes);
    },
    count(): number {
      return (db.prepare("SELECT COUNT(*) AS n FROM messages").get() as { n: number }).n;
    },
    countIn(convId: string): number {
      return (db.prepare("SELECT COUNT(*) AS n FROM messages WHERE conversation_id=?").get(convId) as { n: number }).n;
    },
    /** Crash recovery: generations interrupted by a restart become 'stopped'. */
    recoverStreaming(): number {
      return Number(db.prepare("UPDATE messages SET status='stopped' WHERE status='streaming'").run().changes);
    },
  };
}
export type MessageRepo = ReturnType<typeof createMessageRepo>;
