// Minimal logger. Privacy rule: never log message text, memory text, filenames or prompts.
// Only operational metadata (method, path template, status, duration, error codes).

let quiet = false;
export const setQuiet = (q: boolean): void => { quiet = q; };

const stamp = () => new Date().toISOString();
export const info = (msg: string): void => { if (!quiet) console.log(`${stamp()} ${msg}`); };
export const warn = (msg: string): void => { if (!quiet) console.warn(`${stamp()} WARN ${msg}`); };
export const error = (msg: string, err?: unknown): void => {
  if (quiet) return;
  const name = err instanceof Error ? err.name : typeof err;
  const code = (err as { code?: unknown } | null)?.code;
  console.error(`${stamp()} ERROR ${msg}${err ? ` [${name}${code ? ":" + String(code) : ""}]` : ""}`);
};
