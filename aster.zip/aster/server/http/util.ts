import type { IncomingMessage, ServerResponse } from "node:http";
import { AppError, isAppError } from "../errors.ts";
import * as log from "../log.ts";

export function sendJson(res: ServerResponse, status: number, body: unknown, headers: Record<string, string> = {}): void {
  const data = JSON.stringify(body);
  res.writeHead(status, { "content-type": "application/json; charset=utf-8", "content-length": Buffer.byteLength(data), "cache-control": "no-store", ...headers });
  res.end(data);
}

export function sendNoContent(res: ServerResponse, headers: Record<string, string | string[]> = {}): void {
  res.writeHead(204, { "cache-control": "no-store", ...headers });
  res.end();
}

export function sendError(res: ServerResponse, e: unknown): void {
  let err: AppError;
  if (isAppError(e)) err = e;
  else { log.error("unhandled request error", e); err = new AppError("server", "Internal server error.", { status: 500 }); }
  if (res.headersSent) { res.end(); return; }
  const extra: Record<string, string> = {};
  if (err.retryAfterMs) extra["retry-after"] = String(Math.ceil(err.retryAfterMs / 1000));
  sendJson(res, err.status, { error: { code: err.code, message: err.message } }, extra);
}

/** Read a request body fully, enforcing a byte limit (excess is drained, not stored). */
export async function readBody(req: IncomingMessage, limit: number): Promise<Buffer> {
  const declared = Number(req.headers["content-length"]);
  if (Number.isFinite(declared) && declared > limit) {
    req.resume();
    throw new AppError("validation", `Request is too large (limit ${Math.round(limit / 1024)} KB).`, { status: 413 });
  }
  const chunks: Buffer[] = [];
  let size = 0, over = false;
  for await (const chunk of req) {
    size += (chunk as Buffer).length;
    if (size > limit) { over = true; continue; }
    chunks.push(chunk as Buffer);
  }
  if (over) throw new AppError("validation", `Request is too large (limit ${Math.round(limit / 1024)} KB).`, { status: 413 });
  return Buffer.concat(chunks);
}

export async function readJson(req: IncomingMessage, limit = 1024 * 1024): Promise<unknown> {
  const body = await readBody(req, limit);
  if (body.length === 0) return {};
  const ct = String(req.headers["content-type"] ?? "").toLowerCase();
  if (!ct.startsWith("application/json")) throw new AppError("invalid_request", "Content-Type must be application/json.", { status: 415 });
  try { return JSON.parse(body.toString("utf8")); }
  catch { throw new AppError("validation", "Request body is not valid JSON.", { status: 400 }); }
}

export function parseCookies(req: IncomingMessage): Record<string, string> {
  const out: Record<string, string> = {};
  for (const part of String(req.headers.cookie ?? "").split(";")) {
    const i = part.indexOf("=");
    if (i <= 0) continue;
    const raw = part.slice(i + 1).trim();
    try { out[part.slice(0, i).trim()] = decodeURIComponent(raw); } catch { out[part.slice(0, i).trim()] = raw; }
  }
  return out;
}

export const clientIp = (req: IncomingMessage): string => req.socket.remoteAddress ?? "unknown";

/** Fixed-window rate limiter. */
export class RateLimiter {
  private hits = new Map<string, { n: number; reset: number }>();
  /** Returns true if allowed. */
  allow(key: string, limit: number, windowMs: number, now = Date.now()): boolean {
    const h = this.hits.get(key);
    if (!h || now >= h.reset) {
      this.hits.set(key, { n: 1, reset: now + windowMs });
      if (this.hits.size > 5000) for (const [k, v] of this.hits) if (now >= v.reset) this.hits.delete(k);
      return true;
    }
    h.n++;
    return h.n <= limit;
  }
  retryAfterMs(key: string, now = Date.now()): number {
    const h = this.hits.get(key);
    return h ? Math.max(0, h.reset - now) : 0;
  }
  clear(key: string): void { this.hits.delete(key); }
}
