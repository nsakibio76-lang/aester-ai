// Static file server for public/ with path-traversal protection, ETags and an SPA fallback to index.html.

import fs from "node:fs";
import path from "node:path";
import type { IncomingMessage, ServerResponse } from "node:http";

const MIME: Record<string, string> = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml",
  ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".ico": "image/x-icon",
  ".woff2": "font/woff2", ".woff": "font/woff", ".txt": "text/plain; charset=utf-8", ".map": "application/json",
  ".webmanifest": "application/manifest+json",
};

export function resolvePublicPath(publicDir: string, urlPath: string): string | null {
  let decoded: string;
  try { decoded = decodeURIComponent(urlPath); } catch { return null; }
  if (decoded.includes("\0") || decoded.includes("\\")) return null;
  const segs = decoded.split("/").filter(Boolean);
  if (segs.some((s) => s === ".." || s.startsWith("."))) return null;
  const full = path.resolve(publicDir, ...segs);
  if (full !== publicDir && !full.startsWith(publicDir + path.sep)) return null;
  return full;
}

export async function serveStatic(req: IncomingMessage, res: ServerResponse, publicDir: string, pathname: string): Promise<boolean> {
  if (req.method !== "GET" && req.method !== "HEAD") return false;
  let file = resolvePublicPath(publicDir, pathname);
  if (!file) { res.writeHead(404, { "content-type": "text/plain; charset=utf-8" }); res.end("Not found"); return true; }
  const hasExt = path.extname(pathname) !== "";
  let st = await fs.promises.stat(file).catch(() => null);
  if (st?.isDirectory()) { file = path.join(file, "index.html"); st = await fs.promises.stat(file).catch(() => null); }
  if (!st || !st.isFile()) {
    if (hasExt) { res.writeHead(404, { "content-type": "text/plain; charset=utf-8" }); res.end("Not found"); return true; }
    file = path.join(publicDir, "index.html"); // SPA route
    st = await fs.promises.stat(file).catch(() => null);
    if (!st) { res.writeHead(404, { "content-type": "text/plain; charset=utf-8" }); res.end("Not found"); return true; }
  }
  const etag = `W/"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}"`;
  const ext = path.extname(file).toLowerCase();
  const headers: Record<string, string> = {
    "content-type": MIME[ext] ?? "application/octet-stream",
    "content-length": String(st.size),
    etag,
    "cache-control": pathname.startsWith("/vendor/") ? "public, max-age=86400" : "no-cache",
  };
  if (req.headers["if-none-match"] === etag) { res.writeHead(304, { etag, "cache-control": headers["cache-control"]! }); res.end(); return true; }
  res.writeHead(200, headers);
  if (req.method === "HEAD") { res.end(); return true; }
  fs.createReadStream(file).on("error", () => res.destroy()).pipe(res);
  return true;
}
