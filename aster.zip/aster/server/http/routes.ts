// All HTTP endpoints (see docs/API.md for the contract).

import type { ServerResponse } from "node:http";
import { IMAGE_TYPES, TEXT_EXTENSIONS } from "../config.ts";
import type { Config } from "../config.ts";
import type { Db } from "../db.ts";
import { tx } from "../db.ts";
import { AppError, notFound, validation } from "../errors.ts";
import type { MemoryService } from "../memory/service.ts";
import { isCategory } from "../memory/service.ts";
import type { AIProvider } from "../providers/types.ts";
import type { ConversationRepo } from "../repo/conversations.ts";
import type { AttachmentRepo, MessageRepo } from "../repo/messages.ts";
import type { MemoryRepo } from "../repo/memories.ts";
import type { SettingsRepo } from "../repo/settings.ts";
import { validateSettingsPatch } from "../repo/settings.ts";
import { CATEGORIES, MODES } from "../repo/types.ts";
import type { Mode } from "../repo/types.ts";
import { parseChatRequest } from "../chat/service.ts";
import type { ChatService } from "../chat/service.ts";
import { nowIso } from "../util.ts";
import type { Auth } from "./auth.ts";
import { Router } from "./router.ts";
import { clientIp, RateLimiter, readBody, readJson, sendJson, sendNoContent } from "./util.ts";
import { classifyUpload, sanitizeFileName } from "./uploads.ts";

export interface AppDeps {
  config: Config;
  db: Db;
  auth: Auth;
  provider: AIProvider;
  conversations: ConversationRepo;
  messages: MessageRepo;
  attachments: AttachmentRepo;
  memoryRepo: MemoryRepo;
  memory: MemoryService;
  settings: SettingsRepo;
  chat: ChatService;
}

const DELETE_PHRASE = "DELETE ALL MY DATA";

function asObject(v: unknown): Record<string, unknown> {
  if (typeof v !== "object" || v === null || Array.isArray(v)) throw validation("Request body must be a JSON object.");
  return v as Record<string, unknown>;
}

function intParam(v: string | null, dflt: number, min: number, max: number): number {
  if (v === null || v === "") return dflt;
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw validation("Invalid paging parameter.");
  return n;
}

export function buildRouter(d: AppDeps): Router {
  const r = new Router();
  const { config } = d;
  const chatLimiter = new RateLimiter();

  // ---- public ----
  r.add("GET", "/api/health", ({ res }) => sendJson(res, 200, { ok: true }), { public: true });

  r.add("GET", "/api/meta", ({ req, res }) => {
    const authenticated = d.auth.isAuthenticated(req);
    sendJson(res, 200, {
      appName: config.appName, version: config.version,
      authRequired: d.auth.required, authenticated,
      apiConfigured: d.provider.isConfigured(),
      provider: { id: d.provider.id, name: d.provider.name },
      models: config.models, defaultModel: config.defaultModel,
      limits: {
        maxMessageChars: config.maxMessageChars, maxAttachments: config.maxAttachments,
        maxImageBytes: config.maxImageBytes, maxPdfBytes: config.maxPdfBytes, maxTextBytes: config.maxTextBytes,
        imageTypes: IMAGE_TYPES, textExtensions: TEXT_EXTENSIONS,
      },
    });
  }, { public: true });

  r.add("POST", "/api/auth/login", async ({ req, res }) => {
    const body = asObject(await readJson(req, 4096));
    const cookie = d.auth.login(req, body.password);
    sendNoContent(res, { "set-cookie": cookie });
  }, { public: true });

  r.add("POST", "/api/auth/logout", ({ req, res }) => sendNoContent(res, { "set-cookie": d.auth.logout(req) }), { public: true });

  // ---- settings ----
  r.add("GET", "/api/settings", ({ res }) => sendJson(res, 200, d.settings.get()));
  r.add("PUT", "/api/settings", async ({ req, res }) => {
    const patch = validateSettingsPatch(await readJson(req, 16 * 1024));
    sendJson(res, 200, d.settings.update(patch));
  });

  // ---- conversations ----
  r.add("GET", "/api/conversations", ({ url, res }) => {
    const archived = url.searchParams.get("archived") === "1";
    const q = (url.searchParams.get("q") ?? "").slice(0, 200);
    sendJson(res, 200, d.conversations.list({
      archived, q, limit: intParam(url.searchParams.get("limit"), 50, 1, 100), offset: intParam(url.searchParams.get("offset"), 0, 0, 100000),
    }));
  });

  r.add("POST", "/api/conversations", async ({ req, res }) => {
    const b = asObject(await readJson(req, 16 * 1024));
    if (b.title !== undefined && (typeof b.title !== "string" || b.title.length > 120)) throw validation("Invalid title.");
    if (b.mode !== undefined && !MODES.includes(b.mode as Mode)) throw validation("Invalid mode.");
    if (b.memoryEnabled !== undefined && typeof b.memoryEnabled !== "boolean") throw validation("memoryEnabled must be true or false.");
    sendJson(res, 201, d.conversations.create({ title: b.title as string | undefined, mode: b.mode as Mode | undefined, memoryEnabled: b.memoryEnabled as boolean | undefined }));
  });

  r.add("GET", "/api/conversations/:id", ({ params, res }) => {
    const conversation = d.conversations.require(params.id!);
    sendJson(res, 200, { conversation, messages: d.messages.list(conversation.id) });
  });

  r.add("PATCH", "/api/conversations/:id", async ({ req, res, params }) => {
    const b = asObject(await readJson(req, 16 * 1024));
    d.conversations.require(params.id!);
    const patch: Parameters<ConversationRepo["update"]>[1] = {};
    if (b.title !== undefined) {
      if (typeof b.title !== "string" || !b.title.trim() || b.title.length > 120) throw validation("Title must be 1–120 characters.");
      patch.title = b.title.trim(); patch.titleSource = "user";
    }
    if (b.archived !== undefined) { if (typeof b.archived !== "boolean") throw validation("archived must be true or false."); patch.archived = b.archived; }
    if (b.memoryEnabled !== undefined) { if (typeof b.memoryEnabled !== "boolean") throw validation("memoryEnabled must be true or false."); patch.memoryEnabled = b.memoryEnabled; }
    if (b.mode !== undefined) { if (!MODES.includes(b.mode as Mode)) throw validation("Invalid mode."); patch.mode = b.mode as Mode; }
    sendJson(res, 200, d.conversations.update(params.id!, patch));
  });

  r.add("DELETE", "/api/conversations/:id", ({ params, res }) => {
    if (d.chat.isActive(params.id!)) throw new AppError("invalid_request", "Stop the running reply before deleting this conversation.", { status: 409 });
    if (!d.conversations.delete(params.id!)) throw notFound("Conversation");
    sendNoContent(res);
  });

  // ---- uploads & attachments ----
  r.add("POST", "/api/uploads", async ({ req, res }) => {
    const hard = Math.max(config.maxImageBytes, config.maxPdfBytes, config.maxTextBytes);
    const body = await readBody(req, hard);
    const c = classifyUpload(body, String(req.headers["content-type"] ?? ""), String(req.headers["x-file-name"] ?? ""), config);
    sendJson(res, 201, d.attachments.create({ name: c.name, kind: c.kind, mime: c.mime, data: body }));
  });

  r.add("DELETE", "/api/uploads/:id", ({ params, res }) => {
    if (!d.attachments.deleteUnattached(params.id!)) throw notFound("Upload");
    sendNoContent(res);
  });

  r.add("GET", "/api/attachments/:id", ({ params, res }) => {
    const a = d.attachments.row(params.id!);
    if (!a) throw notFound("Attachment");
    const data = Buffer.from(a.data);
    const inline = a.kind === "image";
    sendAttachment(res, data, a.mime, a.name, inline);
  });

  // ---- memories ----
  r.add("GET", "/api/memories", ({ url, res }) => {
    const category = url.searchParams.get("category") ?? "";
    if (category && !isCategory(category)) throw validation("Unknown category.");
    const memories = d.memory.list({ q: (url.searchParams.get("q") ?? "").slice(0, 200), category: category || undefined });
    sendJson(res, 200, { memories, total: memories.length, categories: [...CATEGORIES] });
  });

  r.add("POST", "/api/memories", async ({ req, res }) => {
    const b = asObject(await readJson(req, 16 * 1024));
    if (b.category !== undefined && !isCategory(b.category)) throw validation("Unknown category.");
    const out = d.memory.save({ content: b.content, category: b.category, source: "manual" });
    sendJson(res, 201, out.memory);
  });

  r.add("PATCH", "/api/memories/:id", async ({ req, res, params }) => {
    const b = asObject(await readJson(req, 16 * 1024));
    if (b.content === undefined && b.category === undefined) throw validation("Nothing to update.");
    const m = d.memory.update(params.id!, { content: b.content, category: b.category }, "manual");
    if (!m) throw notFound("Memory");
    sendJson(res, 200, m);
  });

  r.add("DELETE", "/api/memories/:id", ({ params, res }) => {
    if (!d.memory.delete(params.id!)) throw notFound("Memory");
    sendNoContent(res);
  });

  r.add("DELETE", "/api/memories", async ({ req, res }) => {
    const b = asObject(await readJson(req, 4096));
    if (b.confirm !== true) throw validation('Send {"confirm": true} to delete all memories.');
    sendJson(res, 200, { deleted: d.memory.deleteAll() });
  });

  // ---- data export / deletion ----
  r.add("GET", "/api/export", ({ url, res }) => {
    const files = url.searchParams.get("files") === "1";
    const conversations = d.conversations.all().map((c) => ({
      ...c,
      messages: d.messages.list(c.id).map((m) => ({ ...m, attachments: m.attachments.map((a) => ({ ...a })) })),
    }));
    const payload: Record<string, unknown> = {
      exportedAt: nowIso(), app: config.appName, version: config.version,
      settings: d.settings.get(), memories: d.memory.list(), conversations,
    };
    if (files) {
      payload.files = d.attachments.allWithData().map((a) => ({ id: a.id, name: a.name, mime: a.mime, size: a.size, messageId: a.message_id, dataBase64: Buffer.from(a.data).toString("base64") }));
    }
    const data = JSON.stringify(payload, null, 2);
    res.writeHead(200, {
      "content-type": "application/json; charset=utf-8",
      "content-disposition": `attachment; filename="aster-export-${nowIso().slice(0, 10)}.json"`,
      "content-length": Buffer.byteLength(data), "cache-control": "no-store",
    });
    res.end(data);
  });

  r.add("DELETE", "/api/data", async ({ req, res }) => {
    const b = asObject(await readJson(req, 4096));
    if (b.confirm !== DELETE_PHRASE) throw validation(`Type "${DELETE_PHRASE}" exactly to confirm.`);
    if (d.chat.activeCount() > 0) throw new AppError("invalid_request", "Wait for the running reply to finish (or stop it) first.", { status: 409 });
    const deleted = tx(d.db, () => {
      const out = { conversations: d.conversations.count(), messages: d.messages.count(), memories: d.memory.count(), attachments: d.attachments.count() };
      d.db.exec("DELETE FROM attachments; DELETE FROM conversations; DELETE FROM memories;");
      d.settings.reset();
      return out;
    });
    d.db.exec("INSERT INTO messages_fts(messages_fts) VALUES('rebuild'); PRAGMA wal_checkpoint(TRUNCATE);");
    sendJson(res, 200, { deleted });
  });

  // ---- chat (Server-Sent Events) ----
  r.add("POST", "/api/chat", async ({ req, res }) => {
    const body = await readJson(req, 2 * 1024 * 1024);
    const request = parseChatRequest(body, config);
    const ip = clientIp(req);
    if (!chatLimiter.allow(`chat:${ip}`, config.chatRatePerMinute, 60_000))
      throw new AppError("rate_limited", "You're sending messages very quickly. Wait a few seconds.", { status: 429, retryAfterMs: chatLimiter.retryAfterMs(`chat:${ip}`) });

    const turn = d.chat.prepare(request); // validation / not_found / conflict → normal JSON error

    res.writeHead(200, {
      "content-type": "text/event-stream; charset=utf-8", "cache-control": "no-cache, no-transform",
      connection: "keep-alive", "x-accel-buffering": "no",
    });
    res.flushHeaders();
    const ctl = new AbortController();
    let finished = false;
    res.on("close", () => { if (!finished) ctl.abort(new Error("client disconnected")); });
    const emit = (event: string, data: unknown) => {
      if (finished || res.destroyed || res.writableEnded) return;
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    };
    const keepAlive = setInterval(() => { if (!finished && !res.destroyed) res.write(": ping\n\n"); }, 15000);
    try {
      await turn.run(emit, ctl.signal);
    } finally {
      clearInterval(keepAlive);
      finished = true;
      if (!res.writableEnded) res.end();
    }
  });

  return r;
}

function sendAttachment(res: ServerResponse, data: Buffer, mime: string, name: string, inline: boolean): void {
  const safe = sanitizeFileName(name);
  res.writeHead(200, {
    "content-type": inline ? mime : "application/octet-stream",
    "content-length": data.length,
    "content-disposition": `${inline ? "inline" : "attachment"}; filename*=UTF-8''${encodeURIComponent(safe)}`,
    "x-content-type-options": "nosniff",
    "content-security-policy": "sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src data:",
    "cache-control": "private, max-age=3600",
  });
  res.end(data);
}
