// Optional single-user password login (enabled by setting ASTER_PASSWORD). Sessions are random 256-bit tokens kept
// server-side as SHA-256 hashes; the cookie is HttpOnly + SameSite=Strict. Login attempts are rate-limited.

import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import type { IncomingMessage } from "node:http";
import type { Config } from "../config.ts";
import type { Db } from "../db.ts";
import { AppError } from "../errors.ts";
import { clientIp, parseCookies, RateLimiter } from "./util.ts";

const COOKIE = "aster_session";
const sha = (s: string): string => createHash("sha256").update(s).digest("hex");

export function createAuth(cfg: Config, db: Db) {
  const required = cfg.password !== null;
  const salt = randomBytes(16);
  const expected = required ? scryptSync(cfg.password!, salt, 32) : null;
  const limiter = new RateLimiter();

  const purge = () => db.prepare("DELETE FROM sessions WHERE expires_at < ?").run(new Date().toISOString());
  purge();

  const token = (req: IncomingMessage): string | null => parseCookies(req)[COOKIE] ?? null;

  const cookieAttrs = (maxAge: number) =>
    `Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${cfg.cookieSecure ? "; Secure" : ""}`;

  return {
    required,
    isAuthenticated(req: IncomingMessage): boolean {
      if (!required) return true;
      const t = token(req);
      if (!t) return false;
      const row = db.prepare("SELECT expires_at FROM sessions WHERE token_hash=?").get(sha(t)) as { expires_at: string } | undefined;
      return !!row && row.expires_at > new Date().toISOString();
    },
    /** Verifies the password and returns a Set-Cookie header value. Throws AppError on failure/rate limit. */
    login(req: IncomingMessage, password: unknown): string {
      if (!required) return `${COOKIE}=; ${cookieAttrs(0)}`;
      const key = `login:${clientIp(req)}`;
      if (!limiter.allow(key, 8, 5 * 60_000)) {
        throw new AppError("rate_limited", "Too many login attempts. Wait a few minutes and try again.", { status: 429, retryAfterMs: limiter.retryAfterMs(key) });
      }
      const given = typeof password === "string" ? scryptSync(password.slice(0, 256), salt, 32) : null;
      if (!given || !timingSafeEqual(given, expected!)) throw new AppError("invalid_password", "That password isn't right.", { status: 401 });
      limiter.clear(key);
      purge();
      const t = randomBytes(32).toString("base64url");
      const now = Date.now();
      db.prepare("INSERT INTO sessions (token_hash,created_at,expires_at) VALUES (?,?,?)")
        .run(sha(t), new Date(now).toISOString(), new Date(now + cfg.sessionTtlMs).toISOString());
      return `${COOKIE}=${t}; ${cookieAttrs(Math.floor(cfg.sessionTtlMs / 1000))}`;
    },
    logout(req: IncomingMessage): string {
      const t = token(req);
      if (t) db.prepare("DELETE FROM sessions WHERE token_hash=?").run(sha(t));
      return `${COOKIE}=; ${cookieAttrs(0)}`;
    },
  };
}
export type Auth = ReturnType<typeof createAuth>;
