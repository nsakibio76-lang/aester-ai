import type { IncomingMessage, ServerResponse } from "node:http";

export interface Ctx {
  req: IncomingMessage;
  res: ServerResponse;
  url: URL;
  params: Record<string, string>;
}
export type Handler = (c: Ctx) => Promise<void> | void;
interface Route { method: string; segs: string[]; handler: Handler; isPublic: boolean }

export class Router {
  private routes: Route[] = [];

  add(method: string, pattern: string, handler: Handler, opts: { public?: boolean } = {}): void {
    this.routes.push({ method, segs: pattern.split("/").filter(Boolean), handler, isPublic: !!opts.public });
  }

  /** Returns the matching route, or the allowed methods if the path exists under other methods. */
  match(method: string, pathname: string): { route: Route; params: Record<string, string> } | { allow: string[] } | null {
    const parts = pathname.split("/").filter(Boolean);
    const allow = new Set<string>();
    for (const r of this.routes) {
      if (r.segs.length !== parts.length) continue;
      const params: Record<string, string> = {};
      let ok = true;
      for (let i = 0; i < r.segs.length; i++) {
        const s = r.segs[i]!;
        if (s.startsWith(":")) { try { params[s.slice(1)] = decodeURIComponent(parts[i]!); } catch { ok = false; break; } }
        else if (s !== parts[i]) { ok = false; break; }
      }
      if (!ok) continue;
      if (r.method === method || (method === "HEAD" && r.method === "GET")) return { route: r, params };
      allow.add(r.method);
    }
    return allow.size ? { allow: [...allow] } : null;
  }
}
