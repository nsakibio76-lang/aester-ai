import type { IncomingMessage, ServerResponse } from "node:http";
import type { Config } from "../config.ts";
import { AppError } from "../errors.ts";

export const CSP =
  "default-src 'self'; script-src 'self'; style-src 'self'; style-src-attr 'unsafe-inline'; img-src 'self' data: blob:; " +
  "font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'";

export function applySecurityHeaders(res: ServerResponse, cfg: Pick<Config, "cookieSecure">): void {
  res.setHeader("content-security-policy", CSP);
  res.setHeader("x-content-type-options", "nosniff");
  res.setHeader("x-frame-options", "DENY");
  res.setHeader("referrer-policy", "no-referrer");
  res.setHeader("permissions-policy", "camera=(), microphone=(), geolocation=(), payment=()");
  res.setHeader("cross-origin-opener-policy", "same-origin");
  res.setHeader("cross-origin-resource-policy", "same-origin");
  if (cfg.cookieSecure) res.setHeader("strict-transport-security", "max-age=31536000; includeSubDomains");
}

const hostname = (hostHeader: string): string => {
  const h = hostHeader.toLowerCase();
  if (h.startsWith("[")) return h.slice(0, h.indexOf("]") + 1);
  return h.split(":")[0] ?? h;
};

/** DNS-rebinding defence: only answer requests addressed to a host we expect. */
export function assertHostAllowed(req: IncomingMessage, cfg: Pick<Config, "allowedHosts">): void {
  const raw = req.headers.host;
  if (!raw) throw new AppError("permission", "Missing Host header.", { status: 400 });
  const h = hostname(raw);
  if (h === "localhost" || h === "127.0.0.1" || h === "[::1]") return;
  if (cfg.allowedHosts.includes(h) || cfg.allowedHosts.includes(raw.toLowerCase())) return;
  throw new AppError("permission", "This host name isn't allowed. Add it to ASTER_ALLOWED_HOSTS if it's yours.", { status: 403 });
}

/** CSRF defence for state-changing requests: browsers always send Origin on these; it must match our host. */
export function assertSameOrigin(req: IncomingMessage): void {
  const method = req.method ?? "GET";
  if (method === "GET" || method === "HEAD" || method === "OPTIONS") return;
  const origin = req.headers.origin;
  const site = req.headers["sec-fetch-site"];
  if (origin !== undefined) {
    let host: string;
    try { host = new URL(origin).host; } catch { throw new AppError("permission", "Cross-origin request blocked.", { status: 403 }); }
    if (host.toLowerCase() !== String(req.headers.host ?? "").toLowerCase()) throw new AppError("permission", "Cross-origin request blocked.", { status: 403 });
    return;
  }
  if (site !== undefined && site !== "same-origin" && site !== "none") throw new AppError("permission", "Cross-origin request blocked.", { status: 403 });
  // No Origin and no cross-site fetch metadata: a non-browser client (curl, tests). Auth (if enabled) still applies.
}
