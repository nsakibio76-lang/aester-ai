// Upload validation. We never trust the client's Content-Type: the file's bytes decide what it is.
// Allowed: PNG/JPEG/GIF/WebP images, PDFs, and plain-text/code files (UTF-8, allowlisted extensions). No SVG, no HTML-as-image.

import path from "node:path";
import { IMAGE_TYPES, TEXT_EXTENSIONS } from "../config.ts";
import type { Config } from "../config.ts";
import { AppError } from "../errors.ts";

export type UploadKind = "image" | "pdf" | "text";
export interface Classified { kind: UploadKind; mime: string; name: string }

export function sniffImage(b: Uint8Array): string | null {
  if (b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 && b[4] === 0x0d && b[5] === 0x0a && b[6] === 0x1a && b[7] === 0x0a) return "image/png";
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b.length >= 6 && b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x38 && (b[4] === 0x37 || b[4] === 0x39) && b[5] === 0x61) return "image/gif";
  if (b.length >= 12 && b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return "image/webp";
  return null;
}

export function sniffPdf(b: Uint8Array): boolean {
  const head = Buffer.from(b.subarray(0, Math.min(b.length, 1024))).toString("latin1");
  return head.includes("%PDF-");
}

export function sanitizeFileName(raw: string | undefined): string {
  let n = raw ?? "";
  try { n = decodeURIComponent(n); } catch { /* keep raw */ }
  n = path.basename(n.replace(/\\/g, "/")).replace(/[\u0000-\u001f\u007f<>:"|?*]/g, "").trim();
  if (n.length > 120) { const ext = path.extname(n).slice(0, 12); n = n.slice(0, 120 - ext.length) + ext; }
  return n || "file";
}

const normMime = (m: string | undefined): string => {
  const x = (m ?? "").split(";")[0]!.trim().toLowerCase();
  return x === "image/jpg" ? "image/jpeg" : x;
};

export function classifyUpload(bytes: Uint8Array, claimedMime: string | undefined, rawName: string | undefined, cfg: Config): Classified {
  const name = sanitizeFileName(rawName);
  const claimed = normMime(claimedMime);
  if (bytes.length === 0) throw new AppError("validation", "That file is empty.", { status: 422 });

  const tooBig = (limit: number, what: string) => new AppError("validation", `${what} is too large (max ${(limit / 1048576).toFixed(limit < 1048576 ? 2 : 0)} MB).`, { status: 413 });

  const img = sniffImage(bytes);
  if (img || claimed.startsWith("image/")) {
    if (!img || !IMAGE_TYPES.includes(img)) throw new AppError("validation", "Unsupported or corrupted image. Use PNG, JPEG, GIF or WebP.", { status: 415 });
    if (claimed && claimed !== img && claimed !== "application/octet-stream") throw new AppError("validation", "The file's contents don't match its declared type.", { status: 415 });
    if (bytes.length > cfg.maxImageBytes) throw tooBig(cfg.maxImageBytes, "Image");
    return { kind: "image", mime: img, name };
  }
  if (sniffPdf(bytes) || claimed === "application/pdf") {
    if (!sniffPdf(bytes)) throw new AppError("validation", "That doesn't look like a valid PDF.", { status: 415 });
    if (bytes.length > cfg.maxPdfBytes) throw tooBig(cfg.maxPdfBytes, "PDF");
    return { kind: "pdf", mime: "application/pdf", name };
  }
  const ext = path.extname(name).toLowerCase();
  if (!TEXT_EXTENSIONS.includes(ext))
    throw new AppError("validation", `Files of type "${ext || "unknown"}" aren't supported. Use images (PNG/JPEG/GIF/WebP), PDFs, or text/code files.`, { status: 415 });
  if (bytes.length > cfg.maxTextBytes) throw tooBig(cfg.maxTextBytes, "Text file");
  if (bytes.includes(0)) throw new AppError("validation", "That file looks binary, not text.", { status: 415 });
  try { new TextDecoder("utf-8", { fatal: true }).decode(bytes); }
  catch { throw new AppError("validation", "Text files must be UTF-8 encoded.", { status: 415 }); }
  return { kind: "text", mime: "text/plain", name };
}
