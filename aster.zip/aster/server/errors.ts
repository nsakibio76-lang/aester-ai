// Typed application errors. `code` values are part of the public API contract (docs/API.md).

export type ErrorCode =
  | "not_configured" | "unauthenticated" | "auth" | "rate_limit" | "overloaded"
  | "context_too_long" | "invalid_request" | "not_found" | "permission" | "billing"
  | "network" | "timeout" | "aborted" | "server" | "refusal" | "validation"
  | "rate_limited" | "sensitive_blocked" | "invalid_password";

export class AppError extends Error {
  code: ErrorCode;
  status: number;
  retryable: boolean;
  retryAfterMs: number | null;

  constructor(code: ErrorCode, message: string, opts: { status?: number; retryable?: boolean; retryAfterMs?: number | null } = {}) {
    super(message);
    this.name = "AppError";
    this.code = code;
    this.status = opts.status ?? defaultStatus(code);
    this.retryable = opts.retryable ?? false;
    this.retryAfterMs = opts.retryAfterMs ?? null;
  }
}

function defaultStatus(code: ErrorCode): number {
  switch (code) {
    case "unauthenticated": return 401;
    case "invalid_password": return 401;
    case "auth": return 502;
    case "permission": return 403;
    case "not_found": return 404;
    case "validation": return 422;
    case "sensitive_blocked": return 422;
    case "rate_limited": return 429;
    case "rate_limit": return 429;
    case "not_configured": return 503;
    case "invalid_request": return 400;
    case "context_too_long": return 413;
    case "overloaded": return 503;
    case "billing": return 402;
    case "network": return 502;
    case "timeout": return 504;
    default: return 500;
  }
}

export function isAppError(e: unknown): e is AppError {
  return e instanceof AppError;
}

export const validation = (message: string) => new AppError("validation", message);
export const notFound = (what: string) => new AppError("not_found", `${what} not found.`);
