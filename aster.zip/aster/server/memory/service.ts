// Long-term memory: validation, de-duplication, retrieval for prompts, forgetting.
// Storage is the `memories` table (see db.ts) — it survives restarts.

import type { MemoryRepo } from "../repo/memories.ts";
import { CATEGORIES } from "../repo/types.ts";
import type { Category, Memory, MemorySource } from "../repo/types.ts";
import { AppError, validation } from "../errors.ts";
import { checkMemoryContent } from "./sensitive.ts";

export const MAX_MEMORY_CHARS = 500;
const STOP = new Set("a an the and or but of to in on at for with is are was were be been am i me my mine you your it its this that these those as by from not no do does did have has had will would can could should about into so if then than they them he she we our their".split(" "));

/** Very light English stemmer so "studies"/"studying"/"studied" compare equal. Good enough for de-duplication. */
export function stem(w: string): string {
  if (w.length <= 3 || !/^[a-z]+$/.test(w)) return w;
  if (w.endsWith("ies") && w.length > 4) return w.slice(0, -3) + "y";
  if (w.endsWith("ing") && w.length > 5) return w.slice(0, -3);
  if (w.endsWith("ied") && w.length > 4) return w.slice(0, -3) + "y";
  if (w.endsWith("ed") && w.length > 4) return w.slice(0, -2);
  if (w.endsWith("es") && w.length > 4) return w.slice(0, -2);
  if (w.endsWith("s") && !w.endsWith("ss")) return w.slice(0, -1);
  return w;
}

export const tokenize = (s: string): string[] =>
  (s.toLowerCase().match(/[\p{L}\p{N}]+/gu) ?? []).filter((w) => w.length > 1 && !STOP.has(w)).map(stem);

function similarity(a: string[], b: string[]): number {
  if (!a.length || !b.length) return 0;
  const A = new Set(a), B = new Set(b);
  let inter = 0;
  for (const w of A) if (B.has(w)) inter++;
  const jaccard = inter / (A.size + B.size - inter);
  const contain = inter / Math.min(A.size, B.size);
  return Math.max(jaccard, contain >= 0.9 && Math.min(A.size, B.size) >= 3 ? contain * 0.85 : 0);
}

export const isCategory = (c: unknown): c is Category => typeof c === "string" && (CATEGORIES as readonly string[]).includes(c);

export function normalizeContent(raw: unknown): string {
  if (typeof raw !== "string") throw validation("Memory content must be text.");
  const s = raw.replace(/\s+/g, " ").trim();
  if (!s) throw validation("Memory content can't be empty.");
  if (s.length > MAX_MEMORY_CHARS) throw validation(`A memory can be at most ${MAX_MEMORY_CHARS} characters. Keep it to one short fact.`);
  return s;
}

export interface SaveResult { action: "added" | "updated"; memory: Memory }

export function createMemoryService(repo: MemoryRepo, opts: { maxMemories: number }) {
  function assertAllowed(content: string, source: MemorySource): void {
    const hit = checkMemoryContent(content, source);
    if (hit) {
      throw new AppError(
        "sensitive_blocked",
        hit.kind === "secret"
          ? `Aster won't store ${hit.reason} in memory.`
          : `That looks like ${hit.reason}, which Aster doesn't save automatically. Tell it explicitly to remember it if you want that.`,
      );
    }
  }

  return {
    list: repo.list.bind(repo),
    get: repo.get.bind(repo),

    /** Save a memory, merging into a near-duplicate instead of creating a second copy. */
    save(input: { content: unknown; category?: unknown; source: MemorySource; conversationId?: string | null }): SaveResult {
      const content = normalizeContent(input.content);
      const category: Category = isCategory(input.category) ? input.category : "context";
      assertAllowed(content, input.source);
      const toks = tokenize(content);
      let best: Memory | null = null, bestScore = 0;
      for (const m of repo.list()) {
        const s = similarity(toks, tokenize(m.content));
        if (s > bestScore) { best = m; bestScore = s; }
      }
      if (best && bestScore >= 0.7) {
        const updated = repo.update(best.id, { content, category: best.category === category ? best.category : category })!;
        return { action: "updated", memory: updated };
      }
      if (repo.count() >= opts.maxMemories) {
        throw new AppError("validation", `Memory is full (${opts.maxMemories} items). Delete some memories first.`);
      }
      return { action: "added", memory: repo.create({ category, content, source: input.source, conversationId: input.conversationId ?? null }) };
    },

    update(id: string, patch: { content?: unknown; category?: unknown }, source: MemorySource = "manual"): Memory | null {
      const p: { content?: string; category?: Category } = {};
      if (patch.content !== undefined) { p.content = normalizeContent(patch.content); assertAllowed(p.content, source); }
      if (patch.category !== undefined) {
        if (!isCategory(patch.category)) throw validation("Unknown memory category.");
        p.category = patch.category;
      }
      return repo.update(id, p);
    },

    delete: (id: string) => repo.delete(id),
    deleteAll: () => repo.deleteAll(),

    /** Forget by id, or by words that must all appear in the memory. Refuses to guess when ambiguous. */
    forget(input: { id?: string; query?: string }): { deleted: Memory[]; ambiguous: Memory[] } {
      if (input.id) {
        const m = repo.get(input.id);
        if (m) { repo.delete(m.id); return { deleted: [m], ambiguous: [] }; }
      }
      const q = tokenize(input.query ?? "");
      if (!q.length) return { deleted: [], ambiguous: [] };
      const matches = repo.list().filter((m) => {
        const t = new Set(tokenize(m.content));
        return q.every((w) => t.has(w));
      });
      if (matches.length === 0) return { deleted: [], ambiguous: [] };
      if (matches.length > 3) return { deleted: [], ambiguous: matches.slice(0, 8) };
      for (const m of matches) repo.delete(m.id);
      return { deleted: matches, ambiguous: [] };
    },

    /**
     * Pick the memories to show the model for this message. Small stores are included in full; larger stores get
     * the most relevant items (word overlap weighted by rarity) plus the user's communication/preference notes.
     */
    retrieve(userText: string, limit = 14): Memory[] {
      const all = repo.list();
      let picked: Memory[];
      if (all.length <= limit) {
        picked = all;
      } else {
        const docs = all.map((m) => new Set(tokenize(m.content)));
        const df = new Map<string, number>();
        for (const d of docs) for (const w of d) df.set(w, (df.get(w) ?? 0) + 1);
        const q = new Set(tokenize(userText));
        const scored = all.map((m, i) => {
          let s = 0;
          for (const w of q) if (docs[i]!.has(w)) s += Math.log(1 + all.length / (df.get(w) ?? 1));
          return { m, s };
        });
        const core = all.filter((m) => m.category === "communication" || m.category === "preferences").slice(0, 4);
        const relevant = scored.filter((x) => x.s > 0).sort((a, b) => b.s - a.s).map((x) => x.m);
        const seen = new Set<string>();
        picked = [];
        for (const m of [...core, ...relevant, ...all]) {
          if (picked.length >= limit) break;
          if (!seen.has(m.id)) { seen.add(m.id); picked.push(m); }
        }
      }
      if (picked.length) repo.touch(picked.map((m) => m.id));
      return picked;
    },

    count: () => repo.count(),
  };
}
export type MemoryService = ReturnType<typeof createMemoryService>;

export function formatMemoriesForPrompt(memories: Memory[]): string {
  return memories.map((m) => `- [${m.category}] ${m.content} (id: ${m.id}, saved ${m.updatedAt.slice(0, 10)})`).join("\n");
}
