// Guards for what may be stored in long-term memory.
//  1. SECRETS (passwords, card numbers, API keys, government IDs, bank accounts) are refused for every source,
//     including manual entry via the UI.
//  2. SENSITIVE CATEGORIES (health, sexuality, religion, politics, immigration, criminal record, detailed
//     finances) are refused only for *automatic* memory. If you explicitly say "remember this" it is allowed.
// These are heuristics; the model is also instructed not to attempt such saves.

export type SensitiveKind = "secret" | "sensitive";
export interface SensitiveHit { kind: SensitiveKind; reason: string }

function luhn(digits: string): boolean {
  let sum = 0, alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = digits.charCodeAt(i) - 48;
    if (alt) { d *= 2; if (d > 9) d -= 9; }
    sum += d; alt = !alt;
  }
  return sum % 10 === 0;
}

const SECRET_PATTERNS: [RegExp, string][] = [
  [/\b(password|passcode|passwd|pwd|pin( code| number)?|cvv|cvc|otp|2fa code|secret key|api[ _-]?key|access token|auth token|bearer token|private key|seed phrase|recovery phrase)\b[^.\n]{0,20}?(\bis\b|=|:)\s*\S+/i, "a password, PIN or secret"],
  [/\b(sk-ant-[A-Za-z0-9_-]{10,}|sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{30,}|xox[abprs]-[A-Za-z0-9-]{10,}|AIza[0-9A-Za-z_-]{30,})\b/, "an API key or token"],
  [/\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}\b/, "a JSON web token"],
  [/-----BEGIN [A-Z ]*PRIVATE KEY-----/, "a private key"],
  [/\b\d{3}-\d{2}-\d{4}\b/, "a social security style number"],
  [/\b[A-Z]{2}\d{2}[ ]?(?:[A-Z0-9]{4}[ ]?){3,7}[A-Z0-9]{1,4}\b/, "an IBAN / bank account number"],
  [/\b(account|acct|a\/c)\s*(number|no\.?|#)\s*(is|:|=)?\s*[\d -]{6,}/i, "a bank account number"],
  [/\b(passport|national id|nid|ssn|social security|driver'?s? licen[cs]e|tax id|tin)\b\s*(number|no\.?|#)?\s*(is|:|=)\s*[A-Z0-9-]{5,}/i, "a government ID number"],
];

export function detectSecret(text: string): SensitiveHit | null {
  for (const [re, reason] of SECRET_PATTERNS) if (re.test(text)) return { kind: "secret", reason };
  // payment card numbers: 13-19 digits (spaces/dashes allowed) passing the Luhn check
  const cands = text.match(/\b(?:\d[ -]?){13,19}\b/g) ?? [];
  for (const c of cands) {
    const digits = c.replace(/[^\d]/g, "");
    if (digits.length >= 13 && digits.length <= 19 && luhn(digits)) return { kind: "secret", reason: "a payment card number" };
  }
  return null;
}

const SENSITIVE_PATTERNS: [RegExp, string][] = [
  [/\b(diagnos\w*|prescri\w+|medication|antidepress\w*|chemo\w*|cancer|diabet\w*|asthma|epilep\w*|hiv|aids|std|sti|pregnan\w*|miscarriage|depress\w*|anxiety disorder|bipolar|schizo\w*|adhd|autis\w*|ptsd|therapist|therapy|psychiatr\w*|surgery|disabilit\w*|chronic (illness|pain|condition)|mental health|eating disorder|allerg\w*)\b/i, "health information"],
  [/\b(gay|lesbian|bisexual|queer|transgender|sexual orientation|sex life|sexual(ly)? active|my (boy|girl)friend is (a )?(man|woman))\b/i, "sexuality or gender identity"],
  [/\b(muslim|christian|hindu|buddhist|jewish|sikh|atheist|agnostic|religio\w+|my faith|i pray|church|mosque|temple)\b/i, "religion"],
  [/\b(vote[ds]? for|voting for|democrat|republican|liberal party|conservative party|awami league|bnp|jamaat|political (party|views|beliefs)|my politics)\b/i, "political views"],
  [/\b(visa status|immigration|asylum|refugee|green card|citizenship|undocumented|work permit|deport\w*)\b/i, "immigration status"],
  [/\b(arrest\w*|convict\w*|criminal record|felony|jail|prison|sentenced|probation|police case)\b/i, "criminal history"],
  [/\b(my (salary|income|net worth|debt|loan balance|credit score|savings)|i earn|i make \$?\d|in debt|bankrupt\w*|owe [\d$])/i, "financial details"],
  [/\b(abuse[dr]?|assault\w*|rape[d]?|domestic violence|self[- ]harm|suicid\w*|trauma\w*|molest\w*)\b/i, "personal safety information"],
];

export function detectSensitiveCategory(text: string): SensitiveHit | null {
  for (const [re, reason] of SENSITIVE_PATTERNS) if (re.test(text)) return { kind: "sensitive", reason };
  return null;
}

export function checkMemoryContent(text: string, source: "auto" | "explicit" | "manual"): SensitiveHit | null {
  const secret = detectSecret(text);
  if (secret) return secret;
  if (source === "auto") return detectSensitiveCategory(text);
  return null;
}
