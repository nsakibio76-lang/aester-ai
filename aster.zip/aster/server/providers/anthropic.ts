// Anthropic Messages API provider over plain `fetch` + SSE.
//
// NOTE: the brief asked for the official @anthropic-ai/sdk. It could not be installed in the build environment
// (no network for npm). This module talks to the same documented HTTP endpoint (POST /v1/messages, stream:true)
// and is isolated behind `AIProvider`, so swapping in the SDK later only touches this file.

import type { AIProvider, ContentBlock, ProviderEvent, ProviderMessage, ProviderRequest } from "./types.ts";
import { AppError } from "../errors.ts";
import type { Config } from "../config.ts";

const API_VERSION = "2023-06-01";

// ---------- SSE parsing (exported for tests) ----------
export interface SseEvent { event: string; data: string }

export async function* parseSse(body: ReadableStream<Uint8Array>, onActivity?: () => void): AsyncGenerator<SseEvent> {
  const reader = body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      onActivity?.();
      // Normalise line endings across chunk boundaries (a CRLF may be split; a trailing lone CR waits for its LF).
      buf = (buf + dec.decode(value, { stream: true })).replace(/\r\n/g, "\n").replace(/\r(?!$)/g, "\n");
      let idx: number;
      while ((idx = buf.indexOf("\n\n")) !== -1) {
        const raw = buf.slice(0, idx);
        buf = buf.slice(idx + 2);
        const ev = parseBlock(raw);
        if (ev) yield ev;
      }
    }
    buf = (buf + dec.decode()).replace(/\r\n?/g, "\n");
    if (buf.trim()) { const ev = parseBlock(buf); if (ev) yield ev; }
  } finally {
    try { await reader.cancel(); } catch { /* ignore */ }
  }
}

function parseBlock(raw: string): SseEvent | null {
  let event = "message";
  const data: string[] = [];
  for (const line of raw.split("\n")) {
    if (!line || line.startsWith(":")) continue;
    const i = line.indexOf(":");
    const field = i === -1 ? line : line.slice(0, i);
    const val = i === -1 ? "" : line.slice(i + 1).replace(/^ /, "");
    if (field === "event") event = val;
    else if (field === "data") data.push(val);
  }
  return data.length ? { event, data: data.join("\n") } : null;
}

// ---------- error mapping (exported for tests) ----------
export function mapApiError(status: number, type: string | undefined, message: string | undefined, retryAfterMs: number | null): AppError {
  const msg = (message ?? "").toLowerCase();
  if (status === 401 || type === "authentication_error")
    return new AppError("auth", "The Anthropic API rejected the server's API key. Check ANTHROPIC_API_KEY.", { status: 502 });
  if (status === 403 || type === "permission_error")
    return new AppError("permission", "The API key doesn't have permission for this model or feature.", { status: 502 });
  if (status === 404 || type === "not_found_error")
    return new AppError("not_found", "The selected model wasn't found. Pick another model in Settings or fix ASTER_MODEL.", { status: 502 });
  if (status === 413 || (status === 400 && /prompt is too long|too many tokens|context (window|length)|exceed.*(limit|maximum)|request_too_large/.test(msg)) || type === "request_too_large")
    return new AppError("context_too_long", "This conversation is too long for the model. Start a new chat or remove large attachments.", { status: 413 });
  if (status === 400 && /credit balance|billing|payment/.test(msg))
    return new AppError("billing", "The Anthropic account is out of credit. Add credit in the Anthropic Console, then retry.", { status: 502 });
  if (status === 400 || type === "invalid_request_error")
    return new AppError("invalid_request", `The model request was rejected${message ? `: ${message}` : "."}`, { status: 502 });
  if (status === 429 || type === "rate_limit_error")
    return new AppError("rate_limit", "Rate limit reached. Aster will retry automatically; if it keeps failing, wait a minute.", { status: 429, retryable: true, retryAfterMs });
  if (status === 529 || type === "overloaded_error")
    return new AppError("overloaded", "The model is temporarily overloaded. Retrying usually works.", { status: 503, retryable: true, retryAfterMs });
  if (status >= 500)
    return new AppError("server", "The Anthropic API had a server error. Try again shortly.", { status: 502, retryable: true, retryAfterMs });
  return new AppError("server", `Unexpected API response (HTTP ${status}).`, { status: 502 });
}

function toApiBlock(b: ContentBlock): Record<string, unknown> {
  switch (b.type) {
    case "text": return { type: "text", text: b.text };
    case "image": return { type: "image", source: { type: "base64", media_type: b.mediaType, data: b.data } };
    case "document": return { type: "document", source: { type: "base64", media_type: b.mediaType, data: b.data }, ...(b.title ? { title: b.title } : {}) };
    case "tool_use": return { type: "tool_use", id: b.id, name: b.name, input: b.input };
    case "tool_result": return { type: "tool_result", tool_use_id: b.toolUseId, content: b.content, ...(b.isError ? { is_error: true } : {}) };
  }
}
const toApiMessage = (m: ProviderMessage) => ({ role: m.role, content: m.content.map(toApiBlock) });

export function buildRequestBody(req: ProviderRequest): Record<string, unknown> {
  const body: Record<string, unknown> = {
    model: req.model,
    max_tokens: req.maxTokens,
    stream: true,
    system: req.system.map((s) => ({ type: "text", text: s.text, ...(s.cache ? { cache_control: { type: "ephemeral" } } : {}) })),
    messages: req.messages.map(toApiMessage),
  };
  if (req.tools?.length) {
    body.tools = req.tools.map((t) => ({ name: t.name, description: t.description, input_schema: t.inputSchema }));
  }
  return body;
}

export function createAnthropicProvider(cfg: Pick<Config, "apiKey" | "anthropicBaseUrl" | "streamIdleTimeoutMs">): AIProvider {
  return {
    id: "anthropic",
    name: "Anthropic Claude",
    isConfigured: () => !!cfg.apiKey,

    async *stream(req: ProviderRequest, signal: AbortSignal): AsyncGenerator<ProviderEvent> {
      if (!cfg.apiKey) {
        throw new AppError("not_configured", "No Anthropic API key is configured on the server. Set ANTHROPIC_API_KEY in .env and restart Aster.", { status: 503 });
      }
      // idle watchdog: abort if the connection goes silent
      const idle = new AbortController();
      let timer: NodeJS.Timeout | undefined;
      const poke = () => { clearTimeout(timer); timer = setTimeout(() => idle.abort(new Error("idle")), cfg.streamIdleTimeoutMs); };
      const combined = AbortSignal.any([signal, idle.signal]);
      poke();
      try {
        let res: Response;
        try {
          res = await fetch(`${cfg.anthropicBaseUrl}/v1/messages`, {
            method: "POST",
            headers: {
              "content-type": "application/json",
              "x-api-key": cfg.apiKey,
              "anthropic-version": API_VERSION,
              accept: "text/event-stream",
            },
            body: JSON.stringify(buildRequestBody(req)),
            signal: combined,
          });
        } catch (e) {
          throw mapFetchError(e, signal, idle.signal);
        }
        if (!res.ok) {
          let type: string | undefined, message: string | undefined;
          try {
            const j = (await res.json()) as { error?: { type?: string; message?: string } };
            type = j.error?.type; message = j.error?.message;
          } catch { /* non-JSON error body */ }
          const ra = Number(res.headers.get("retry-after"));
          throw mapApiError(res.status, type, message, Number.isFinite(ra) && ra > 0 ? Math.min(ra * 1000, 60000) : null);
        }
        if (!res.body) throw new AppError("network", "The API returned an empty response.", { retryable: true });

        const tools = new Map<number, { id: string; name: string; json: string }>();
        let inputTokens = 0, outputTokens = 0, stopReason = "end_turn";
        try {
          for await (const ev of parseSse(res.body, poke)) {
            let d: any;
            try { d = JSON.parse(ev.data); } catch { continue; }
            switch (d.type) {
              case "message_start":
                inputTokens = (d.message?.usage?.input_tokens ?? 0) + (d.message?.usage?.cache_read_input_tokens ?? 0) + (d.message?.usage?.cache_creation_input_tokens ?? 0);
                outputTokens = d.message?.usage?.output_tokens ?? 0;
                break;
              case "content_block_start":
                if (d.content_block?.type === "tool_use") tools.set(d.index, { id: d.content_block.id, name: d.content_block.name, json: "" });
                break;
              case "content_block_delta":
                if (d.delta?.type === "text_delta" && d.delta.text) yield { type: "text", text: d.delta.text };
                else if (d.delta?.type === "input_json_delta") { const t = tools.get(d.index); if (t) t.json += d.delta.partial_json ?? ""; }
                break;
              case "content_block_stop": {
                const t = tools.get(d.index);
                if (t) {
                  let input: Record<string, unknown> = {};
                  try { input = t.json.trim() ? JSON.parse(t.json) : {}; } catch { input = { _parse_error: true }; }
                  tools.delete(d.index);
                  yield { type: "tool_use", id: t.id, name: t.name, input };
                }
                break;
              }
              case "message_delta":
                if (d.delta?.stop_reason) stopReason = d.delta.stop_reason;
                if (d.usage?.output_tokens !== undefined) outputTokens = d.usage.output_tokens;
                if (d.usage?.input_tokens !== undefined) inputTokens = d.usage.input_tokens || inputTokens;
                break;
              case "error":
                throw mapApiError(d.error?.type === "overloaded_error" ? 529 : d.error?.type === "rate_limit_error" ? 429 : 500, d.error?.type, d.error?.message, null);
              default: break; // ping, message_stop, thinking deltas, etc.
            }
          }
        } catch (e) {
          if (e instanceof AppError) throw e;
          throw mapFetchError(e, signal, idle.signal);
        }
        yield { type: "end", stopReason, usage: { inputTokens, outputTokens } };
      } finally {
        clearTimeout(timer);
      }
    },
  };
}

function mapFetchError(e: unknown, user: AbortSignal, idle: AbortSignal): AppError {
  if (user.aborted) return new AppError("aborted", "Generation stopped.", { status: 499 });
  if (idle.aborted) return new AppError("timeout", "The model stopped responding (timed out). Try again.", { status: 504, retryable: true });
  if (e instanceof AppError) return e;
  return new AppError("network", "Couldn't reach the Anthropic API. Check the server's internet connection.", { status: 502, retryable: true });
}
