// Provider-agnostic contract. To add another AI vendor, implement `AIProvider` and register it in providers/index.ts;
// nothing else in the app knows which vendor is in use.

export type ContentBlock =
  | { type: "text"; text: string }
  | { type: "image"; mediaType: string; data: string /* base64 */ }
  | { type: "document"; mediaType: "application/pdf"; data: string /* base64 */; title?: string }
  | { type: "tool_use"; id: string; name: string; input: Record<string, unknown> }
  | { type: "tool_result"; toolUseId: string; content: string; isError?: boolean };

export interface ProviderMessage { role: "user" | "assistant"; content: ContentBlock[] }

export interface ToolDef { name: string; description: string; inputSchema: Record<string, unknown> }

export interface SystemBlock { text: string; cache?: boolean }

export interface ProviderRequest {
  model: string;
  system: SystemBlock[];
  messages: ProviderMessage[];
  tools?: ToolDef[];
  maxTokens: number;
}

export interface Usage { inputTokens: number; outputTokens: number }

export type ProviderEvent =
  | { type: "text"; text: string }
  | { type: "tool_use"; id: string; name: string; input: Record<string, unknown> }
  | { type: "end"; stopReason: string; usage: Usage };

export interface AIProvider {
  readonly id: string;
  readonly name: string;
  isConfigured(): boolean;
  /** Stream a model turn. Throws AppError (with a stable `code`) on failure. */
  stream(req: ProviderRequest, signal: AbortSignal): AsyncGenerator<ProviderEvent>;
}

/** Convenience: run a request to completion and return the text (used for titles). */
export async function completeText(p: AIProvider, req: ProviderRequest, signal: AbortSignal): Promise<{ text: string; usage: Usage }> {
  let text = "";
  let usage: Usage = { inputTokens: 0, outputTokens: 0 };
  for await (const ev of p.stream(req, signal)) {
    if (ev.type === "text") text += ev.text;
    else if (ev.type === "end") usage = ev.usage;
  }
  return { text, usage };
}
