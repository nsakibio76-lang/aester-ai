import type { Config } from "../config.ts";
import type { AIProvider } from "./types.ts";
import { createAnthropicProvider } from "./anthropic.ts";

/** Registry of provider factories. Add new vendors here (e.g. "openai") and select with ASTER_PROVIDER. */
const FACTORIES: Record<string, (cfg: Config) => AIProvider> = {
  anthropic: createAnthropicProvider,
};

export function createProvider(cfg: Config): AIProvider {
  const f = FACTORIES[cfg.provider];
  if (!f) throw new Error(`Unknown ASTER_PROVIDER "${cfg.provider}". Available: ${Object.keys(FACTORIES).join(", ")}`);
  return f(cfg);
}

export type { AIProvider } from "./types.ts";
