// Safe math evaluator used as the `calculate` tool. No eval(): a hand-written parser with
// exact rational arithmetic (BigInt) for + - * / and integer powers, falling back to floats
// for transcendental functions. Limits on input size, recursion and result size keep it cheap and safe.

export class CalcError extends Error {}

type Q = { t: "q"; n: bigint; d: bigint };
type F = { t: "f"; v: number };
type Val = Q | F;

const MAX_EXPR = 500;
const MAX_DEPTH = 60;
const MAX_BITS = 200_000;

const big = (n: number | bigint): bigint => BigInt(n);
const absB = (a: bigint): bigint => (a < 0n ? -a : a);
function gcdB(a: bigint, b: bigint): bigint {
  a = absB(a); b = absB(b);
  while (b) [a, b] = [b, a % b];
  return a;
}
const bits = (a: bigint): number => absB(a).toString(2).length;

function q(n: bigint, d: bigint = 1n): Q {
  if (d === 0n) throw new CalcError("division by zero");
  if (d < 0n) { n = -n; d = -d; }
  const g = gcdB(n, d) || 1n;
  return { t: "q", n: n / g, d: d / g };
}
const f = (v: number): F => ({ t: "f", v });
const isInt = (a: Val): a is Q => a.t === "q" && a.d === 1n;

function qToFloat(a: Q): number {
  const nn = Number(a.n), dd = Number(a.d);
  if (Number.isFinite(nn) && Number.isFinite(dd)) return nn / dd;
  const shift = Math.max(bits(a.n), bits(a.d)) - 1000;
  return Number(a.n >> big(shift)) / Number(a.d >> big(shift));
}
const toF = (a: Val): number => (a.t === "f" ? a.v : qToFloat(a));

function fin(v: number): F {
  if (Number.isNaN(v)) throw new CalcError("result is undefined (or not a real number)");
  if (!Number.isFinite(v)) throw new CalcError("result is too large or infinite");
  return f(v);
}

function decimalToQ(s: string): Q {
  const m = /^(\d*)(?:\.(\d*))?(?:[eE]([+-]?\d+))?$/.exec(s);
  if (!m) throw new CalcError(`bad number "${s}"`);
  const [, ip = "", fp = "", ex = "0"] = m;
  let n = BigInt((ip + fp) || "0");
  let e = Number(ex) - fp.length;
  if (Math.abs(e) > 400) throw new CalcError("exponent too large");
  if (e >= 0) n *= 10n ** big(e);
  return q(n, e < 0 ? 10n ** big(-e) : 1n);
}

function iroot(n: bigint, k: number): bigint | null {
  if (n < 0n) return null;
  if (n < 2n) return n;
  let lo = 0n, hi = 1n << big(Math.ceil(bits(n) / k) + 1);
  const K = big(k);
  while (lo < hi) {
    const mid = (lo + hi + 1n) >> 1n;
    if (mid ** K <= n) lo = mid; else hi = mid - 1n;
  }
  return lo ** K === n ? lo : null;
}

function add(a: Val, b: Val): Val { return a.t === "q" && b.t === "q" ? q(a.n * b.d + b.n * a.d, a.d * b.d) : fin(toF(a) + toF(b)); }
function sub(a: Val, b: Val): Val { return a.t === "q" && b.t === "q" ? q(a.n * b.d - b.n * a.d, a.d * b.d) : fin(toF(a) - toF(b)); }
function mul(a: Val, b: Val): Val { return a.t === "q" && b.t === "q" ? q(a.n * b.n, a.d * b.d) : fin(toF(a) * toF(b)); }
function div(a: Val, b: Val): Val {
  if (b.t === "q" && b.n === 0n) throw new CalcError("division by zero");
  if (b.t === "f" && b.v === 0) throw new CalcError("division by zero");
  return a.t === "q" && b.t === "q" ? q(a.n * b.d, a.d * b.n) : fin(toF(a) / toF(b));
}
const neg = (a: Val): Val => (a.t === "q" ? q(-a.n, a.d) : f(-a.v));

function pow(a: Val, b: Val): Val {
  if (a.t === "q" && b.t === "q") {
    if (b.d === 1n) {
      const e = Number(b.n);
      if (a.n === 0n && e < 0) throw new CalcError("0 cannot be raised to a negative power");
      const ae = Math.abs(e);
      if (Number.isSafeInteger(e) && (bits(a.n) + bits(a.d)) * ae <= MAX_BITS) {
        const r = q(a.n ** big(ae), a.d ** big(ae));
        return e >= 0 ? r : q(r.d, r.n);
      }
    } else if (a.n >= 0n && b.d <= 12n) {
      // exact root when it exists, e.g. 8^(1/3), 4^(3/2)
      const k = Number(b.d);
      const rn = iroot(a.n, k), rd = iroot(a.d, k);
      if (rn !== null && rd !== null && Math.abs(Number(b.n)) <= 200) {
        const base = q(rn, rd);
        return pow(base, q(b.n));
      }
    }
  }
  const base = toF(a), ex = toF(b);
  if (base < 0 && !Number.isInteger(ex)) throw new CalcError("complex result (negative base with fractional exponent) is not supported");
  return fin(Math.pow(base, ex));
}

function requireInt(a: Val, what: string): bigint {
  if (!isInt(a)) throw new CalcError(`${what} needs an integer`);
  return a.n;
}

function modulo(a: Val, b: Val): Val {
  if (isInt(a) && isInt(b)) {
    if (b.n === 0n) throw new CalcError("modulo by zero");
    return q(((a.n % b.n) + b.n) % b.n);
  }
  const x = toF(a), y = toF(b);
  if (y === 0) throw new CalcError("modulo by zero");
  return fin(x - y * Math.floor(x / y));
}

function factorial(a: Val): Val {
  const n = requireInt(a, "factorial");
  if (n < 0n || n > 1000n) throw new CalcError("factorial is limited to 0..1000");
  let r = 1n;
  for (let i = 2n; i <= n; i++) r *= i;
  return q(r);
}

function binom(n: bigint, k: bigint): bigint {
  if (k < 0n || n < 0n || k > n) return 0n;
  if (n > 100000n) throw new CalcError("binomial arguments too large");
  if (k > n - k) k = n - k;
  let r = 1n;
  for (let i = 1n; i <= k; i++) r = (r * (n - k + i)) / i;
  return r;
}

const trigClean = (v: number): Val => f(Math.abs(v) < 1e-14 ? 0 : v);
const DEG = Math.PI / 180;

type Fn = (args: Val[]) => Val;
const nums = (args: Val[], min: number, name: string): number[] => {
  if (args.length < min) throw new CalcError(`${name} needs at least ${min} value(s)`);
  return args.map(toF);
};
const arity = (name: string, n: number, args: Val[]): void => {
  if (args.length !== n) throw new CalcError(`${name} expects ${n} argument${n === 1 ? "" : "s"}`);
};
const f1 = (name: string, fn: (x: number) => number): Fn => (a) => { arity(name, 1, a); return fin(fn(toF(a[0]!))); };

const FUNCS: Record<string, Fn> = {
  sqrt: (a) => { arity("sqrt", 1, a); const x = a[0]!; if (toF(x) < 0) throw new CalcError("square root of a negative number is not real"); return pow(x, q(1n, 2n)); },
  cbrt: (a) => { arity("cbrt", 1, a); return a[0]!.t === "q" ? pow(a[0]!, q(1n, 3n)) : f(Math.cbrt(toF(a[0]!))); },
  abs: (a) => { arity("abs", 1, a); const x = a[0]!; return x.t === "q" ? q(absB(x.n), x.d) : f(Math.abs(x.v)); },
  sign: (a) => { arity("sign", 1, a); return q(big(Math.sign(toF(a[0]!)))); },
  sin: (a) => { arity("sin", 1, a); return trigClean(Math.sin(toF(a[0]!))); },
  cos: (a) => { arity("cos", 1, a); return trigClean(Math.cos(toF(a[0]!))); },
  tan: (a) => { arity("tan", 1, a); const x = toF(a[0]!); if (Math.abs(Math.cos(x)) < 1e-15) throw new CalcError("tan is undefined here"); return trigClean(Math.tan(x)); },
  sind: (a) => { arity("sind", 1, a); return trigClean(Math.sin(toF(a[0]!) * DEG)); },
  cosd: (a) => { arity("cosd", 1, a); return trigClean(Math.cos(toF(a[0]!) * DEG)); },
  tand: (a) => { arity("tand", 1, a); const x = toF(a[0]!) * DEG; if (Math.abs(Math.cos(x)) < 1e-15) throw new CalcError("tan is undefined here"); return trigClean(Math.tan(x)); },
  asin: f1("asin", Math.asin), acos: f1("acos", Math.acos), atan: f1("atan", Math.atan),
  asind: (a) => { arity("asind", 1, a); return fin(Math.asin(toF(a[0]!)) / DEG); },
  acosd: (a) => { arity("acosd", 1, a); return fin(Math.acos(toF(a[0]!)) / DEG); },
  atand: (a) => { arity("atand", 1, a); return fin(Math.atan(toF(a[0]!)) / DEG); },
  atan2: (a) => { arity("atan2", 2, a); return fin(Math.atan2(toF(a[0]!), toF(a[1]!))); },
  sinh: f1("sinh", Math.sinh), cosh: f1("cosh", Math.cosh), tanh: f1("tanh", Math.tanh),
  exp: f1("exp", Math.exp),
  ln: (a) => { arity("ln", 1, a); if (toF(a[0]!) <= 0) throw new CalcError("ln needs a positive number"); return fin(Math.log(toF(a[0]!))); },
  log: (a) => {
    if (a.length < 1 || a.length > 2) throw new CalcError("log expects log(x) or log(x, base)");
    const x = toF(a[0]!); const b = a.length === 2 ? toF(a[1]!) : 10;
    if (x <= 0 || b <= 0 || b === 1) throw new CalcError("log needs a positive argument and a valid base");
    return fin(Math.log(x) / Math.log(b));
  },
  log2: (a) => { arity("log2", 1, a); if (toF(a[0]!) <= 0) throw new CalcError("log2 needs a positive number"); return fin(Math.log2(toF(a[0]!))); },
  log10: (a) => { arity("log10", 1, a); if (toF(a[0]!) <= 0) throw new CalcError("log10 needs a positive number"); return fin(Math.log10(toF(a[0]!))); },
  floor: (a) => { arity("floor", 1, a); const x = a[0]!; return x.t === "q" ? q((x.n - (((x.n % x.d) + x.d) % x.d)) / x.d) : f(Math.floor(x.v)); },
  ceil: (a) => { arity("ceil", 1, a); const x = a[0]!; if (x.t === "f") return f(Math.ceil(x.v)); const fl = (x.n - (((x.n % x.d) + x.d) % x.d)) / x.d; return q(x.n % x.d === 0n ? fl : fl + 1n); },
  round: (a) => { arity("round", 1, a); return f(Math.round(toF(a[0]!))); },
  min: (a) => { nums(a, 1, "min"); return a.reduce((m, x) => (toF(x) < toF(m) ? x : m)); },
  max: (a) => { nums(a, 1, "max"); return a.reduce((m, x) => (toF(x) > toF(m) ? x : m)); },
  sum: (a) => { nums(a, 1, "sum"); return a.reduce((s, x) => add(s, x), q(0n)); },
  product: (a) => { nums(a, 1, "product"); return a.reduce((s, x) => mul(s, x), q(1n)); },
  mean: (a) => { nums(a, 1, "mean"); return div(a.reduce((s, x) => add(s, x), q(0n)), q(big(a.length))); },
  median: (a) => {
    nums(a, 1, "median");
    const s = [...a].sort((x, y) => toF(x) - toF(y));
    const m = s.length >> 1;
    return s.length % 2 ? s[m]! : div(add(s[m - 1]!, s[m]!), q(2n));
  },
  var: (a) => { const x = nums(a, 2, "var"); const m = x.reduce((s, v) => s + v, 0) / x.length; return fin(x.reduce((s, v) => s + (v - m) ** 2, 0) / (x.length - 1)); },
  varp: (a) => { const x = nums(a, 1, "varp"); const m = x.reduce((s, v) => s + v, 0) / x.length; return fin(x.reduce((s, v) => s + (v - m) ** 2, 0) / x.length); },
  stdev: (a) => { const x = nums(a, 2, "stdev"); const m = x.reduce((s, v) => s + v, 0) / x.length; return fin(Math.sqrt(x.reduce((s, v) => s + (v - m) ** 2, 0) / (x.length - 1))); },
  stdevp: (a) => { const x = nums(a, 1, "stdevp"); const m = x.reduce((s, v) => s + v, 0) / x.length; return fin(Math.sqrt(x.reduce((s, v) => s + (v - m) ** 2, 0) / x.length)); },
  gcd: (a) => { if (a.length < 2) throw new CalcError("gcd needs at least 2 integers"); return q(a.map((x) => requireInt(x, "gcd")).reduce((g, x) => gcdB(g, x))); },
  lcm: (a) => {
    if (a.length < 2) throw new CalcError("lcm needs at least 2 integers");
    return q(a.map((x) => requireInt(x, "lcm")).reduce((l, x) => (l === 0n || x === 0n ? 0n : absB(l * x) / gcdB(l, x))));
  },
  mod: (a) => { arity("mod", 2, a); return modulo(a[0]!, a[1]!); },
  pow: (a) => { arity("pow", 2, a); return pow(a[0]!, a[1]!); },
  factorial: (a) => { arity("factorial", 1, a); return factorial(a[0]!); },
  binom: (a) => { arity("binom", 2, a); return q(binom(requireInt(a[0]!, "binom"), requireInt(a[1]!, "binom"))); },
  ncr: (a) => FUNCS.binom!(a),
  npr: (a) => {
    arity("npr", 2, a);
    const n = requireInt(a[0]!, "nPr"), k = requireInt(a[1]!, "nPr");
    if (k < 0n || k > n) return q(0n);
    if (n > 100000n) throw new CalcError("nPr arguments too large");
    let r = 1n; for (let i = 0n; i < k; i++) r *= n - i;
    return q(r);
  },
  deg: (a) => { arity("deg", 1, a); return fin(toF(a[0]!) / DEG); },
  rad: (a) => { arity("rad", 1, a); return fin(toF(a[0]!) * DEG); },
};

const CONSTS: Record<string, number> = { pi: Math.PI, e: Math.E, tau: 2 * Math.PI, phi: (1 + Math.sqrt(5)) / 2 };

// ---------- tokenizer ----------
type Tok = { k: "num" | "id" | "op"; v: string };
function tokenize(src: string): Tok[] {
  const s = src
    .replace(/[×·⋅]/g, "*").replace(/÷/g, "/").replace(/[−–]/g, "-").replace(/π/g, " pi ").replace(/²/g, "^2").replace(/³/g, "^3");
  const out: Tok[] = [];
  let i = 0;
  while (i < s.length) {
    const c = s[i]!;
    if (/\s/.test(c)) { i++; continue; }
    if (/[0-9.]/.test(c)) {
      const m = /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(s.slice(i));
      if (!m) throw new CalcError(`bad number near "${s.slice(i, i + 8)}"`);
      out.push({ k: "num", v: m[0] }); i += m[0].length; continue;
    }
    if (/[A-Za-z_]/.test(c)) {
      const m = /^[A-Za-z_][A-Za-z0-9_]*/.exec(s.slice(i))!;
      out.push({ k: "id", v: m[0].toLowerCase() }); i += m[0].length; continue;
    }
    if (c === "*" && s[i + 1] === "*") { out.push({ k: "op", v: "^" }); i += 2; continue; }
    if (c === "√") { out.push({ k: "id", v: "sqrt" }); i++; continue; }
    if ("+-*/^%!(),".includes(c)) { out.push({ k: "op", v: c }); i++; continue; }
    throw new CalcError(`unexpected character "${c}"`);
  }
  return out;
}

// ---------- parser/evaluator ----------
class Parser {
  toks: Tok[];
  p = 0;
  depth = 0;
  constructor(toks: Tok[]) { this.toks = toks; }
  peek(): Tok | undefined { return this.toks[this.p]; }
  isOp(v: string): boolean { const t = this.peek(); return !!t && t.k === "op" && t.v === v; }
  eat(v: string): void { if (!this.isOp(v)) throw new CalcError(`expected "${v}"`); this.p++; }
  enter(): void { if (++this.depth > MAX_DEPTH) throw new CalcError("expression is nested too deeply"); }
  leave(): void { this.depth--; }

  parse(): Val {
    const v = this.expr();
    if (this.p < this.toks.length) throw new CalcError(`unexpected "${this.peek()!.v}"`);
    return v;
  }
  expr(): Val {
    this.enter();
    let v = this.term();
    while (this.isOp("+") || this.isOp("-")) {
      const op = this.toks[this.p++]!.v;
      const r = this.term();
      v = op === "+" ? add(v, r) : sub(v, r);
    }
    this.leave();
    return v;
  }
  term(): Val {
    let v = this.unary();
    for (;;) {
      const t = this.peek();
      if (!t) break;
      if (t.k === "op" && (t.v === "*" || t.v === "/" || t.v === "%")) {
        this.p++;
        const r = this.unary();
        v = t.v === "*" ? mul(v, r) : t.v === "/" ? div(v, r) : modulo(v, r);
      } else if (t.k === "num" || t.k === "id" || (t.k === "op" && t.v === "(")) {
        v = mul(v, this.unary()); // implicit multiplication: 2(3), 3pi, 2sqrt(4)
      } else break;
    }
    return v;
  }
  unary(): Val {
    if (this.isOp("-")) { this.p++; this.enter(); const v = neg(this.unary()); this.leave(); return v; }
    if (this.isOp("+")) { this.p++; return this.unary(); }
    return this.power();
  }
  power(): Val {
    const base = this.postfix();
    if (this.isOp("^")) {
      this.p++;
      this.enter();
      const ex = this.unary(); // right-associative, allows 2^-3
      this.leave();
      return pow(base, ex);
    }
    return base;
  }
  postfix(): Val {
    let v = this.primary();
    while (this.isOp("!")) { this.p++; v = factorial(v); }
    return v;
  }
  primary(): Val {
    const t = this.peek();
    if (!t) throw new CalcError("expression ended unexpectedly");
    if (t.k === "num") { this.p++; return decimalToQ(t.v); }
    if (t.k === "id") {
      this.p++;
      const fn = FUNCS[t.v];
      if (fn && this.isOp("(")) {
        this.eat("(");
        const args: Val[] = [];
        if (!this.isOp(")")) {
          for (;;) { args.push(this.expr()); if (this.isOp(",")) { this.p++; continue; } break; }
        }
        this.eat(")");
        return fn(args);
      }
      if (fn) { // function applied without parentheses, e.g. "sqrt 16" or "√16"
        return fn([this.unaryNoImplicit()]);
      }
      if (t.v in CONSTS) return f(CONSTS[t.v]!);
      throw new CalcError(`unknown name "${t.v}" (variables are not supported; substitute numbers)`);
    }
    if (t.v === "(") {
      this.p++;
      const v = this.expr();
      this.eat(")");
      return v;
    }
    throw new CalcError(`unexpected "${t.v}"`);
  }
  unaryNoImplicit(): Val {
    if (this.isOp("-")) { this.p++; return neg(this.unaryNoImplicit()); }
    return this.postfix();
  }
}

// ---------- formatting ----------
function fmtFloat(v: number): string {
  if (v === 0) return "0";
  const abs = Math.abs(v);
  if (abs >= 1e21 || abs < 1e-6) return v.toExponential(12).replace(/\.?0+e/, "e");
  return String(Number(v.toPrecision(15)));
}

function fmtQ(a: Q): string {
  if (a.d === 1n) {
    const s = a.n.toString();
    return s.length > 60 ? `${s.slice(0, 20)}…${s.slice(-10)} (${s.length - (a.n < 0n ? 1 : 0)} digits, ≈ ${fmtFloat(qToFloat(a))})` : s;
  }
  return `${a.n}/${a.d} ≈ ${fmtFloat(qToFloat(a))}`;
}

export interface CalcResult { text: string; exact: boolean }

export function calculate(expression: string): CalcResult {
  if (typeof expression !== "string" || !expression.trim()) throw new CalcError("empty expression");
  if (expression.length > MAX_EXPR) throw new CalcError(`expression is too long (max ${MAX_EXPR} characters)`);
  const val = new Parser(tokenize(expression)).parse();
  return val.t === "q" ? { text: fmtQ(val), exact: true } : { text: fmtFloat(val.v), exact: false };
}
