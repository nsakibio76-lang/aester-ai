// Tools the model may call during a turn. Every tool is executed on the server; results go back to the model
// and a short summary is shown to the user as a chip under the message.

import type { ToolDef } from "../providers/types.ts";
import type { MemoryService } from "../memory/service.ts";
import { isCategory } from "../memory/service.ts";
import type { ConversationRepo } from "../repo/conversations.ts";
import type { Conversation, Memory } from "../repo/types.ts";
import { CATEGORIES } from "../repo/types.ts";
import { AppError } from "../errors.ts";
import { calculate, CalcError } from "./calculator.ts";
import { truncate } from "../util.ts";

export interface ToolContext {
  conversationId: string;
  memoryEnabled: boolean;
  autoMemory: boolean;
  memory: MemoryService;
  conversations: ConversationRepo;
  onMemory(action: "added" | "updated" | "deleted", memory: Memory): void;
  onConversation(c: Conversation): void;
}

export interface ToolOutcome { content: string; isError: boolean; summary: string }

const CAT = [...CATEGORIES];

export function toolDefs(memoryEnabled: boolean): ToolDef[] {
  const defs: ToolDef[] = [{
    name: "calculate",
    description:
      "Evaluate a numeric math expression exactly and return the result. Use it to verify arithmetic, evaluate numeric answers, check a solution by substitution, " +
      "compute statistics, factorials, binomials, gcd/lcm, powers and roots. Supports + - * / ^ % !, parentheses, constants (pi, e, tau, phi) and functions: " +
      "sqrt cbrt abs sin cos tan (radians) sind cosd tand (degrees) asin acos atan atan2 sinh cosh tanh exp ln log(x[,base]) log2 log10 floor ceil round min max sum product " +
      "mean median var varp stdev stdevp gcd lcm mod pow factorial binom npr deg rad. Rational results are returned exactly as fractions. No symbolic variables: substitute numbers.",
    inputSchema: { type: "object", properties: { expression: { type: "string", description: "e.g. '(3+4)^2/7' or 'binom(10,3)' or 'sqrt(2)*sind(45)'" } }, required: ["expression"] },
  }];
  if (memoryEnabled) {
    defs.push(
      {
        name: "memory_save",
        description:
          "Save one durable fact about the user to long-term memory (a short, self-contained sentence in third person, e.g. 'Studies for the HSC exam in 2027'). " +
          "Set explicit=true ONLY when the user directly asked you to remember it. Never save secrets, temporary details, or sensitive categories unless explicitly asked.",
        inputSchema: {
          type: "object",
          properties: {
            content: { type: "string", description: "One concise fact, max 500 characters." },
            category: { type: "string", enum: CAT },
            explicit: { type: "boolean", description: "true if the user explicitly asked to remember this." },
          },
          required: ["content", "category", "explicit"],
        },
      },
      {
        name: "memory_update",
        description: "Replace the text (and optionally category) of an existing memory, by id. Use when information changed or was wrong.",
        inputSchema: { type: "object", properties: { id: { type: "string" }, content: { type: "string" }, category: { type: "string", enum: CAT } }, required: ["id", "content"] },
      },
      {
        name: "memory_forget",
        description: "Delete memories the user asked to forget. Prefer `id` (from the memory list); otherwise give distinctive `query` words that all appear in the memory.",
        inputSchema: { type: "object", properties: { id: { type: "string" }, query: { type: "string" } } },
      },
      {
        name: "memory_list",
        description: "List everything stored in long-term memory (with ids). Call this when the user asks what you remember about them, or before updating/forgetting.",
        inputSchema: { type: "object", properties: { category: { type: "string", enum: CAT } } },
      },
      {
        name: "conversation_memory",
        description:
          "Turn long-term memory on or off for THIS conversation. Call with enabled=false when the user says things like 'don't remember this conversation', 'keep this private' or 'off the record'. " +
          "While off, nothing from this chat is saved and stored memories are not used.",
        inputSchema: { type: "object", properties: { enabled: { type: "boolean" } }, required: ["enabled"] },
      },
    );
  }
  return defs;
}

const ok = (content: string, summary: string): ToolOutcome => ({ content, isError: false, summary });
const fail = (content: string, summary: string): ToolOutcome => ({ content, isError: true, summary });
const str = (v: unknown): string => (typeof v === "string" ? v : "");

export function runTool(name: string, input: Record<string, unknown>, ctx: ToolContext): ToolOutcome {
  try {
    if (input._parse_error) return fail("The tool input was not valid JSON. Try again.", "Invalid tool input");
    switch (name) {
      case "calculate": {
        const expr = str(input.expression);
        try {
          const r = calculate(expr);
          return ok(r.text, truncate(`${expr.trim()} = ${r.text}`, 140));
        } catch (e) {
          if (e instanceof CalcError) return fail(`Could not evaluate: ${e.message}`, truncate(`${expr.trim()} → ${e.message}`, 140));
          throw e;
        }
      }
      case "memory_save": {
        if (!ctx.memoryEnabled) return fail("Memory is turned off for this conversation. Nothing was saved.", "Memory is off");
        const explicit = input.explicit === true;
        if (!ctx.autoMemory && !explicit)
          return fail("Automatic memory is switched off. Only save when the user explicitly asks you to remember something (explicit=true). Nothing was saved.", "Skipped (auto-memory is off)");
        const r = ctx.memory.save({ content: input.content, category: input.category, source: explicit ? "explicit" : "auto", conversationId: ctx.conversationId });
        ctx.onMemory(r.action, r.memory);
        return ok(`${r.action === "added" ? "Saved" : "Updated existing memory"} (id ${r.memory.id}): ${r.memory.content}`, truncate(`${r.action === "added" ? "Saved" : "Updated"}: ${r.memory.content}`, 140));
      }
      case "memory_update": {
        if (!ctx.memoryEnabled) return fail("Memory is turned off for this conversation.", "Memory is off");
        const cat = input.category === undefined ? undefined : isCategory(input.category) ? input.category : "invalid";
        if (cat === "invalid") return fail("Unknown category.", "Unknown category");
        const m = ctx.memory.update(str(input.id), { content: input.content, category: cat }, "explicit");
        if (!m) return fail("No memory with that id exists. Call memory_list to see ids.", "Memory not found");
        ctx.onMemory("updated", m);
        return ok(`Updated memory ${m.id}: ${m.content}`, truncate(`Updated: ${m.content}`, 140));
      }
      case "memory_forget": {
        if (!ctx.memoryEnabled) return fail("Memory is turned off for this conversation.", "Memory is off");
        const r = ctx.memory.forget({ id: str(input.id) || undefined, query: str(input.query) || undefined });
        if (r.deleted.length) {
          for (const m of r.deleted) ctx.onMemory("deleted", m);
          return ok(`Deleted ${r.deleted.length} memor${r.deleted.length === 1 ? "y" : "ies"}: ${r.deleted.map((m) => m.content).join(" | ")}`, truncate(`Forgot: ${r.deleted.map((m) => m.content).join("; ")}`, 140));
        }
        if (r.ambiguous.length)
          return fail(`That matches ${r.ambiguous.length}+ memories, so nothing was deleted. Ask the user which, then call again with an id:\n` + r.ambiguous.map((m) => `- ${m.id}: ${m.content}`).join("\n"), "Needs a more specific request");
        return fail("No matching memory was found. Nothing was deleted.", "No matching memory");
      }
      case "memory_list": {
        if (!ctx.memoryEnabled) return fail("Memory is turned off for this conversation.", "Memory is off");
        const cat = str(input.category);
        const all = ctx.memory.list(cat && isCategory(cat) ? { category: cat } : {}).slice(0, 200);
        if (!all.length) return ok("Long-term memory is empty.", "Memory is empty");
        return ok(all.map((m) => `- (id ${m.id}) [${m.category}] ${m.content} — saved ${m.createdAt.slice(0, 10)}, updated ${m.updatedAt.slice(0, 10)}`).join("\n"), `Read ${all.length} memor${all.length === 1 ? "y" : "ies"}`);
      }
      case "conversation_memory": {
        const enabled = input.enabled === true;
        const c = ctx.conversations.update(ctx.conversationId, { memoryEnabled: enabled });
        ctx.memoryEnabled = enabled;
        ctx.onConversation(c);
        return ok(enabled ? "Memory is now ON for this conversation." : "Memory is now OFF for this conversation: nothing from it will be saved and stored memories won't be used from here on.", enabled ? "Memory on for this chat" : "Memory off for this chat");
      }
      default:
        return fail(`Unknown tool "${name}".`, "Unknown tool");
    }
  } catch (e) {
    if (e instanceof AppError) return fail(`Not saved: ${e.message}`, truncate(e.message, 140));
    throw e;
  }
}
