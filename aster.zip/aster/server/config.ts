// Configuration comes exclusively from environment variables (optionally loaded from .env by index.ts).
// The Anthropic key never leaves the server. NOTE: we deliberately do NOT read the generic
// ANTHROPIC_BASE_URL variable, so a stray proxy setting can never receive your key; use ASTER_ANTHROPIC_BASE_URL.

import path from "node:path";

export interface ModelOption { id: string; label: string }

export interface Config {
  appName: string;
  version: string;
  host: string;
  port: number;
  dataDir: string;
  dbPath: string;
  publicDir: string;
  password: string | null;
  cookieSecure: boolean;
  allowedHosts: string[];
  provider: string;
  apiKey: string | null;
  anthropicBaseUrl: string;
  defaultModel: string;
  titleModel: string;
  models: ModelOption[];
  maxMessageChars: number;
  maxAttachments: number;
  maxImageBytes: number;
  maxPdfBytes: number;
  maxTextBytes: number;
  maxContextTokens: number;
  maxOutputTokens: number;
  maxMemories: number;
  chatRatePerMinute: number;
  retryBaseMs: number;
  maxRetries: number;
  streamIdleTimeoutMs: number;
  sessionTtlMs: number;
}

export const IMAGE_TYPES = ["image/png", "image/jpeg", "image/gif", "image/webp"];
export const TEXT_EXTENSIONS = [
  ".txt", ".md", ".markdown", ".csv", ".tsv", ".json", ".xml", ".yaml", ".yml", ".toml", ".ini", ".log", ".tex",
  ".py", ".js", ".mjs", ".ts", ".tsx", ".jsx", ".java", ".c", ".h", ".cpp", ".hpp", ".cs", ".go", ".rs", ".rb",
  ".php", ".sh", ".sql", ".html", ".css", ".r", ".m", ".kt", ".swift",
];

const DEFAULT_MODELS: ModelOption[] = [
  { id: "claude-sonnet-5-5", label: "Sonnet 5.5 (balanced)" },
  { id: "claude-opus-5-5", label: "Opus 5.5 (most capable)" },
  { id: "claude-haiku-5-5", label: "Haiku 5.5 (fastest)" },
];

function int(env: Record<string, string | undefined>, key: string, dflt: number, min = 0, max = Number.MAX_SAFE_INTEGER): number {
  const raw = env[key];
  if (raw === undefined || raw.trim() === "") return dflt;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) {
    throw new Error(`Invalid ${key}="${raw}": expected an integer between ${min} and ${max}.`);
  }
  return n;
}

function parseModels(raw: string | undefined): ModelOption[] {
  if (!raw || !raw.trim()) return DEFAULT_MODELS;
  const out: ModelOption[] = [];
  for (const part of raw.split(",")) {
    const [id, ...rest] = part.split(":");
    const mid = (id ?? "").trim();
    if (!mid) continue;
    out.push({ id: mid, label: rest.join(":").trim() || mid });
  }
  return out.length ? out : DEFAULT_MODELS;
}

export function isLoopbackHost(h: string): boolean {
  return h === "127.0.0.1" || h === "localhost" || h === "::1" || h === "[::1]";
}

export function loadConfig(env: Record<string, string | undefined> = process.env, root = process.cwd()): Config {
  const host = (env.ASTER_HOST || "127.0.0.1").trim();
  const password = env.ASTER_PASSWORD && env.ASTER_PASSWORD.length > 0 ? env.ASTER_PASSWORD : null;
  if (password !== null && password.length < 8) {
    throw new Error("ASTER_PASSWORD must be at least 8 characters.");
  }
  if (!isLoopbackHost(host) && password === null && env.ASTER_ALLOW_INSECURE_NETWORK !== "1") {
    throw new Error(
      `Refusing to listen on ${host} without a password. Set ASTER_PASSWORD (8+ chars), ` +
      `or bind to 127.0.0.1. (Override: ASTER_ALLOW_INSECURE_NETWORK=1 — not recommended.)`,
    );
  }
  const dataDir = path.resolve(root, env.ASTER_DATA_DIR || "data");
  const defaultModel = (env.ASTER_MODEL || DEFAULT_MODELS[0]!.id).trim();
  const models = parseModels(env.ASTER_MODELS);
  if (!models.some((m) => m.id === defaultModel)) models.unshift({ id: defaultModel, label: defaultModel });
  const port = int(env, "ASTER_PORT", 3000, 0, 65535);
  const extraHosts = (env.ASTER_ALLOWED_HOSTS || "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
  return {
    appName: "Aster",
    version: "1.0.0",
    host,
    port,
    dataDir,
    dbPath: env.ASTER_DB_PATH ? path.resolve(root, env.ASTER_DB_PATH) : path.join(dataDir, "aster.db"),
    publicDir: path.resolve(root, "public"),
    password,
    cookieSecure: env.ASTER_COOKIE_SECURE === "1",
    allowedHosts: [...extraHosts, ...(isLoopbackHost(host) ? [] : [host.toLowerCase()])],
    provider: (env.ASTER_PROVIDER || "anthropic").trim(),
    apiKey: env.ANTHROPIC_API_KEY && env.ANTHROPIC_API_KEY.trim() ? env.ANTHROPIC_API_KEY.trim() : null,
    anthropicBaseUrl: (env.ASTER_ANTHROPIC_BASE_URL || "https://api.anthropic.com").replace(/\/+$/, ""),
    defaultModel,
    titleModel: (env.ASTER_TITLE_MODEL || defaultModel).trim(),
    models,
    maxMessageChars: int(env, "ASTER_MAX_MESSAGE_CHARS", 32000, 100, 500000),
    maxAttachments: int(env, "ASTER_MAX_ATTACHMENTS", 5, 1, 20),
    maxImageBytes: int(env, "ASTER_MAX_IMAGE_BYTES", 5 * 1024 * 1024, 1024, 20 * 1024 * 1024),
    maxPdfBytes: int(env, "ASTER_MAX_PDF_BYTES", 10 * 1024 * 1024, 1024, 32 * 1024 * 1024),
    maxTextBytes: int(env, "ASTER_MAX_TEXT_BYTES", 512 * 1024, 1024, 5 * 1024 * 1024),
    maxContextTokens: int(env, "ASTER_MAX_CONTEXT_TOKENS", 150000, 2000, 1000000),
    maxOutputTokens: int(env, "ASTER_MAX_OUTPUT_TOKENS", 8192, 256, 64000),
    maxMemories: int(env, "ASTER_MAX_MEMORIES", 500, 10, 5000),
    chatRatePerMinute: int(env, "ASTER_CHAT_RATE_PER_MIN", 30, 1, 10000),
    retryBaseMs: int(env, "ASTER_RETRY_BASE_MS", 1500, 0, 60000),
    maxRetries: int(env, "ASTER_MAX_RETRIES", 3, 0, 8),
    streamIdleTimeoutMs: int(env, "ASTER_STREAM_IDLE_TIMEOUT_MS", 90000, 1000, 600000),
    sessionTtlMs: 30 * 24 * 3600 * 1000,
  };
}

export function allModelIds(c: Config): string[] {
  return c.models.map((m) => m.id);
}
