// Development helper: runs Aster against a local MOCK of the Anthropic API (no key, no network, throwaway data dir).
// For trying the UI and for automated browser checks:  npm run dev:mock
// The mock answers by trigger words (math, code, quiz, flashcards, remember …, slow, error …) — see test/helpers/mock-anthropic.ts.
// This is NOT how you use Aster day to day: real use needs ANTHROPIC_API_KEY (see README).

import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createApp } from "../server/app.ts";
import { loadConfig } from "../server/config.ts";
import { startMockAnthropic } from "../test/helpers/mock-anthropic.ts";

const mock = await startMockAnthropic({ apiKey: "mock-key" });
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "aster-mock-"));
const config = loadConfig({
  ASTER_PORT: process.env.ASTER_PORT ?? "3210",
  ASTER_HOST: "127.0.0.1",
  ASTER_DATA_DIR: dataDir,
  ANTHROPIC_API_KEY: "mock-key",
  ASTER_ANTHROPIC_BASE_URL: mock.url,
  ASTER_RETRY_BASE_MS: "300",
  ...(process.env.ASTER_PASSWORD ? { ASTER_PASSWORD: process.env.ASTER_PASSWORD } : {}),
}, process.cwd());

const app = createApp(config);
const { url } = await app.listen();
console.log(`Aster (MOCK model) running at ${url}`);
console.log(`Mock Anthropic API at ${mock.url} — data dir ${dataDir}`);

const stop = async () => {
  await app.close();
  await mock.close();
  fs.rmSync(dataDir, { recursive: true, force: true });
  process.exit(0);
};
process.on("SIGINT", stop);
process.on("SIGTERM", stop);
