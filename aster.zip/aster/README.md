# Aster — your personal AI assistant

A working, self-hosted AI assistant with a Claude-class conversational interface, **persistent long-term memory**, and a **step-by-step math tutor** that reads photos of problems. Everything you say is answered by a real model through the Anthropic API; nothing is scripted.

- **Chat**: streaming replies, Markdown, LaTeX (KaTeX), syntax-highlighted code, copy / regenerate / edit, stop, retry, conversation history with search, rename, archive and delete.
- **Math tutor**: understands → given → method → numbered steps with *why* → check → **final answer**. An exact calculator tool (big integers, fractions, trig, statistics) lets the model verify arithmetic instead of guessing. Upload an image of a problem and it transcribes it first, and says what is unclear.
- **Memory**: durable facts about you, in categories, kept in a database. You can view / search / edit / delete them, switch automatic memory off, or make any chat private.
- **Study tools**: summaries, translation, code explanation, practice questions, interactive **quizzes** and **flip-card flashcards**.
- **Privacy & security**: key stays on the server, optional password login, CSRF/DNS-rebinding defences, strict CSP, validated uploads, export and delete-all.

---

## Quick start

Requires **Node.js 22.18 or newer** (it runs TypeScript and SQLite natively). There are **no runtime dependencies** — nothing to `npm install` to run the app.

```bash
cd aster
cp .env.example .env          # then edit .env and paste your key
npm start                     # → http://127.0.0.1:3000
```

### Get and configure an Anthropic API key

1. Sign in at <https://console.anthropic.com>, add a little credit under **Billing**.
2. **Settings → API keys → Create key**, copy it (shown once).
3. Put it in `.env`: `ANTHROPIC_API_KEY=sk-ant-...` and restart `npm start`.

The key is read only by the server. It is never sent to the browser, never logged, and never included in any API response (there are tests for this). Without a key Aster still starts: you can browse and manage everything, and the UI shows a setup notice instead of failing silently.

Model ids change over time — see <https://docs.claude.com/en/docs/about-claude/models> and set `ASTER_MODEL` / `ASTER_MODELS` to ids your key can use. Pick the model per-chat in **Settings**.

### Try the UI without a key

```bash
npm run dev:mock
```

Starts Aster against a local **mock of the Anthropic wire protocol** (throwaway data dir). It answers by trigger words (`math`, `code`, `quiz`, `flashcards`, `remember that …`, `calc 2+2`, `slow`, `error` …). It exists for UI development and tests only — see `test/helpers/mock-anthropic.ts`.

---

## Environment variables

All optional except the key. See `.env.example` for the annotated list.

| Variable | Default | Meaning |
|---|---|---|
| `ANTHROPIC_API_KEY` | – | Your key (server only). |
| `ASTER_MODEL` | `claude-sonnet-5-5` | Default model. |
| `ASTER_MODELS` | Sonnet / Opus / Haiku 5.5 | Models offered in Settings, `id:Label,…`. |
| `ASTER_TITLE_MODEL` | `ASTER_MODEL` | Model that writes chat titles. |
| `ASTER_MAX_OUTPUT_TOKENS` | `8192` | Max tokens per reply. |
| `ASTER_HOST` / `ASTER_PORT` | `127.0.0.1` / `3000` | Listen address. |
| `ASTER_DATA_DIR` | `./data` | Where `aster.db` lives (created with private permissions). |
| `ASTER_PASSWORD` | – | Enables login (8+ chars). **Required** for any non-localhost bind; the server refuses to start otherwise. |
| `ASTER_COOKIE_SECURE` | – | `1` when served over HTTPS. |
| `ASTER_ALLOWED_HOSTS` | – | Extra host names you serve Aster under. |
| `ASTER_MAX_CONTEXT_TOKENS` | `150000` | Budget for conversation history; oldest turns are dropped beyond it (the model is told). |
| `ASTER_MAX_MEMORIES` | `500` | Memory capacity. |
| `ASTER_CHAT_RATE_PER_MIN` | `30` | Chat requests per minute (cost guard). |
| `ASTER_MAX_IMAGE_BYTES` / `_PDF_BYTES` / `_TEXT_BYTES` | 5 MB / 10 MB / 512 KB | Upload limits. |
| `ASTER_PROVIDER` | `anthropic` | Provider adapter (see *Adding another AI provider*). |
| `ASTER_ANTHROPIC_BASE_URL` | `https://api.anthropic.com` | Override for gateways. Deliberately **not** the generic `ANTHROPIC_BASE_URL`, so a stray proxy variable can never receive your key. |

## Database

Aster stores everything in one **SQLite** file (`data/aster.db`, WAL mode, versioned migrations, full-text search for chat search). There is nothing to install or configure; back it up by copying the file while the server is stopped. Tables: `conversations`, `messages`, `attachments`, `memories`, `settings`, `sessions`.

---

## How persistent memory works

Memory is a table in the database, so it survives closing the app, restarting the server, and starting new conversations (covered by a test that restarts the server).

**Saving.** Memory tools are offered to the model in every non-private chat: `memory_save`, `memory_update`, `memory_forget`, `memory_list`, `conversation_memory`. The model decides when something is a *stable, useful fact* (education, goals, preferences, interests, projects, how you like things explained) and saves one short sentence in one of nine categories: personal, preferences, education, learning goals, interests, ambitions, projects, context, communication. The prompt tells it to skip trivia, temporary context and other people's details. Near-duplicates are merged into the existing memory instead of stored twice.

**Using.** At each turn the server retrieves memories (all of them while the store is small; later the most relevant by word overlap plus your communication/preference notes) and places them in the system prompt. Their `last used` time is recorded. The model is told to treat only that list and tool results as real, and never to claim to remember anything else.

**Controls.**
- *Automatic memory* toggle (Memory page / Settings). Off = it only saves when you explicitly say "remember this".
- Say it in chat: **"Remember this"**, **"Forget that"**, **"What do you remember about me?"** (it reads the real list via a tool), **"Update my memory…"**, **"Don't remember this conversation"** (switches that chat to private).
- *Private chat*: set when creating a chat (lock icon) or by asking. In a private chat memory is neither read nor written.
- Memory page: view, search, filter by category, edit, delete, add manually, clear all; each memory shows source (auto / you asked / manual), created, updated and last-used times.

**What is never stored.** Secrets — passwords, PINs, card numbers (Luhn-checked), API keys/tokens, private keys, government IDs, bank accounts — are refused for every source, including manual entry. Highly sensitive categories (health, sexuality, religion, politics, immigration, criminal history, detailed finances, personal-safety topics) are refused for *automatic* memory; if you explicitly ask, it is allowed. These checks are heuristics (regular expressions) and can miss or over-match; the model is also instructed not to attempt such saves.

---

## Mathematics

Choose **Auto**, **Math** or **Study** in the composer. For problems the model follows a fixed protocol with these headings — `Understanding the problem`, `Given`, `Concepts and method`, `Solution`, `Check`, `Final answer` — and the UI highlights the final answer and de-emphasises the check. It will not jump to the answer unless you ask for "just the answer". The **`calculate`** tool evaluates expressions exactly (rational arithmetic with big integers; `+ − × ÷ ^ ! %`, `sqrt`, `sin/cos/tan` (+degree variants), `ln`, `log`, `binom`, `gcd`, `lcm`, `mean`, `median`, `stdev`, …) with limits on size and depth; there is no `eval`.

**Images**: attach (or paste / drag) a PNG, JPEG, GIF or WebP; it is sent to the model's vision input. The prompt requires it to transcribe what it reads, describe diagrams, flag unclear parts, and not invent values it can't see. PDFs go through the model's native PDF input.

---

## Security model

Implemented and covered by `test/unit/security.test.ts` unless noted:

- API key only in server env; never in responses, logs or errors; upstream auth error text is not forwarded.
- Optional password (`scrypt` compare, constant-time), session cookie `HttpOnly; SameSite=Strict` (+`Secure` over HTTPS), tokens stored only as SHA-256 hashes, login rate-limited, logout invalidates server-side.
- Fails closed: refuses non-localhost binding without a password.
- CSRF: state-changing requests need a matching `Origin` (or no browser metadata); DNS-rebinding: unexpected `Host` rejected.
- CSP `script-src 'self'` (no inline scripts, no remote origins), `nosniff`, `X-Frame-Options: DENY`, `no-referrer`; everything the UI needs is served from the app itself (KaTeX, highlight.js, marked and DOMPurify are vendored). Model output is rendered through DOMPurify.
- Uploads: type decided by file *content* (magic bytes), not the client's claim; allowlisted types only (no SVG/HTML); size limits per kind; UTF-8 text only; names sanitised; served `nosniff` with a sandbox CSP.
- All SQL is parameterised; search input is sanitised for FTS; path traversal on static files is blocked.
- Logs record method / route / status / duration only — never message, memory or file content (tested).
- Your data: **Export** (JSON, optionally with files) and **Delete all my data** (typed confirmation) in Settings.

**Not covered / your responsibility**: the database file is not encrypted at rest (use disk encryption); your messages are sent to Anthropic to be answered, under Anthropic's terms; if you expose Aster beyond localhost, put it behind HTTPS and set a strong `ASTER_PASSWORD`. It is a single-user app (one password, one data set).

---

## Project structure

```
aster/
├─ package.json            scripts: start, dev, dev:mock, test, typecheck (no runtime deps)
├─ .env.example            annotated configuration
├─ docs/API.md             HTTP + SSE contract between server and UI
├─ server/                 Node (native TypeScript)
│  ├─ index.ts             entry: loads .env, starts server, graceful shutdown
│  ├─ app.ts               wiring + request pipeline (host/origin/auth checks, API vs static)
│  ├─ config.ts            env parsing & validation (fails closed)
│  ├─ db.ts                SQLite open, migrations, FTS5 search index
│  ├─ errors.ts log.ts util.ts
│  ├─ providers/           AI provider layer
│  │   ├─ types.ts         provider-agnostic interface (messages, tools, events)
│  │   ├─ anthropic.ts     Messages API over fetch: streaming, tool_use, error mapping
│  │   └─ index.ts         registry (add vendors here)
│  ├─ chat/
│  │   ├─ service.ts       turn runner: send/edit/regenerate, tool loop, retries, abort, titles
│  │   ├─ prompt.ts        persona, math protocol, memory policy, quiz/flashcard formats
│  │   └─ context.ts       history → provider messages, attachments, token-budget trimming
│  ├─ memory/              service.ts (save/dedupe/retrieve/forget) · sensitive.ts (what is refused)
│  ├─ tools/               calculator.ts (safe exact evaluator) · index.ts (tool defs + executor)
│  ├─ repo/                conversations · messages(+attachments) · memories · settings · types
│  └─ http/                router · routes · auth · security · static · uploads · util
├─ public/                 frontend (vanilla ES modules, no build step)
│  ├─ index.html  favicon.svg
│  ├─ css/                 tokens (light/dark) · base · layout · chat · widgets · panels
│  ├─ js/                  app · api (SSE client) · state · sanitize · theme · icons · dom
│  │   ├─ lib/             pure modules: markdown · math · highlight · sse · errors · files · format
│  │   └─ ui/              sidebar · chat · message · composer · memory · settings · widgets · auth …
│  └─ vendor/              katex · highlight.js · marked · dompurify (with licences)
├─ scripts/dev-mock.ts     run the app against the mock provider
└─ test/
   ├─ helpers/             mock-anthropic.ts (wire-protocol fixture) · harness.ts (boots real app)
   └─ unit/                110 tests (see below)
```

## Tests

```bash
npm test                  # 110 tests, ~7 s, no network or key needed
npm run typecheck         # optional: needs `npm install` for typescript + @types/node
```

The tests boot the **real** server with a real SQLite file and real provider code against a mock that speaks the Anthropic streaming wire format, so streaming, the tool loop, retries, aborts and error mapping are exercised end to end. They cover: calculator, memory (dedupe, forget, retrieval, sensitive filter), repositories & search, persistence across restart, provider/SSE parsing & error mapping, uploads, context trimming, chat flows (send / follow-up / regenerate / edit / stop / concurrency / errors), memory flows through tools, auth, CSRF, host checks, headers, path traversal, SQL-injection inertness, rate limits, no-secrets-in-logs, export and delete-all, and the frontend's pure rendering libraries (markdown, LaTeX, highlighting, SSE, formatting).

---

## Adding another AI provider

Implement `AIProvider` from `server/providers/types.ts` (`stream(request, signal)` yielding `text`, `tool_use` and `end` events, throwing `AppError` with a stable `code`), register it in `server/providers/index.ts`, and select it with `ASTER_PROVIDER`. Nothing else in the app knows which vendor is used.

## Known limitations (please read)

- **Not yet verified against the live Anthropic API.** The build environment had no API key or internet access for the app, so the provider was developed against Anthropic's documented Messages-API streaming format and tested against a faithful mock. Your first real chat is the true integration test; if a model id is rejected, the error says so — adjust `ASTER_MODEL`.
- **The official `@anthropic-ai/sdk` is not used.** Package installs were blocked, so `server/providers/anthropic.ts` calls the HTTP API with `fetch`. It's isolated behind the provider interface; swapping in the SDK only touches that file.
- **SQLite instead of PostgreSQL + Prisma, and no Next.js/Tailwind.** Same reason; the stack is zero-dependency Node + vanilla ES modules. SQLite is ideal for a single-user app (zero setup, one file). Moving to Postgres would mean re-implementing `server/repo/*` and `db.ts`.
- Memory capture is **model-driven** (tool calls), so it is not perfect: it may occasionally miss something worth saving or save something borderline. Review the Memory page now and then.
- Extended "thinking" mode is not enabled; the math protocol relies on the structured prompt and the calculator tool.
- Verified in Chromium (desktop and phone-sized viewports, light and dark). Other browsers should work (standard ES modules, MathML-free KaTeX HTML) but weren't exercised.
- Quiz/flashcard progress lives in the page, not the database.
- Conversation search is word/prefix based (FTS5), not semantic.

## Licences of bundled libraries

KaTeX (MIT), marked (MIT), highlight.js (BSD-3-Clause), DOMPurify (MPL-2.0 / Apache-2.0) — licence files are in `public/vendor/*`.
