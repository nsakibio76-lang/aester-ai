/** Aster client entry: boots, handles auth, builds the shell, routes between chat and memory. */
import { h, clear, prefs } from './dom.js';
import { icon, brandMark } from './icons.js';
import { api, setUnauthenticatedHandler } from './api.js';
import { state, on, emit } from './state.js';
import { describeError } from './lib/errors.js';
import { applyTheme } from './theme.js';
import { createSidebar } from './ui/sidebar.js';
import { createChat } from './ui/chat.js';
import { createMemory } from './ui/memory.js';
import { openSettings } from './ui/settings.js';
import { showLogin } from './ui/auth.js';

const root = document.getElementById('app');
const mobileQuery = matchMedia('(max-width: 767px)');

let chat = null;
let memory = null;
let sidebar = null;
let appEl = null;
let mainEl = null;
let scrim = null;
let view = 'chat';
let sidebarOpen = prefs.get('sidebar', 'open') !== 'closed';
let drawerOpen = false;
let noticeDismissed = false;
let authInFlight = false;
let teardown = [];

try { noticeDismissed = sessionStorage.getItem('aster.noticeDismissed') === '1'; } catch { /* storage unavailable */ }

function fatal(err) {
  clear(root);
  root.className = 'boot';
  root.removeAttribute('aria-busy');
  const d = describeError(err.code || 'network', err.message);
  root.append(h('div', { class: 'fatal' }, brandMark('fatal-mark'), h('h1', { text: 'Aster cannot start' }), h('p', { text: d.message }),
    h('button', { type: 'button', class: 'btn btn-primary', text: 'Try again', onClick: () => { root.setAttribute('aria-busy', 'true'); boot(); } })));
}

async function boot() {
  authInFlight = false;
  for (const fn of teardown) fn();
  teardown = [];
  let meta;
  try { meta = await api.meta(); } catch (e) { fatal(e); return; }
  state.meta = meta;
  document.title = meta.appName;
  if (meta.authRequired && !meta.authenticated) {
    showLogin(root, { appName: meta.appName, onSuccess: boot });
    return;
  }
  try { state.settings = await api.getSettings(); } catch (e) {
    if (e.code === 'unauthenticated') return; // handler shows the login form
    fatal(e); return;
  }
  applyTheme(state.settings.theme);
  buildApp();
  route();
  sidebar.load();
}

setUnauthenticatedHandler(() => {
  if (authInFlight) return;
  authInFlight = true;
  if (chat) chat.abort();
  state.conversations = [];
  state.activeId = null;
  boot();
});

/* ---------- shell ---------- */
const shell = {
  navigate,
  toggleSidebar() {
    if (mobileQuery.matches) drawerOpen = !drawerOpen;
    else { sidebarOpen = !sidebarOpen; prefs.set('sidebar', sidebarOpen ? 'open' : 'closed'); }
    applyLayout(true);
  },
  openSettings: () => openSettings({ shell }),
  currentView: () => view,
  conversationChanged(c) { chat && chat.applyConversation(c); },
  conversationRemoved(id) { chat && chat.conversationRemoved(id); },
  settingsChanged() { memory && memory.syncSettings(); },
  async logout() {
    try { await api.logout(); } catch (e) { /* still return to the sign-in screen */ }
    if (chat) chat.abort();
    state.conversations = []; state.activeId = null;
    boot();
  },
};

function buildApp() {
  clear(root);
  root.className = 'app';
  root.removeAttribute('aria-busy');
  sidebar = createSidebar({ shell });
  chat = createChat({ shell });
  memory = createMemory({ shell });
  scrim = h('div', { class: 'scrim', hidden: true, onClick: () => { drawerOpen = false; applyLayout(); } });
  const notice = h('div', { class: 'notice', role: 'status', hidden: true });
  mainEl = h('main', { class: 'main', id: 'main' }, notice, chat.el, memory.el);
  appEl = root;
  root.append(sidebar.el, scrim, mainEl);
  renderNotice(notice);
  applyLayout();
}

function renderNotice(el) {
  const show = state.meta.apiConfigured === false && !noticeDismissed;
  el.hidden = !show;
  clear(el);
  if (!show) return;
  el.append(icon('alert'),
    h('p', { class: 'notice-text' }, h('strong', { text: 'Aster needs an API key. ' }),
      'Add your Anthropic key as ', h('code', { text: 'ANTHROPIC_API_KEY' }), ' in the server’s ', h('code', { text: '.env' }), ' file and restart. Until then you can browse and manage everything except chatting.'),
    h('button', { type: 'button', class: 'btn btn-sm', text: 'Dismiss', onClick: () => {
      noticeDismissed = true;
      try { sessionStorage.setItem('aster.noticeDismissed', '1'); } catch { /* storage unavailable */ }
      renderNotice(el);
    } }));
}

function applyLayout(focus = false) {
  const mobile = mobileQuery.matches;
  if (!mobile) drawerOpen = false;
  const open = mobile ? drawerOpen : sidebarOpen;
  appEl.dataset.sidebar = open ? 'open' : 'closed';
  sidebar.el.inert = !open;
  mainEl.inert = mobile && drawerOpen;
  scrim.hidden = !(mobile && drawerOpen);
  for (const b of document.querySelectorAll('.nav-toggle')) b.setAttribute('aria-expanded', String(open));
  if (focus) {
    if (open) sidebar.el.querySelector('a, button, input')?.focus();
    else document.querySelector('.pane:not([hidden]) .nav-toggle')?.focus();
  }
}
mobileQuery.addEventListener('change', () => appEl && applyLayout());

document.addEventListener('keydown', (e) => {
  if (!appEl) return;
  if (e.key === 'Escape' && drawerOpen && mobileQuery.matches && !document.querySelector('dialog[open]')) { drawerOpen = false; applyLayout(true); }
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    if (mobileQuery.matches) drawerOpen = true; else sidebarOpen = true;
    applyLayout();
    sidebar.focusSearch();
  }
});

/* ---------- routing ---------- */
function navigate(path, { replace = false, silent = false } = {}) {
  if (location.pathname !== path) history[replace ? 'replaceState' : 'pushState'](null, '', path);
  if (!silent) route();
}

function setView(v) {
  view = v;
  chat.el.hidden = v !== 'chat';
  memory.el.hidden = v !== 'memory';
  sidebar.setMemoryActive(v === 'memory');
  emit('active');
}

function route() {
  if (!chat) return;
  const path = location.pathname.replace(/\/+$/, '') || '/';
  const m = /^\/c\/([^/]+)$/.exec(path);
  if (path === '/memory') { setView('memory'); memory.show(); }
  else if (m) { setView('chat'); chat.show(decodeURIComponent(m[1])); }
  else { setView('chat'); chat.showNew(); }
  if (mobileQuery.matches && drawerOpen) { drawerOpen = false; applyLayout(); }
}
window.addEventListener('popstate', route);

boot();
