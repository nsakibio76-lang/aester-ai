// Applies the cached theme before first paint (loaded synchronously from <head>; no inline script because of CSP).
try {
  var t = localStorage.getItem('aster.theme');
  if (t === 'light' || t === 'dark') document.documentElement.setAttribute('data-theme', t);
} catch (e) { /* storage unavailable: fall back to the system theme */ }
