/** HTTP client for the Aster API (docs/API.md). */
import { createSSEParser } from './lib/sse.js';

export class ApiError extends Error {
  constructor(status, code, message, retryable = false) {
    super(message || code);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.retryable = retryable;
  }
}

let onUnauthenticated = () => {};
export function setUnauthenticatedHandler(fn) { onUnauthenticated = fn; }

async function toApiError(res) {
  let code = 'server';
  let message = `Request failed (${res.status}).`;
  try {
    const body = await res.json();
    if (body && body.error) { code = body.error.code || code; message = body.error.message || message; }
  } catch { /* non-JSON error body */ }
  if (res.status === 401 && code !== 'invalid_password') code = 'unauthenticated';
  else if (res.status === 413) code = code === 'server' ? 'validation' : code;
  return new ApiError(res.status, code, message, res.status >= 500);
}

async function request(method, path, { json, body, headers = {}, signal, raw = false } = {}) {
  const init = { method, headers: { Accept: 'application/json', ...headers }, signal, credentials: 'same-origin' };
  if (json !== undefined) { init.body = JSON.stringify(json); init.headers['Content-Type'] = 'application/json'; }
  else if (body !== undefined) init.body = body;
  let res;
  try {
    res = await fetch(path, init);
  } catch (e) {
    if (e && e.name === 'AbortError') throw e;
    throw new ApiError(0, 'network', 'Could not reach the server.', true);
  }
  if (!res.ok) {
    const err = await toApiError(res);
    if (err.code === 'unauthenticated' && path !== '/api/auth/login') onUnauthenticated(err);
    throw err;
  }
  if (raw) return res;
  if (res.status === 204) return null;
  try { return await res.json(); } catch { return null; }
}

const qs = (o) => {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(o)) if (v !== undefined && v !== null && v !== '') p.set(k, String(v));
  const s = p.toString();
  return s ? `?${s}` : '';
};

export const api = {
  meta: () => request('GET', '/api/meta'),
  login: (password) => request('POST', '/api/auth/login', { json: { password } }),
  logout: () => request('POST', '/api/auth/logout', { json: {} }),
  getSettings: () => request('GET', '/api/settings'),
  putSettings: (patch) => request('PUT', '/api/settings', { json: patch }),
  listConversations: ({ archived = false, q = '', limit = 50, offset = 0 } = {}) =>
    request('GET', `/api/conversations${qs({ archived: archived ? 1 : 0, q, limit, offset })}`),
  createConversation: (body = {}) => request('POST', '/api/conversations', { json: body }),
  getConversation: (id) => request('GET', `/api/conversations/${encodeURIComponent(id)}`),
  patchConversation: (id, patch) => request('PATCH', `/api/conversations/${encodeURIComponent(id)}`, { json: patch }),
  deleteConversation: (id) => request('DELETE', `/api/conversations/${encodeURIComponent(id)}`),
  upload: (file, signal) =>
    request('POST', '/api/uploads', {
      body: file,
      signal,
      headers: { 'Content-Type': file.type || 'application/octet-stream', 'X-File-Name': encodeURIComponent(file.name) },
    }),
  deleteUpload: (id) => request('DELETE', `/api/uploads/${encodeURIComponent(id)}`),
  listMemories: ({ q = '', category = '' } = {}) => request('GET', `/api/memories${qs({ q, category })}`),
  createMemory: (body) => request('POST', '/api/memories', { json: body }),
  patchMemory: (id, patch) => request('PATCH', `/api/memories/${encodeURIComponent(id)}`, { json: patch }),
  deleteMemory: (id) => request('DELETE', `/api/memories/${encodeURIComponent(id)}`),
  clearMemories: () => request('DELETE', '/api/memories', { json: { confirm: true } }),
  deleteAllData: (phrase) => request('DELETE', '/api/data', { json: { confirm: phrase } }),
  async exportData(files) {
    const res = await request('GET', `/api/export${qs({ files: files ? 1 : 0 })}`, { raw: true });
    const blob = await res.blob();
    const cd = res.headers.get('Content-Disposition') || '';
    const m = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/i.exec(cd);
    return { blob, filename: m ? decodeURIComponent(m[1]) : 'aster-export.json' };
  },
};

/**
 * POST /api/chat and dispatch SSE events. Resolves when the stream closes.
 * Rejects with ApiError for HTTP-level failures, AbortError when aborted.
 */
export async function streamChat(payload, { signal, onEvent }) {
  let res;
  try {
    res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' },
      body: JSON.stringify(payload),
      signal,
      credentials: 'same-origin',
    });
  } catch (e) {
    if (e && e.name === 'AbortError') throw e;
    throw new ApiError(0, 'network', 'Could not reach the server.', true);
  }
  if (!res.ok) {
    const err = await toApiError(res);
    if (err.code === 'unauthenticated') onUnauthenticated(err);
    throw err;
  }
  if (!res.body) throw new ApiError(0, 'network', 'The server sent no response stream.', true);
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  const parser = createSSEParser((ev) => {
    let data = null;
    try { data = JSON.parse(ev.data); } catch { return; }
    onEvent(ev.event, data);
  });
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      parser.push(decoder.decode(value, { stream: true }));
    }
    parser.push(decoder.decode());
    parser.flush();
  } catch (e) {
    if (e && e.name === 'AbortError') throw e;
    throw new ApiError(0, 'network', 'The connection was interrupted.', true);
  }
}
