import { prefs } from './dom.js';

/** theme: 'system' | 'light' | 'dark'. Caches the explicit choice so the next load paints correctly. */
export function applyTheme(theme) {
  const root = document.documentElement;
  if (theme === 'light' || theme === 'dark') {
    root.setAttribute('data-theme', theme);
    prefs.set('theme', theme);
  } else {
    root.removeAttribute('data-theme');
    try { localStorage.removeItem('aster.theme'); } catch { /* storage unavailable */ }
  }
}
