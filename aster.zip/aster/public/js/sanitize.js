/** DOMPurify wrapper. Everything the model produces passes through here before reaching the DOM. */
import DOMPurify from '../vendor/dompurify/purify.es.mjs';

const purify = DOMPurify(window);

purify.addHook('afterSanitizeAttributes', (node) => {
  if (node.tagName === 'A') {
    if (node.getAttribute('target') === '_blank') node.setAttribute('rel', 'noopener noreferrer');
    else node.removeAttribute('target');
  }
});

const RICH = {
  USE_PROFILES: { html: true, svg: true, mathMl: true },
  ADD_TAGS: ['semantics', 'annotation'],
  ADD_ATTR: ['target', 'encoding', 'display', 'data-spec', 'data-widget', 'data-lang', 'data-action'],
  FORBID_TAGS: ['style', 'form', 'iframe', 'object', 'embed', 'link', 'meta', 'base'],
  FORBID_ATTR: ['srcset'],
};

/** Sanitise rendered Markdown/KaTeX HTML. */
export function sanitizeHtml(html) {
  return purify.sanitize(html, RICH);
}

/** Conversation-search snippets: only <mark> survives. */
export function sanitizeSnippet(html) {
  return purify.sanitize(html, { ALLOWED_TAGS: ['mark'], ALLOWED_ATTR: [] });
}
