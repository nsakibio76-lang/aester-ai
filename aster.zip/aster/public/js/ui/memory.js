/** Memory management page: view, search, filter, add, edit, delete, clear, auto-memory toggle. */
import { h, clear, debounce } from '../dom.js';
import { icon } from '../icons.js';
import { api } from '../api.js';
import { state, on } from '../state.js';
import { describeError, MEMORY_CATEGORIES } from '../lib/errors.js';
import { formatDateTime, timeAgo } from '../lib/format.js';
import { toast } from './toast.js';
import { confirmDialog } from './dialog.js';

const SOURCES = { auto: 'Learned automatically', explicit: 'You asked to remember', manual: 'Added by you' };
const label = (id) => (MEMORY_CATEGORIES.find((c) => c.id === id) || { label: id }).label;

export function createMemory({ shell }) {
  let query = '';
  let category = '';
  let editingId = null;
  let adding = false;
  let items = [];
  let total = 0;
  let seq = 0;

  const navBtn = h('button', { type: 'button', class: 'icon-btn nav-toggle', 'aria-label': 'Toggle sidebar', onClick: () => shell.toggleSidebar() }, icon('panel'));
  const addBtn = h('button', { type: 'button', class: 'btn btn-sm', onClick: () => { adding = !adding; editingId = null; renderForm(); } }, icon('plus'), 'Add memory');
  const topbar = h('header', { class: 'topbar' }, navBtn, h('h1', { class: 'topbar-title', text: 'Memory' }), h('span', { class: 'spacer' }), addBtn);

  const autoInput = h('input', { type: 'checkbox', 'aria-describedby': 'auto-hint', onChange: async () => {
    const want = autoInput.checked;
    try { state.settings = await api.putSettings({ autoMemory: want }); } catch (e) { autoInput.checked = !want; toast(describeError(e.code, e.message).message, { kind: 'error' }); }
  } });
  const autoRow = h('div', { class: 'panel-row' },
    h('div', { class: 'panel-row-text' }, h('strong', { text: 'Automatic memory' }), h('p', { id: 'auto-hint', class: 'hint', text: 'Let Aster save lasting things you tell it, like goals, preferences and what you are studying. Private chats are never saved. You can also say “remember this” or “forget that” in any chat.' })),
    h('label', { class: 'switch' }, autoInput, h('span', { class: 'switch-track' }), h('span', { class: 'sr-only', text: 'Automatic memory' })));

  const search = h('input', { class: 'input', type: 'search', placeholder: 'Search memories', 'aria-label': 'Search memories', autocomplete: 'off' });
  const runSearch = debounce(() => load(), 250);
  search.addEventListener('input', () => { query = search.value.trim(); runSearch(); });
  const chips = h('div', { class: 'chips', role: 'group', 'aria-label': 'Filter by category' });
  function renderChips() {
    clear(chips);
    for (const c of [{ id: '', label: 'All' }, ...MEMORY_CATEGORIES]) {
      chips.append(h('button', { type: 'button', class: 'chip', 'aria-pressed': String(category === c.id), text: c.label, onClick: () => { category = c.id; renderChips(); load(); } }));
    }
  }
  renderChips();

  const formHost = h('div', { class: 'memory-form-host' });
  const count = h('p', { class: 'count', 'aria-live': 'polite' });
  const listEl = h('ul', { class: 'memory-list', 'aria-label': 'Saved memories' });
  const clearBtn = h('button', { type: 'button', class: 'btn btn-danger btn-sm', onClick: clearAll }, icon('trash'), 'Clear all memories');
  const panel = h('div', { class: 'panel' },
    h('p', { class: 'panel-lede', text: 'What Aster knows about you, across every chat. Everything here is yours to edit or delete.' }),
    autoRow,
    h('div', { class: 'memory-tools' }, h('div', { class: 'search search-wide' }, icon('search'), search), chips),
    formHost, count, listEl,
    h('div', { class: 'panel-foot' }, clearBtn));
  const el = h('section', { class: 'pane pane-memory', 'aria-label': 'Memory' }, topbar, h('div', { class: 'panel-scroll' }, panel));

  function catSelect(value) {
    return h('select', { class: 'select', 'aria-label': 'Category' }, MEMORY_CATEGORIES.map((c) => h('option', { value: c.id, text: c.label, selected: c.id === value })));
  }

  function renderForm() {
    clear(formHost);
    addBtn.setAttribute('aria-expanded', String(adding));
    if (!adding) return;
    const ta = h('textarea', { class: 'textarea', 'aria-label': 'What should Aster remember?', placeholder: 'For example: I am studying for the IGCSE maths exam in May.', maxlength: 1000 });
    const sel = catSelect('context');
    const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
    const save = h('button', { type: 'submit', class: 'btn btn-primary btn-sm', text: 'Save memory' });
    const form = h('form', { class: 'memory-form' }, h('div', { class: 'field' }, h('label', { text: 'New memory' }), ta), h('div', { class: 'field' }, h('label', { text: 'Category' }), sel), err,
      h('div', { class: 'form-actions' }, h('button', { type: 'button', class: 'btn btn-sm', text: 'Cancel', onClick: () => { adding = false; renderForm(); } }), save));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const content = ta.value.trim();
      if (!content) { err.hidden = false; err.textContent = 'Write something for Aster to remember.'; return; }
      save.disabled = true;
      try {
        await api.createMemory({ content, category: sel.value });
        adding = false; renderForm(); toast('Memory saved.', { kind: 'ok' }); load();
      } catch (e2) {
        err.hidden = false; err.textContent = describeError(e2.code, e2.message).message; save.disabled = false;
      }
    });
    formHost.append(form);
    ta.focus();
  }

  async function load() {
    const my = ++seq;
    try {
      const res = await api.listMemories({ q: query, category });
      if (my !== seq) return;
      items = res.memories; total = res.total;
      render();
    } catch (e) {
      if (e.code !== 'unauthenticated') { clear(listEl); count.textContent = ''; listEl.append(h('li', { class: 'error-banner' }, icon('alert'), h('div', { class: 'error-text', text: describeError(e.code, e.message).message }))); }
    }
  }

  function render() {
    clear(listEl);
    const filtered = query || category;
    count.textContent = total === 0 ? '' : `${total} ${total === 1 ? 'memory' : 'memories'}${filtered ? ' match' : ''}`;
    clearBtn.disabled = !items.length && !filtered;
    if (!items.length) {
      listEl.append(h('li', { class: 'memory-empty' },
        h('p', { class: 'memory-empty-title', text: filtered ? 'No memories match.' : 'Nothing saved yet.' }),
        h('p', { class: 'hint', text: filtered ? 'Try a different search or category.' : 'Tell Aster something worth keeping, say “remember this”, or add a memory yourself.' })));
      return;
    }
    for (const m of items) listEl.append(m.id === editingId ? renderEdit(m) : renderItem(m));
  }

  function renderItem(m) {
    const meta = [
      h('span', { class: 'badge', text: label(m.category) }),
      h('span', { class: `badge badge-${m.source}`, text: SOURCES[m.source] || m.source }),
      h('span', { class: 'memory-time', title: `Created ${formatDateTime(m.createdAt)}` }, m.updatedAt !== m.createdAt ? `Updated ${timeAgo(m.updatedAt)}` : `Saved ${timeAgo(m.createdAt)}`),
      m.lastUsedAt && h('span', { class: 'memory-time', title: formatDateTime(m.lastUsedAt) }, `Used ${timeAgo(m.lastUsedAt)}`),
      m.conversationId && h('a', { class: 'memory-from', href: `/c/${encodeURIComponent(m.conversationId)}`, onClick: (e) => { if (!(e.metaKey || e.ctrlKey)) { e.preventDefault(); shell.navigate(`/c/${encodeURIComponent(m.conversationId)}`); } } }, 'From a chat'),
    ];
    return h('li', { class: 'memory-item', 'data-id': m.id },
      h('div', { class: 'memory-main' }, h('p', { class: 'memory-content', text: m.content }), h('div', { class: 'memory-meta' }, meta)),
      h('div', { class: 'memory-actions' },
        h('button', { type: 'button', class: 'icon-btn icon-btn-sm', 'aria-label': 'Edit memory', title: 'Edit', onClick: () => { editingId = m.id; adding = false; renderForm(); render(); } }, icon('pencil')),
        h('button', { type: 'button', class: 'icon-btn icon-btn-sm', 'aria-label': 'Delete memory', title: 'Delete', onClick: () => remove(m) }, icon('trash'))));
  }

  function renderEdit(m) {
    const ta = h('textarea', { class: 'textarea', 'aria-label': 'Memory text', maxlength: 1000 });
    ta.value = m.content;
    const sel = catSelect(m.category);
    const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
    const form = h('form', { class: 'memory-form' }, ta, h('div', { class: 'field' }, h('label', { text: 'Category' }), sel), err,
      h('div', { class: 'form-actions' }, h('button', { type: 'button', class: 'btn btn-sm', text: 'Cancel', onClick: () => { editingId = null; render(); } }), h('button', { type: 'submit', class: 'btn btn-primary btn-sm', text: 'Save changes' })));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const content = ta.value.trim();
      if (!content) { err.hidden = false; err.textContent = 'A memory cannot be empty. Delete it instead.'; return; }
      try {
        await api.patchMemory(m.id, { content, category: sel.value });
        editingId = null; toast('Memory updated.', { kind: 'ok' }); load();
      } catch (e2) { err.hidden = false; err.textContent = describeError(e2.code, e2.message).message; }
    });
    setTimeout(() => ta.focus(), 0);
    return h('li', { class: 'memory-item is-editing', 'data-id': m.id }, form);
  }

  async function remove(m) {
    const ok = await confirmDialog({ title: 'Delete this memory?', message: `Aster will forget: “${m.content.length > 140 ? m.content.slice(0, 139) + '…' : m.content}”`, confirmLabel: 'Delete memory', danger: true });
    if (!ok) return;
    try { await api.deleteMemory(m.id); toast('Memory deleted.', { kind: 'ok' }); load(); } catch (e) { toast(describeError(e.code, e.message).message, { kind: 'error' }); }
  }

  async function clearAll() {
    const ok = await confirmDialog({ title: 'Clear all memories?', message: 'Aster will forget everything it has saved about you. Your conversations are not affected. This cannot be undone.', confirmLabel: 'Clear all', danger: true });
    if (!ok) return;
    try { const r = await api.clearMemories(); toast(`Cleared ${r && r.deleted != null ? r.deleted : 'all'} ${r && r.deleted === 1 ? 'memory' : 'memories'}.`, { kind: 'ok' }); load(); } catch (e) { toast(describeError(e.code, e.message).message, { kind: 'error' }); }
  }

  on('memory-changed', () => { if (el.offsetParent !== null) load(); });

  return {
    el,
    show() {
      autoInput.checked = !!(state.settings && state.settings.autoMemory);
      document.title = `Memory - ${state.meta.appName}`;
      load();
    },
    syncSettings() { autoInput.checked = !!(state.settings && state.settings.autoMemory); },
  };
}
