/** Message composer: auto-growing textarea, mode selector, attachments (picker, drop, paste). */
import { h, clear, announce } from '../dom.js';
import { icon } from '../icons.js';
import { api } from '../api.js';
import { validateFile } from '../lib/files.js';
import { formatBytes, truncate } from '../lib/format.js';
import { describeError } from '../lib/errors.js';
import { state } from '../state.js';
import { toast } from './toast.js';
import { openLightbox } from './lightbox.js';

const MODES = [
  { id: 'auto', label: 'Auto', hint: 'Aster adapts to what you ask' },
  { id: 'math', label: 'Math', hint: 'Step-by-step worked solutions with checks' },
  { id: 'study', label: 'Study', hint: 'Teaches, quizzes and checks your understanding' },
];

export function createComposer({ onSend, onStop, onModeChange, dropTarget }) {
  let busy = false;
  let mode = 'auto';
  /** @type {{ localId: number, file: File, status: string, att: any, error: string, url: string, ctl: AbortController }[]} */
  let items = [];
  let seq = 0;

  const limits = () => state.meta.limits;

  const input = h('textarea', { class: 'composer-input', rows: 1, placeholder: 'Message Aster', 'aria-label': 'Message', enterkeyhint: 'send' });
  const tray = h('div', { class: 'att-tray', hidden: true, 'aria-label': 'Attachments' });
  const fileInput = h('input', { type: 'file', multiple: true, hidden: true, tabindex: '-1', 'aria-hidden': 'true' });
  const attachBtn = h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Attach files', title: 'Attach images, PDFs or text files', onClick: () => fileInput.click() }, icon('paperclip'));
  const counter = h('span', { class: 'char-count', hidden: true });
  const sendBtn = h('button', { type: 'submit', class: 'send-btn', 'aria-label': 'Send message', disabled: true }, icon('send'));
  const modeBox = h('div', { class: 'mode', role: 'radiogroup', 'aria-label': 'Mode' });
  const modeBtns = new Map();
  for (const m of MODES) {
    const b = h('button', { type: 'button', role: 'radio', class: 'mode-btn', 'aria-checked': m.id === mode ? 'true' : 'false', title: m.hint, text: m.label, onClick: () => { setMode(m.id); onModeChange && onModeChange(m.id); input.focus(); } });
    modeBtns.set(m.id, b);
    modeBox.append(b);
  }
  modeBox.addEventListener('keydown', (e) => {
    if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
    e.preventDefault();
    const i = MODES.findIndex((m) => m.id === mode);
    const next = MODES[(i + (e.key === 'ArrowRight' ? 1 : MODES.length - 1)) % MODES.length].id;
    setMode(next); onModeChange && onModeChange(next); modeBtns.get(next).focus();
  });

  const form = h('form', { class: 'composer', autocomplete: 'off' },
    tray, input,
    h('div', { class: 'composer-bar' }, attachBtn, fileInput, modeBox, h('span', { class: 'spacer' }), counter, sendBtn));
  const el = h('div', { class: 'composer-wrap' }, form, h('p', { class: 'composer-note', text: 'Aster can make mistakes. Check important answers.' }));

  /* ---------- behaviour ---------- */
  function autosize() {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, Math.max(140, window.innerHeight * 0.4)) + 'px';
  }

  function effectiveText() {
    const t = input.value.trim();
    if (t) return t;
    if (items.some((i) => i.status === 'ready')) {
      return mode === 'math' ? 'Please solve the problem in the attached image, step by step.' : 'Please take a look at the attached file.';
    }
    return '';
  }

  function refresh() {
    const uploading = items.some((i) => i.status === 'uploading');
    const max = limits().maxMessageChars;
    const len = input.value.length;
    counter.hidden = len < max * 0.85;
    counter.textContent = `${len.toLocaleString()} / ${max.toLocaleString()}`;
    counter.classList.toggle('is-over', len > max);
    const canSend = !busy && !uploading && !!effectiveText() && len <= max;
    sendBtn.disabled = busy ? false : !canSend;
    sendBtn.replaceChildren(icon(busy ? 'stop' : 'send'));
    sendBtn.classList.toggle('is-stop', busy);
    sendBtn.setAttribute('aria-label', busy ? 'Stop generating' : 'Send message');
    sendBtn.title = busy ? 'Stop generating' : uploading ? 'Waiting for uploads…' : 'Send (Enter)';
    attachBtn.disabled = false;
  }

  function setMode(m) {
    if (!modeBtns.has(m)) m = 'auto';
    mode = m;
    for (const [id, b] of modeBtns) { b.setAttribute('aria-checked', id === m ? 'true' : 'false'); b.tabIndex = id === m ? 0 : -1; }
  }
  setMode('auto');

  function renderTray() {
    clear(tray);
    tray.hidden = items.length === 0;
    for (const it of items) {
      const isImg = it.att ? it.att.kind === 'image' : it.file.type.startsWith('image/');
      const thumb = isImg && it.url
        ? h('button', { type: 'button', class: 'tray-thumb', 'aria-label': `Preview ${it.file.name}`, onClick: () => openLightbox(it.url, it.file.name) }, h('img', { src: it.url, alt: '' }))
        : h('span', { class: 'tray-icon' }, icon('file'));
      tray.append(h('div', { class: `tray-item is-${it.status}` }, thumb,
        h('span', { class: 'tray-meta' },
          h('span', { class: 'tray-name', text: truncate(it.file.name, 28), title: it.file.name }),
          h('span', { class: 'tray-sub', text: it.status === 'uploading' ? 'Uploading…' : it.status === 'error' ? it.error : formatBytes(it.file.size) })),
        h('button', { type: 'button', class: 'icon-btn icon-btn-sm', 'aria-label': `Remove ${it.file.name}`, onClick: () => removeItem(it) }, icon('x'))));
    }
    refresh();
  }

  async function addFiles(fileList) {
    const files = Array.from(fileList || []);
    for (const file of files) {
      const v = validateFile(file, limits(), items.length);
      if (!v.ok) { toast(v.error, { kind: 'error', timeout: 7000 }); continue; }
      const it = { localId: ++seq, file, status: 'uploading', att: null, error: '', url: v.kind === 'image' ? URL.createObjectURL(file) : '', ctl: new AbortController() };
      items.push(it);
      renderTray();
      api.upload(file, it.ctl.signal).then(
        (att) => { it.att = att; it.status = 'ready'; renderTray(); },
        (e) => {
          if (e && e.name === 'AbortError') return;
          it.status = 'error';
          it.error = describeError(e.code, e.message).message.slice(0, 80);
          renderTray();
          toast(`Could not upload “${file.name}”. ${describeError(e.code, e.message).message}`, { kind: 'error', timeout: 7000 });
        });
    }
  }

  async function removeItem(it) {
    items = items.filter((x) => x !== it);
    if (it.status === 'uploading') it.ctl.abort();
    if (it.url) URL.revokeObjectURL(it.url);
    renderTray();
    if (it.status === 'ready' && it.att) {
      try { await api.deleteUpload(it.att.id); } catch (e) { toast(`Could not remove “${it.file.name}” from the server: ${e.message}`, { kind: 'error' }); }
    }
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (busy) { onStop && onStop(); return; }
    submit();
  });

  function submit() {
    if (busy || sendBtn.disabled) return;
    const text = effectiveText();
    if (!text) return;
    const ready = items.filter((i) => i.status === 'ready');
    const atts = ready.map((i) => i.att);
    const previews = ready.map((i) => i.url).filter(Boolean);
    const snapshot = { text: input.value, items: items.slice() };
    input.value = '';
    items = [];
    previews.forEach((u) => setTimeout(() => URL.revokeObjectURL(u), 30000));
    renderTray();
    autosize();
    onSend({ text, attachments: atts, restore: () => { input.value = snapshot.text; items = snapshot.items; renderTray(); autosize(); refresh(); } });
  }

  input.addEventListener('input', () => { autosize(); refresh(); });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229) {
      e.preventDefault();
      submit();
    }
  });
  input.addEventListener('paste', (e) => {
    const files = Array.from(e.clipboardData?.files || []);
    if (files.length) { e.preventDefault(); addFiles(files); }
  });
  fileInput.addEventListener('change', () => { addFiles(fileInput.files); fileInput.value = ''; });

  // Drag & drop anywhere over the chat pane.
  const target = dropTarget || el;
  const overlay = h('div', { class: 'drop-overlay', hidden: true }, icon('paperclip'), h('span', { text: 'Drop to attach' }));
  target.append(overlay);
  let depth = 0;
  const hasFiles = (e) => Array.from(e.dataTransfer?.types || []).includes('Files');
  target.addEventListener('dragenter', (e) => { if (hasFiles(e)) { e.preventDefault(); depth++; overlay.hidden = false; } });
  target.addEventListener('dragover', (e) => { if (hasFiles(e)) e.preventDefault(); });
  target.addEventListener('dragleave', (e) => { if (hasFiles(e) && --depth <= 0) { depth = 0; overlay.hidden = true; } });
  target.addEventListener('drop', (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault(); depth = 0; overlay.hidden = true;
    addFiles(e.dataTransfer.files);
  });

  window.addEventListener('resize', autosize);

  return {
    el,
    focus: () => input.focus(),
    getMode: () => mode,
    setMode,
    setBusy(b) { busy = b; refresh(); if (!b) announce('Response finished'); },
    setText(text, { focus = true } = {}) { input.value = text; autosize(); refresh(); if (focus) { input.focus(); input.setSelectionRange(text.length, text.length); } },
    getText: () => input.value,
    refresh,
    addFiles,
  };
}
