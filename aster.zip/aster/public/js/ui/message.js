/** One chat message (user or assistant) as a DOM view with streaming support. */
import { h, clear, copyText, announce } from '../dom.js';
import { icon, brandMark } from '../icons.js';
import { renderMarkdown } from '../lib/markdown.js';
import { sanitizeHtml } from '../sanitize.js';
import { hydrateWidgets } from './widgets.js';
import { describeError } from '../lib/errors.js';
import { formatBytes, truncate } from '../lib/format.js';
import { openLightbox } from './lightbox.js';

// name -> [icon, finished label, in-progress label]
const TOOLS = {
  calculate: ['calculator', 'Calculated', 'Calculating'],
  memory_save: ['bookmark', 'Saved to memory', 'Saving to memory'],
  memory_update: ['bookmark', 'Updated memory', 'Updating memory'],
  memory_forget: ['trash', 'Removed from memory', 'Removing from memory'],
  memory_list: ['bookmark', 'Checked memory', 'Checking memory'],
  conversation_memory: ['lock', 'Chat memory changed', 'Changing chat memory'],
};

export function attachmentNode(att) {
  if (att.kind === 'image') {
    return h('button', { type: 'button', class: 'att-thumb', 'aria-label': `Enlarge ${att.name}`, onClick: () => openLightbox(att.url, att.name) },
      h('img', { src: att.url, alt: att.name, loading: 'lazy' }));
  }
  return h('a', { class: 'att-chip', href: att.url, download: att.name, title: att.name },
    icon(att.kind === 'pdf' ? 'file' : 'file'), h('span', { class: 'att-name', text: truncate(att.name, 32) }), h('span', { class: 'att-size', text: formatBytes(att.size) }));
}

function iconAction(name, label, onClick, extra = '') {
  return h('button', { type: 'button', class: `icon-btn icon-btn-sm ${extra}`.trim(), 'aria-label': label, title: label, onClick }, icon(name));
}

export class MessageView {
  /**
   * @param {object} msg  Message (docs/API.md)
   * @param {object} hooks { isLast(view), onRegenerate(view), onRetry(view), onContinue(view), onEdit(view, text), onChange() }
   */
  constructor(msg, hooks) {
    this.msg = msg;
    this.hooks = hooks;
    this.role = msg.role;
    this.text = msg.content || '';
    this.streaming = msg.status === 'streaming';
    this.error = msg.error || null;
    this.tools = new Map();
    for (const t of msg.toolEvents || []) this.tools.set(t.id, { ...t, phase: 'result' });
    this._raf = 0;
    this._last = 0;
    this.role === 'user' ? this.buildUser() : this.buildAssistant();
  }

  /* ---------- user ---------- */
  buildUser() {
    this.bubble = h('div', { class: 'bubble' });
    this.actions = h('div', { class: 'msg-actions' });
    this.el = h('article', { class: 'msg msg-user', 'data-id': this.msg.id, 'aria-label': 'You said' }, this.bubble, this.actions);
    this.renderUser();
  }

  renderUser() {
    clear(this.bubble);
    const atts = this.msg.attachments || [];
    if (atts.length) this.bubble.append(h('div', { class: 'att-row' }, atts.map(attachmentNode)));
    if (this.text) this.bubble.append(h('div', { class: 'bubble-text', text: this.text }));
    clear(this.actions);
    this.copyBtn = iconAction('copy', 'Copy message', () => this.copy());
    this.actions.append(iconAction('pencil', 'Edit message', () => this.startEdit()), this.copyBtn);
  }

  startEdit() {
    if (this.editing) return;
    this.editing = true;
    const ta = h('textarea', { class: 'textarea edit-area', 'aria-label': 'Edit your message', rows: 3 });
    ta.value = this.text;
    const autosize = () => { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight + 2, 320) + 'px'; };
    ta.addEventListener('input', autosize);
    const save = h('button', { type: 'button', class: 'btn btn-primary btn-sm', text: 'Save and resend' });
    const cancel = h('button', { type: 'button', class: 'btn btn-sm', text: 'Cancel' });
    const finish = () => { this.editing = false; this.el.classList.remove('is-editing'); this.renderUser(); };
    cancel.addEventListener('click', finish);
    save.addEventListener('click', () => {
      const t = ta.value.trim();
      if (!t) return;
      this.editing = false;
      this.el.classList.remove('is-editing');
      this.hooks.onEdit(this, t);
    });
    ta.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') finish();
      else if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) save.click();
    });
    clear(this.bubble);
    clear(this.actions);
    this.el.classList.add('is-editing');
    this.bubble.append(ta, h('div', { class: 'edit-actions' }, cancel, save));
    requestAnimationFrame(() => { autosize(); ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); });
  }

  setUserMessage(msg) {
    this.msg = msg;
    this.text = msg.content || '';
    this.el.setAttribute('data-id', msg.id);
    this.editing = false;
    this.el.classList.remove('is-editing');
    this.renderUser();
  }

  /* ---------- assistant ---------- */
  buildAssistant() {
    this.toolsEl = h('div', { class: 'tools', 'aria-label': 'Tools used' });
    this.statusEl = h('div', { class: 'status-line', 'aria-live': 'polite' });
    this.body = h('div', { class: 'prose' });
    this.errorEl = h('div', { class: 'error-banner', role: 'alert', hidden: true });
    this.actions = h('div', { class: 'msg-actions' });
    this.el = h('article', { class: 'msg msg-assistant', 'data-id': this.msg.id, 'aria-label': 'Aster said' },
      h('div', { class: 'msg-mark' }, brandMark()),
      h('div', { class: 'msg-main' }, this.toolsEl, this.statusEl, this.body, this.errorEl, this.actions));
    this.renderTools();
    if (this.streaming && !this.text) this.setThinking(true);
    this.renderBody(!this.streaming);
    this.renderError();
    this.updateActions();
    this.el.classList.toggle('is-streaming', this.streaming);
  }

  setThinking(on, note = '') {
    clear(this.statusEl);
    this.thinking = on;
    if (!on) return;
    this.statusEl.append(h('span', { class: 'thinking' }, brandMark('thinking-mark'), h('span', { class: 'thinking-text', text: note || 'Thinking…' })));
  }

  setRetryNotice(message, retryInMs) {
    clear(this.statusEl);
    this.statusEl.append(h('span', { class: 'retry-note' }, icon('clock'), message + (retryInMs ? ` Retrying in ${Math.max(1, Math.round(retryInMs / 1000))} s…` : '')));
  }

  appendDelta(t) {
    if (!t) return;
    if (this.thinking || this.statusEl.firstChild) { clear(this.statusEl); this.thinking = false; }
    this.text += t;
    this.scheduleRender();
  }

  scheduleRender() {
    if (this._raf) return;
    const tick = () => {
      this._raf = 0;
      if (performance.now() - this._last < 60) { this._raf = requestAnimationFrame(tick); return; }
      this._last = performance.now();
      this.renderBody(false);
      this.hooks.onChange && this.hooks.onChange();
    };
    this._raf = requestAnimationFrame(tick);
  }

  renderBody(final) {
    if (this._raf) { cancelAnimationFrame(this._raf); this._raf = 0; }
    if (!this.text) { clear(this.body); return; }
    try {
      this.body.innerHTML = sanitizeHtml(renderMarkdown(this.text, { streaming: !final }));
      if (final) hydrateWidgets(this.body);
    } catch (e) {
      console.error('[aster] render failed', e);
      this.body.textContent = this.text;
    }
  }

  addToolEvent(evt) {
    const prev = this.tools.get(evt.id) || {};
    this.tools.set(evt.id, { ...prev, ...evt, summary: evt.summary ?? prev.summary });
    this.renderTools();
  }

  renderTools() {
    clear(this.toolsEl);
    this.toolsEl.hidden = this.tools.size === 0;
    for (const t of this.tools.values()) {
      const [ic, label, doing] = TOOLS[t.name] || ['spark', t.name, t.name];
      const pending = t.phase === 'start';
      const failed = t.ok === false;
      this.toolsEl.append(h('span', { class: `tool-chip${pending ? ' is-pending' : ''}${failed ? ' is-fail' : ''}`, title: t.summary || '' },
        icon(ic), h('span', { class: 'tool-label', text: pending ? `${doing}…` : failed ? `${label} failed` : label }),
        t.summary && !pending && h('span', { class: 'tool-sum', text: truncate(t.summary, 80) })));
    }
  }

  setError(err) {
    this.error = err;
    this.streaming = false;
    this.setThinking(false);
    this.renderBody(true);
    this.renderError();
    this.updateActions();
    this.el.classList.remove('is-streaming');
  }

  renderError() {
    clear(this.errorEl);
    this.errorEl.hidden = !this.error;
    if (!this.error) return;
    const d = describeError(this.error.code, this.error.message);
    this.errorEl.append(icon('alert'), h('div', { class: 'error-text' }, h('strong', { text: d.title }), h('span', { text: ' ' + d.message })));
  }

  /** Server confirmed the message (start event) — adopt its id. */
  bind(msg) {
    this.msg = msg;
    this.el.setAttribute('data-id', msg.id);
  }

  /** Reset to an empty streaming state (regenerate in place). */
  restart() {
    this.text = '';
    this.error = null;
    this.tools.clear();
    this.streaming = true;
    this.msg = { ...this.msg, stopReason: null, status: 'streaming', error: null };
    clear(this.body);
    this.renderTools();
    this.renderError();
    this.setThinking(true);
    this.el.classList.add('is-streaming');
    this.updateActions();
  }

  finalize(msg) {
    this.msg = msg;
    this.text = msg.content ?? this.text;
    this.streaming = false;
    this.error = msg.error || this.error;
    this.setThinking(false);
    clear(this.statusEl);
    this.renderBody(true);
    this.renderError();
    this.el.classList.remove('is-streaming');
    this.el.setAttribute('data-id', msg.id);
    this.updateActions();
  }

  stopped() {
    this.streaming = false;
    this.msg = { ...this.msg, status: 'stopped' };
    this.setThinking(false);
    clear(this.statusEl);
    this.renderBody(true);
    this.el.classList.remove('is-streaming');
    this.updateActions();
  }

  async copy() {
    const ok = await copyText(this.text);
    const btn = this.copyBtn;
    if (!btn) return;
    btn.replaceChildren(icon(ok ? 'check' : 'x'));
    btn.classList.toggle('is-on', ok);
    announce(ok ? 'Copied to clipboard' : 'Copy failed');
    setTimeout(() => { btn.replaceChildren(icon('copy')); btn.classList.remove('is-on'); }, 1500);
  }

  updateActions() {
    if (this.role !== 'assistant') return;
    clear(this.actions);
    if (this.streaming) return;
    const last = this.hooks.isLast(this);
    this.copyBtn = null;
    if (this.text) {
      this.copyBtn = iconAction('copy', 'Copy response', () => this.copy());
      this.actions.append(this.copyBtn);
    }
    if (this.error && this.error.code !== 'aborted' || this.msg.status === 'error') {
      this.actions.append(h('button', { type: 'button', class: 'btn btn-sm', onClick: () => this.hooks.onRetry(this) }, icon('refresh'), 'Retry'));
    } else if (last) {
      this.actions.append(iconAction('refresh', 'Regenerate response', () => this.hooks.onRegenerate(this)));
    }
    if (last && this.msg.stopReason === 'max_tokens' && !this.error) {
      this.actions.append(h('button', { type: 'button', class: 'btn btn-sm', onClick: () => this.hooks.onContinue(this) }, icon('chevronRight'), 'Continue'));
    }
    if (this.msg.status === 'stopped') this.actions.append(h('span', { class: 'msg-note', text: 'Stopped' }));
    if (this.msg.stopReason === 'max_tokens' && !this.error) this.actions.append(h('span', { class: 'msg-note', text: 'Reached the length limit' }));
    if (this.msg.model) this.actions.append(h('span', { class: 'msg-meta', text: this.msg.model }));
  }
}
