import { h } from '../dom.js';
import { icon } from '../icons.js';

/** toast(message, { kind: 'info'|'error'|'ok', action: { label, onClick }, timeout }) */
export function toast(message, { kind = 'info', action, timeout = 5000 } = {}) {
  const host = document.getElementById('toasts');
  if (!host) return;
  const el = h('div', { class: `toast toast-${kind}` },
    icon(kind === 'error' ? 'alert' : kind === 'ok' ? 'check' : 'info'),
    h('span', { class: 'toast-text', text: message }),
    action && h('button', { type: 'button', class: 'toast-action', text: action.label, onClick: () => { action.onClick(); close(); } }),
    h('button', { type: 'button', class: 'icon-btn icon-btn-sm', 'aria-label': 'Dismiss', onClick: () => close() }, icon('x')),
  );
  let timer;
  function close() {
    clearTimeout(timer);
    el.classList.add('is-leaving');
    setTimeout(() => el.remove(), 160);
  }
  host.append(el);
  while (host.children.length > 4) host.firstChild.remove();
  if (timeout) timer = setTimeout(close, timeout);
  return close;
}
