/** Interactive quiz + flashcard widgets, hydrated from `.widget[data-spec]` placeholders. */
import { h, clear } from '../dom.js';
import { icon } from '../icons.js';
import { renderInline } from '../lib/markdown.js';
import { sanitizeHtml } from '../sanitize.js';

function rich(text, tag = 'span') {
  const el = h(tag, { class: 'rich' });
  el.innerHTML = sanitizeHtml(renderInline(String(text ?? '')));
  return el;
}

export function hydrateWidgets(root) {
  for (const el of root.querySelectorAll('.widget[data-widget]:not([data-ready])')) {
    el.setAttribute('data-ready', '1');
    let spec;
    try { spec = JSON.parse(el.getAttribute('data-spec') || ''); } catch { continue; }
    if (el.getAttribute('data-widget') === 'quiz') mountQuiz(el, spec);
    else if (el.getAttribute('data-widget') === 'flashcards') mountFlashcards(el, spec);
  }
}

const LETTERS = 'ABCDEFGH';

function mountQuiz(root, spec) {
  const qs = spec.questions;
  let i = 0;
  let score = 0;
  let answered = null; // chosen index for the current question
  const results = [];

  function render() {
    clear(root);
    root.classList.add('widget-ready');
    const head = h('div', { class: 'widget-head' },
      h('span', { class: 'widget-title', text: spec.title || 'Quiz' }),
      h('span', { class: 'widget-meta', text: i < qs.length ? `Question ${i + 1} of ${qs.length}` : 'Finished' }));
    root.append(head);

    if (i >= qs.length) {
      const pct = Math.round((score / qs.length) * 100);
      root.append(
        h('div', { class: 'quiz-result' },
          h('p', { class: 'quiz-score', text: `${score} of ${qs.length} correct` }),
          h('p', { class: 'widget-note', text: pct === 100 ? 'A clean sweep.' : pct >= 60 ? 'Solid. Review the ones you missed and try again.' : 'Worth another pass. Ask Aster to explain the questions you missed.' }),
          h('ul', { class: 'quiz-review' }, results.map((r, n) =>
            h('li', { class: r.ok ? 'is-right' : 'is-wrong' }, icon(r.ok ? 'check' : 'x'), h('span', { class: 'quiz-review-q' }, rich(qs[n].q))))),
          h('div', { class: 'widget-actions' },
            h('button', { type: 'button', class: 'btn btn-sm', onClick: () => { i = 0; score = 0; answered = null; results.length = 0; render(); } }, icon('refresh'), 'Try again'))));
      return;
    }

    const q = qs[i];
    const group = h('div', { class: 'quiz-options', role: 'group', 'aria-label': 'Answer choices' });
    q.options.forEach((opt, idx) => {
      const btn = h('button', { type: 'button', class: 'quiz-option', 'data-index': idx, onClick: () => choose(idx) },
        h('span', { class: 'quiz-letter', text: LETTERS[idx] || String(idx + 1) }), rich(opt));
      group.append(btn);
    });
    const feedback = h('div', { class: 'quiz-feedback', 'aria-live': 'polite' });
    root.append(h('div', { class: 'quiz-q' }, rich(q.q, 'div')), group, feedback);

    function choose(idx) {
      if (answered !== null) return;
      answered = idx;
      const ok = idx === q.answer;
      if (ok) score++;
      results[i] = { ok };
      for (const b of group.children) {
        const n = Number(b.getAttribute('data-index'));
        b.disabled = true;
        if (n === q.answer) b.classList.add('is-correct');
        else if (n === idx) b.classList.add('is-wrong');
        if (n === idx) b.setAttribute('aria-pressed', 'true');
      }
      feedback.append(
        h('p', { class: `quiz-verdict ${ok ? 'is-right' : 'is-wrong'}` }, icon(ok ? 'check' : 'x'),
          ok ? 'Correct.' : `Not quite. The answer is ${LETTERS[q.answer] || q.answer + 1}.`),
        q.explanation && h('div', { class: 'quiz-explain' }, rich(q.explanation, 'div')),
        h('div', { class: 'widget-actions' },
          h('button', { type: 'button', class: 'btn btn-primary btn-sm', onClick: () => { i++; answered = null; render(); } },
            i + 1 < qs.length ? 'Next question' : 'See results', icon('chevronRight'))));
      feedback.querySelector('.btn')?.focus({ preventScroll: false });
    }
  }
  render();
}

function mountFlashcards(root, spec) {
  const cards = spec.cards;
  let deck = cards.map((_, n) => n);
  let pos = 0;
  let flipped = false;
  let known = new Set();
  let missed = new Set();

  function shuffle() {
    for (let n = deck.length - 1; n > 0; n--) {
      const m = Math.floor(Math.random() * (n + 1));
      [deck[n], deck[m]] = [deck[m], deck[n]];
    }
    pos = 0; flipped = false;
  }

  function mark(isKnown) {
    const id = deck[pos];
    (isKnown ? known : missed).add(id);
    (isKnown ? missed : known).delete(id);
    pos++; flipped = false; render();
  }

  function render() {
    clear(root);
    root.classList.add('widget-ready');
    root.append(h('div', { class: 'widget-head' },
      h('span', { class: 'widget-title', text: spec.title || 'Flashcards' }),
      h('span', { class: 'widget-meta', text: pos < deck.length ? `Card ${pos + 1} of ${deck.length}` : 'Finished' })));

    if (pos >= deck.length) {
      const again = deck.filter((id) => missed.has(id));
      root.append(h('div', { class: 'quiz-result' },
        h('p', { class: 'quiz-score', text: `You knew ${known.size} of ${cards.length}` }),
        h('p', { class: 'widget-note', text: again.length ? `${again.length} card${again.length === 1 ? '' : 's'} to go again.` : 'You knew every card.' }),
        h('div', { class: 'widget-actions' },
          again.length > 0 && h('button', { type: 'button', class: 'btn btn-primary btn-sm', onClick: () => { deck = again; missed = new Set(); pos = 0; flipped = false; render(); } }, icon('refresh'), `Study missed (${again.length})`),
          h('button', { type: 'button', class: 'btn btn-sm', onClick: () => { deck = cards.map((_, n) => n); known = new Set(); missed = new Set(); pos = 0; flipped = false; render(); } }, 'Restart deck'))));
      return;
    }

    const c = cards[deck[pos]];
    const card = h('button', { type: 'button', class: `fc-card${flipped ? ' is-flipped' : ''}`, 'aria-label': flipped ? 'Showing the back. Flip to the front' : 'Showing the front. Flip to the back', onClick: () => { flipped = !flipped; card.classList.toggle('is-flipped', flipped); card.setAttribute('aria-label', flipped ? 'Showing the back. Flip to the front' : 'Showing the front. Flip to the back'); judge.hidden = !flipped; } },
      h('span', { class: 'fc-inner' },
        h('span', { class: 'fc-face fc-front', 'aria-hidden': flipped ? 'true' : null }, h('span', { class: 'fc-side', text: 'Front' }), rich(c.front, 'span')),
        h('span', { class: 'fc-face fc-back', 'aria-hidden': flipped ? null : 'true' }, h('span', { class: 'fc-side', text: 'Back' }), rich(c.back, 'span'))));
    const judge = h('div', { class: 'fc-judge', hidden: !flipped },
      h('button', { type: 'button', class: 'btn btn-sm', onClick: () => mark(false) }, icon('undo'), 'Again'),
      h('button', { type: 'button', class: 'btn btn-primary btn-sm', onClick: () => mark(true) }, icon('check'), 'Knew it'));
    root.append(card, judge,
      h('div', { class: 'widget-actions fc-nav' },
        h('button', { type: 'button', class: 'btn btn-quiet btn-sm', disabled: pos === 0, onClick: () => { pos--; flipped = false; render(); } }, icon('chevronLeft'), 'Previous'),
        h('button', { type: 'button', class: 'btn btn-quiet btn-sm', onClick: () => { shuffle(); render(); } }, icon('shuffle'), 'Shuffle'),
        h('button', { type: 'button', class: 'btn btn-quiet btn-sm', onClick: () => { pos++; flipped = false; render(); } }, 'Skip', icon('chevronRight'))));
  }
  render();
}
