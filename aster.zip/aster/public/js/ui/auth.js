/** Password sign-in screen (only when the server reports authRequired). */
import { h, clear } from '../dom.js';
import { brandMark } from '../icons.js';
import { api } from '../api.js';
import { describeError } from '../lib/errors.js';

export function showLogin(root, { appName, onSuccess }) {
  clear(root);
  root.className = 'login-screen';
  root.removeAttribute('aria-busy');
  const pw = h('input', { class: 'input', id: 'login-pw', type: 'password', autocomplete: 'current-password', required: true, 'aria-describedby': 'login-err' });
  const err = h('p', { id: 'login-err', class: 'form-error', role: 'alert', hidden: true });
  const btn = h('button', { type: 'submit', class: 'btn btn-primary login-btn', text: 'Sign in' });
  const form = h('form', { class: 'login-card' },
    h('div', { class: 'login-brand' }, brandMark('login-mark'), h('h1', { text: appName })),
    h('p', { class: 'login-lede', text: 'Enter your password to continue.' }),
    h('div', { class: 'field' }, h('label', { for: 'login-pw', text: 'Password' }), pw), err, btn);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    btn.disabled = true; err.hidden = true;
    try {
      await api.login(pw.value);
      pw.value = '';
      onSuccess();
    } catch (e2) {
      err.hidden = false;
      err.textContent = e2.code === 'invalid_password' ? 'That password is not correct.' : describeError(e2.code, e2.message).message;
      btn.disabled = false; pw.select();
    }
  });
  root.append(form);
  pw.focus();
}
