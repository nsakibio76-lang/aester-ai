import { h } from '../dom.js';
import { icon } from '../icons.js';

export function openLightbox(src, alt) {
  const dialog = h('dialog', { class: 'lightbox', 'aria-label': alt || 'Image preview' },
    h('button', { type: 'button', class: 'icon-btn lightbox-close', 'aria-label': 'Close preview', onClick: () => dialog.close() }, icon('x')),
    h('img', { src, alt: alt || '' }));
  dialog.addEventListener('click', (e) => { if (e.target !== dialog.querySelector('button')) dialog.close(); });
  dialog.addEventListener('close', () => dialog.remove());
  document.body.append(dialog);
  dialog.showModal();
}
