/** Sidebar: new chat, search, conversation list (rename / archive / delete), navigation. */
import { h, clear, debounce } from '../dom.js';
import { icon, brandMark } from '../icons.js';
import { api } from '../api.js';
import { state, on, emit, upsertConversation } from '../state.js';
import { describeError } from '../lib/errors.js';
import { sanitizeSnippet } from '../sanitize.js';
import { toast } from './toast.js';
import { confirmDialog } from './dialog.js';

function groupLabel(iso) {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return 'Earlier';
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const day = 86400000;
  if (t >= start.getTime()) return 'Today';
  if (t >= start.getTime() - day) return 'Yesterday';
  if (t >= start.getTime() - 7 * day) return 'Previous 7 days';
  if (t >= start.getTime() - 30 * day) return 'Previous 30 days';
  return 'Earlier';
}

export function createSidebar({ shell }) {
  let loading = false;
  let renamingId = null;
  let loadSeq = 0;

  const searchInput = h('input', { class: 'search-input', type: 'search', placeholder: 'Search chats', 'aria-label': 'Search conversations', autocomplete: 'off' });
  const clearBtn = h('button', { type: 'button', class: 'icon-btn icon-btn-sm search-clear', 'aria-label': 'Clear search', hidden: true, onClick: () => { searchInput.value = ''; setQuery(''); searchInput.focus(); } }, icon('x'));
  const chatsTab = h('button', { type: 'button', class: 'tab', 'aria-pressed': 'true', text: 'Chats', onClick: () => setArchived(false) });
  const archTab = h('button', { type: 'button', class: 'tab', 'aria-pressed': 'false', onClick: () => setArchived(true) }, icon('archive'), 'Archived');
  const list = h('ul', { class: 'convo-list', 'aria-label': 'Conversations' });
  const moreBtn = h('button', { type: 'button', class: 'btn btn-quiet btn-sm more-btn', text: 'Show more', hidden: true, onClick: () => load({ append: true }) });
  const status = h('p', { class: 'list-status', 'aria-live': 'polite' });
  const memoryLink = h('a', { class: 'foot-link', href: '/memory', onClick: (e) => nav(e, '/memory') }, icon('bookmark'), h('span', { text: 'Memory' }));
  const settingsBtn = h('button', { type: 'button', class: 'foot-link', onClick: () => shell.openSettings() }, icon('sliders'), h('span', { text: 'Settings' }));
  const logoutBtn = h('button', { type: 'button', class: 'foot-link', hidden: !state.meta.authRequired, onClick: () => shell.logout() }, icon('logout'), h('span', { text: 'Sign out' }));

  const el = h('aside', { class: 'sidebar', 'aria-label': 'Sidebar' },
    h('div', { class: 'sidebar-head' },
      h('a', { class: 'brand', href: '/', 'aria-label': `${state.meta.appName} home`, onClick: (e) => nav(e, '/') }, brandMark(), h('span', { class: 'brand-name', text: state.meta.appName })),
      h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Close sidebar', onClick: () => shell.toggleSidebar() }, icon('panel'))),
    h('div', { class: 'sidebar-top' },
      h('a', { class: 'btn btn-primary btn-new', href: '/', onClick: (e) => nav(e, '/') }, icon('plus'), 'New chat'),
      h('div', { class: 'search' }, icon('search'), searchInput, clearBtn),
      h('div', { class: 'tabs', role: 'group', 'aria-label': 'Conversation list' }, chatsTab, archTab)),
    h('nav', { class: 'sidebar-scroll', 'aria-label': 'Conversation history' }, list, status, moreBtn),
    h('div', { class: 'sidebar-foot' }, memoryLink, settingsBtn, logoutBtn));

  function nav(e, path) {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return;
    e.preventDefault();
    shell.navigate(path);
  }

  /* ---------- data ---------- */
  async function load({ append = false } = {}) {
    if (loading && append) return;
    const seq = ++loadSeq;
    loading = true;
    const offset = append ? state.conversations.length : 0;
    const version = state.listVersion;
    try {
      const res = await api.listConversations({ archived: state.archivedView, q: state.query, limit: 50, offset });
      if (seq !== loadSeq) return;
      if (version !== state.listVersion && !append) {
        // The list changed locally while this request was in flight (e.g. a chat was just created): refetch.
        loading = false;
        return load();
      }
      state.conversations = append ? state.conversations.concat(res.conversations) : res.conversations;
      state.hasMore = !!res.hasMore;
      status.textContent = '';
      loading = false;
      render();
    } catch (e) {
      if (seq !== loadSeq) return;
      if (e.code !== 'unauthenticated') {
        status.textContent = describeError(e.code, e.message).message;
        status.classList.add('is-error');
      }
    } finally {
      if (seq === loadSeq) loading = false;
    }
  }

  const runSearch = debounce(() => load(), 250);
  function setQuery(q) {
    state.query = q.trim();
    clearBtn.hidden = !q;
    runSearch();
  }
  searchInput.addEventListener('input', () => setQuery(searchInput.value));
  searchInput.addEventListener('keydown', (e) => { if (e.key === 'Escape' && searchInput.value) { searchInput.value = ''; setQuery(''); } });

  function setArchived(v) {
    if (state.archivedView === v) return;
    state.archivedView = v;
    chatsTab.setAttribute('aria-pressed', String(!v));
    archTab.setAttribute('aria-pressed', String(v));
    state.conversations = [];
    render();
    load();
  }

  /* ---------- rendering ---------- */
  function render() {
    clear(list);
    moreBtn.hidden = !state.hasMore;
    if (!state.conversations.length) {
      if (!loading) {
        status.classList.remove('is-error');
        status.textContent = state.query ? `No chats match “${state.query}”.` : state.archivedView ? 'Nothing archived.' : 'Your conversations will appear here.';
      }
      return;
    }
    status.textContent = '';
    let lastGroup = null;
    for (const c of state.conversations) {
      if (!state.query) {
        const g = groupLabel(c.updatedAt);
        if (g !== lastGroup) { list.append(h('li', { class: 'convo-group', role: 'presentation', text: g })); lastGroup = g; }
      }
      list.append(renderItem(c));
    }
  }

  function renderItem(c) {
    const active = state.activeId === c.id && shell.currentView() === 'chat';
    const li = h('li', { class: `convo${active ? ' is-active' : ''}`, 'data-id': c.id });
    if (renamingId === c.id) {
      const input = h('input', { class: 'rename-input', 'aria-label': 'Conversation title', maxlength: 120, value: c.title });
      let done = false;
      const commit = async (save) => {
        if (done) return; done = true;
        renamingId = null;
        const next = input.value.trim();
        if (save && next && next !== c.title) {
          try {
            const updated = await api.patchConversation(c.id, { title: next });
            upsertConversation(updated);
            shell.conversationChanged(updated);
          } catch (e) { toast(describeError(e.code, e.message).message, { kind: 'error' }); }
        }
        render();
      };
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); commit(true); } else if (e.key === 'Escape') { e.preventDefault(); commit(false); } });
      input.addEventListener('blur', () => commit(true));
      li.append(h('div', { class: 'convo-rename' }, input));
      setTimeout(() => { input.focus(); input.select(); }, 0);
      return li;
    }
    const link = h('a', { class: 'convo-link', href: `/c/${encodeURIComponent(c.id)}`, 'aria-current': active ? 'page' : null, onClick: (e) => nav(e, `/c/${encodeURIComponent(c.id)}`) },
      h('span', { class: 'convo-title' }, c.memoryEnabled === false && h('span', { class: 'convo-private', title: 'Private chat' }, icon('lock')), h('span', { class: 'convo-title-text', text: c.title || 'New chat' })));
    if (c.snippet) {
      const sn = h('span', { class: 'convo-snippet' });
      sn.innerHTML = sanitizeSnippet(c.snippet);
      link.append(sn);
    }
    const actions = h('div', { class: 'convo-actions' },
      h('button', { type: 'button', class: 'icon-btn icon-btn-sm', 'aria-label': `Rename ${c.title}`, title: 'Rename', onClick: () => { renamingId = c.id; render(); } }, icon('pencil')),
      h('button', { type: 'button', class: 'icon-btn icon-btn-sm', 'aria-label': `${c.archived ? 'Unarchive' : 'Archive'} ${c.title}`, title: c.archived ? 'Unarchive' : 'Archive', onClick: () => archive(c) }, icon(c.archived ? 'inbox' : 'archive')),
      h('button', { type: 'button', class: 'icon-btn icon-btn-sm', 'aria-label': `Delete ${c.title}`, title: 'Delete', onClick: () => remove(c) }, icon('trash')));
    li.append(link, actions);
    return li;
  }

  async function archive(c) {
    const next = !c.archived;
    try {
      const updated = await api.patchConversation(c.id, { archived: next });
      upsertConversation(updated);
      shell.conversationChanged(updated);
      toast(next ? 'Chat archived.' : 'Chat restored.', { kind: 'ok', action: { label: 'Undo', onClick: async () => {
        try { const back = await api.patchConversation(c.id, { archived: !next }); upsertConversation(back); shell.conversationChanged(back); load(); } catch (e) { toast(describeError(e.code, e.message).message, { kind: 'error' }); }
      } } });
    } catch (e) { toast(describeError(e.code, e.message).message, { kind: 'error' }); }
  }

  async function remove(c) {
    const ok = await confirmDialog({ title: 'Delete this chat?', message: `“${c.title}” and all its messages will be permanently deleted. This cannot be undone.`, confirmLabel: 'Delete chat', danger: true });
    if (!ok) return;
    try {
      await api.deleteConversation(c.id);
      state.conversations = state.conversations.filter((x) => x.id !== c.id);
      render();
      shell.conversationRemoved(c.id);
      toast('Chat deleted.', { kind: 'ok' });
    } catch (e) { toast(describeError(e.code, e.message).message, { kind: 'error' }); }
  }

  on('conversations', render);
  on('active', render);

  return { el, load, render, focusSearch: () => searchInput.focus(), setMemoryActive: (v) => memoryLink.classList.toggle('is-active', v) };
}
