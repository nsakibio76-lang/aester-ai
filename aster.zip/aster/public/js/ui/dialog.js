import { h } from '../dom.js';
import { icon } from '../icons.js';

/**
 * Open a modal built on <dialog>. Returns { dialog, close }.
 * `build(close)` returns the dialog body nodes.
 */
export function openDialog({ title, wide = false, labelledBy, build, onClose }) {
  const titleId = labelledBy || 'dlg-' + Math.random().toString(36).slice(2, 8);
  const dialog = h('dialog', { class: `dialog${wide ? ' dialog-wide' : ''}`, 'aria-labelledby': titleId });
  const close = (value) => {
    if (dialog.open) dialog.close(value);
  };
  const head = title
    ? h('header', { class: 'dialog-head' },
        h('h2', { id: titleId, class: 'dialog-title', text: title }),
        h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Close', onClick: () => close('') }, icon('x')))
    : null;
  dialog.append(...[head, ...[].concat(build(close))].filter(Boolean));
  dialog.addEventListener('close', () => { dialog.remove(); if (onClose) onClose(dialog.returnValue); });
  dialog.addEventListener('click', (e) => { if (e.target === dialog) close(''); });
  document.body.append(dialog);
  dialog.showModal();
  return { dialog, close };
}

/** Promise-based confirmation. Resolves true when confirmed. */
export function confirmDialog({ title, message, confirmLabel = 'Confirm', danger = false }) {
  return new Promise((resolve) => {
    let result = false;
    openDialog({
      title,
      build: (close) => [
        h('div', { class: 'dialog-body' }, h('p', { class: 'dialog-text', text: message })),
        h('footer', { class: 'dialog-foot' },
          h('button', { type: 'button', class: 'btn', text: 'Cancel', onClick: () => close('') }),
          h('button', { type: 'button', class: `btn ${danger ? 'btn-danger-solid' : 'btn-primary'}`, text: confirmLabel, autofocus: true, onClick: () => { result = true; close('ok'); } })),
      ],
      onClose: () => resolve(result),
    });
  });
}
