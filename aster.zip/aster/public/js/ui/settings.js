/** Settings dialog: appearance, assistant behaviour, memory, and data (export / delete everything). */
import { h, debounce } from '../dom.js';
import { icon } from '../icons.js';
import { api } from '../api.js';
import { state } from '../state.js';
import { describeError } from '../lib/errors.js';
import { applyTheme } from '../theme.js';
import { openDialog } from './dialog.js';
import { toast } from './toast.js';

const PHRASE = 'DELETE ALL MY DATA';

function select(id, value, options) {
  const s = h('select', { class: 'select', id }, options.map(([v, l]) => h('option', { value: v, text: l, selected: v === value })));
  return s;
}

export function openSettings({ shell }) {
  const s = state.settings;
  const meta = state.meta;
  const saved = h('span', { class: 'saved-note', 'aria-live': 'polite' });
  let savedTimer;

  async function save(patch) {
    try {
      state.settings = await api.putSettings(patch);
      saved.textContent = 'Saved';
      clearTimeout(savedTimer);
      savedTimer = setTimeout(() => { saved.textContent = ''; }, 1800);
      shell.settingsChanged();
    } catch (e) {
      saved.textContent = '';
      toast(`Could not save: ${describeError(e.code, e.message).message}`, { kind: 'error' });
    }
  }
  let pending = {};
  const flushPending = () => { const p = pending; pending = {}; if (Object.keys(p).length) save(p); };
  const saveText = debounce(flushPending, 600);
  const queue = (p) => { Object.assign(pending, p); saveText(); };

  // Theme (segmented radios)
  const themeBox = h('div', { class: 'segmented', role: 'radiogroup', 'aria-label': 'Theme' });
  const themeBtns = [];
  for (const [v, l] of [['system', 'System'], ['light', 'Light'], ['dark', 'Dark']]) {
    const b = h('button', { type: 'button', role: 'radio', class: 'seg-btn', 'aria-checked': String(s.theme === v), text: l, onClick: () => {
      for (const x of themeBtns) x.setAttribute('aria-checked', String(x === b));
      applyTheme(v); save({ theme: v });
    } });
    themeBtns.push(b); themeBox.append(b);
  }

  const defaultModel = (meta.models || []).find((m) => m.id === meta.defaultModel);
  const modelSel = select('set-model', s.model || '', [['', `Default${defaultModel ? ` (${defaultModel.label})` : ''}`], ...(meta.models || []).map((m) => [m.id, m.label])]);
  modelSel.addEventListener('change', () => save({ model: modelSel.value || null }));
  const styleSel = select('set-style', s.responseStyle, [['concise', 'Concise'], ['balanced', 'Balanced'], ['detailed', 'Detailed']]);
  styleSel.addEventListener('change', () => save({ responseStyle: styleSel.value }));
  const levelSel = select('set-level', s.explainLevel, [['auto', 'Adapt to me'], ['beginner', 'Beginner'], ['intermediate', 'Intermediate'], ['advanced', 'Advanced']]);
  levelSel.addEventListener('change', () => save({ explainLevel: levelSel.value }));
  const lang = h('input', { class: 'input', id: 'set-lang', maxlength: 40, placeholder: 'Same language as my message', value: s.language || '' });
  lang.addEventListener('input', () => queue({ language: lang.value.trim() }));
  const instr = h('textarea', { class: 'textarea', id: 'set-instr', maxlength: 2000, rows: 4, placeholder: 'For example: Use metric units. Show Python examples. Keep answers under 200 words unless I ask for more.' });
  instr.value = s.customInstructions || '';
  const instrCount = h('span', { class: 'hint', text: `${instr.value.length} / 2000` });
  instr.addEventListener('input', () => { instrCount.textContent = `${instr.value.length} / 2000`; queue({ customInstructions: instr.value }); });

  const autoInput = h('input', { type: 'checkbox', checked: !!s.autoMemory, onChange: () => save({ autoMemory: autoInput.checked }) });

  // Data
  const withFiles = h('input', { type: 'checkbox', id: 'exp-files' });
  const exportBtn = h('button', { type: 'button', class: 'btn', onClick: async () => {
    exportBtn.disabled = true;
    try {
      const { blob, filename } = await api.exportData(withFiles.checked);
      const url = URL.createObjectURL(blob);
      const a = h('a', { href: url, download: filename });
      document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      toast('Export downloaded.', { kind: 'ok' });
    } catch (e) { toast(`Export failed: ${describeError(e.code, e.message).message}`, { kind: 'error' }); }
    finally { exportBtn.disabled = false; }
  } }, icon('download'), 'Export my data');

  const confirmInput = h('input', { class: 'input', id: 'del-confirm', placeholder: PHRASE, autocomplete: 'off', 'aria-describedby': 'del-hint' });
  const delBtn = h('button', { type: 'button', class: 'btn btn-danger-solid', disabled: true, onClick: async () => {
    delBtn.disabled = true;
    try {
      const r = await api.deleteAllData(confirmInput.value);
      const d = r && r.deleted ? r.deleted : {};
      toast(`Deleted ${d.conversations ?? 0} conversations, ${d.memories ?? 0} memories and ${d.attachments ?? 0} files.`, { kind: 'ok', timeout: 4000 });
      setTimeout(() => location.assign('/'), 900);
    } catch (e) { toast(`Could not delete: ${describeError(e.code, e.message).message}`, { kind: 'error' }); delBtn.disabled = confirmInput.value !== PHRASE; }
  } }, icon('trash'), 'Delete everything');
  confirmInput.addEventListener('input', () => { delBtn.disabled = confirmInput.value !== PHRASE; });

  const section = (title, ...kids) => h('section', { class: 'settings-section' }, h('h3', { class: 'settings-h', text: title }), ...kids);
  const row = (labelText, control, hint) => h('div', { class: 'field' }, h('label', { for: control.id, text: labelText }), control, hint && h('p', { class: 'hint', text: hint }));

  openDialog({
    title: 'Settings',
    wide: true,
    build: (close) => [
      h('div', { class: 'dialog-body settings-body' },
        section('Appearance', h('div', { class: 'field' }, h('span', { class: 'field-label', text: 'Theme' }), themeBox)),
        section('Assistant',
          row('Model', modelSel, 'Used for new messages. You can change it at any time.'),
          h('div', { class: 'field-grid' }, row('Response length', styleSel), row('Explain at', levelSel)),
          row('Reply language', lang, 'Leave empty to reply in the language you write in.'),
          h('div', { class: 'field' }, h('label', { for: 'set-instr', text: 'Custom instructions' }), instr, h('div', { class: 'field-foot' }, h('p', { class: 'hint', text: 'Added to every conversation.' }), instrCount))),
        section('Memory',
          h('div', { class: 'panel-row' },
            h('div', { class: 'panel-row-text' }, h('strong', { text: 'Automatic memory' }), h('p', { class: 'hint', text: 'Save lasting facts and goals from your chats. Private chats are never saved.' })),
            h('label', { class: 'switch' }, autoInput, h('span', { class: 'switch-track' }), h('span', { class: 'sr-only', text: 'Automatic memory' }))),
          h('button', { type: 'button', class: 'btn btn-sm', onClick: () => { close(''); shell.navigate('/memory'); } }, icon('bookmark'), 'Manage memories')),
        section('Your data',
          h('p', { class: 'hint', text: 'Export everything Aster stores about you as a JSON file, or permanently delete it.' }),
          h('div', { class: 'data-row' }, exportBtn, h('label', { class: 'check', for: 'exp-files' }, withFiles, h('span', { text: 'Include uploaded files' }))),
          h('div', { class: 'danger-zone' },
            h('strong', { text: 'Delete all my data' }),
            h('p', { id: 'del-hint', class: 'hint', text: `Removes every conversation, memory, setting and uploaded file. Type ${PHRASE} to enable the button.` }),
            h('div', { class: 'data-row' }, confirmInput, delBtn)))),
      h('footer', { class: 'dialog-foot' }, saved, h('span', { class: 'spacer' }), h('span', { class: 'hint', text: `${meta.appName} ${meta.version || ''}`.trim() }), h('button', { type: 'button', class: 'btn btn-primary', text: 'Done', onClick: () => close('') })),
    ],
    onClose: () => { saveText.cancel(); flushPending(); },
  });
}
