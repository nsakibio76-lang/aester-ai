/** The chat pane: topbar, thread, composer, and the streaming turn state machine. */
import { h, clear, announce, copyText, prefs } from '../dom.js';
import { icon, brandMark } from '../icons.js';
import { api, streamChat, ApiError } from '../api.js';
import { state, emit, upsertConversation } from '../state.js';
import { describeError } from '../lib/errors.js';
import { greeting, truncate } from '../lib/format.js';
import { MessageView } from './message.js';
import { createComposer } from './composer.js';
import { toast } from './toast.js';

const STARTERS = [
  { title: 'Solve a math problem', hint: 'Worked step by step, with a check', mode: 'math', text: 'Solve step by step: 2x² − 5x − 12 = 0' },
  { title: 'Explain a concept at my level', hint: 'Plain language first, then deeper', mode: 'study', text: 'Explain how vaccines train the immune system, as if I am a curious beginner. Then show me what an advanced version of the idea looks like.' },
  { title: 'Quiz me', hint: 'Interactive multiple choice', mode: 'study', text: 'Quiz me with 5 questions on quadratic equations.' },
  { title: 'Make flashcards', hint: 'Flip, shuffle, mark what you knew', mode: 'study', text: 'Make 8 flashcards for the main organelles of a cell and what each one does.' },
  { title: 'Summarize some text', hint: 'Paste it after the prompt', mode: 'auto', text: 'Summarize the following in five bullet points, then give me one sentence on the main idea:\n\n' },
  { title: 'Translate and explain', hint: 'With notes on tricky choices', mode: 'auto', text: 'Translate this into French and explain any tricky word choices:\n\n' },
  { title: 'Explain some code', hint: 'Line by line, then the big picture', mode: 'auto', text: 'Explain what this code does, line by line, then tell me how I could improve it:\n\n' },
  { title: 'Plan a learning path', hint: 'Weeks, goals, practice', mode: 'study', text: 'Plan a 6-week learning path for linear algebra at 5 hours per week, with a small project at the end.' },
];

export function createChat({ shell }) {
  let conv = null;
  let pendingPrivate = false;
  /** @type {MessageView[]} */
  let views = [];
  let stream = null; // { ac, view, aborted }
  let pinned = true;
  let loadToken = 0;

  /* ---------- DOM ---------- */
  const navBtn = h('button', { type: 'button', class: 'icon-btn nav-toggle', 'aria-label': 'Toggle sidebar', onClick: () => shell.toggleSidebar() }, icon('panel'));
  const titleEl = h('h1', { class: 'topbar-title', text: 'New chat' });
  const privateBtn = h('button', { type: 'button', class: 'private-btn', 'aria-pressed': 'false', onClick: () => togglePrivate() }, icon('lock'), h('span', { class: 'private-label', text: 'Private' }));
  const topbar = h('header', { class: 'topbar' }, navBtn, titleEl, h('span', { class: 'spacer' }), privateBtn);

  const thread = h('div', { class: 'thread', role: 'log', 'aria-label': 'Conversation', 'aria-live': 'off' });
  const scroller = h('div', { class: 'thread-scroll', tabindex: '-1' }, thread);
  const jump = h('button', { type: 'button', class: 'jump', hidden: true, 'aria-label': 'Jump to latest message', onClick: () => scrollToBottom(true) }, icon('arrowDown'));
  const errorBar = h('div', { class: 'composer-error', role: 'alert', hidden: true });

  const composer = createComposer({
    onSend: (p) => send(p),
    onStop: () => stop(),
    onModeChange: (m) => {
      prefs.set('mode', m);
      if (conv) api.patchConversation(conv.id, { mode: m }).then((c) => { conv = { ...conv, ...c }; upsertConversation(c); }).catch((e) => toast(describeError(e.code, e.message).message, { kind: 'error' }));
    },
  });
  const dock = h('div', { class: 'dock' }, jump, errorBar, composer.el);
  const el = h('section', { class: 'pane pane-chat', 'aria-label': 'Chat' }, topbar, scroller, dock);

  /* ---------- scrolling ---------- */
  scroller.addEventListener('scroll', () => {
    pinned = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < 96;
    jump.hidden = pinned || views.length === 0;
  });
  function scrollToBottom(force) {
    if (force) pinned = true;
    if (pinned) scroller.scrollTop = scroller.scrollHeight;
    jump.hidden = pinned;
  }

  /* ---------- header / flags ---------- */
  function renderHeader() {
    const title = conv ? conv.title : 'New chat';
    titleEl.textContent = title;
    document.title = conv ? `${truncate(title, 60)} - ${state.meta.appName}` : state.meta.appName;
    const priv = conv ? conv.memoryEnabled === false : pendingPrivate;
    privateBtn.setAttribute('aria-pressed', String(priv));
    privateBtn.classList.toggle('is-on', priv);
    privateBtn.title = priv ? 'Private chat: nothing from it is saved to memory. Click to allow memory.' : 'Make this chat private so nothing from it is saved to memory';
    privateBtn.setAttribute('aria-label', priv ? 'Private chat is on' : 'Make chat private');
  }

  async function togglePrivate() {
    if (!conv) { pendingPrivate = !pendingPrivate; renderHeader(); return; }
    const next = conv.memoryEnabled === false; // currently private -> enable memory
    try {
      const c = await api.patchConversation(conv.id, { memoryEnabled: next });
      conv = { ...conv, ...c };
      upsertConversation(c);
      renderHeader();
      toast(next ? 'Memory is on for this chat.' : 'This chat is private. Nothing from it will be saved to memory.', { kind: 'ok' });
    } catch (e) {
      toast(describeError(e.code, e.message).message, { kind: 'error' });
    }
  }

  function showComposerError(err) {
    clear(errorBar);
    if (!err) { errorBar.hidden = true; return; }
    const d = describeError(err.code, err.message);
    errorBar.hidden = false;
    errorBar.append(icon('alert'), h('div', { class: 'error-text' }, h('strong', { text: d.title }), h('span', { text: ' ' + d.message })),
      h('button', { type: 'button', class: 'icon-btn icon-btn-sm', 'aria-label': 'Dismiss', onClick: () => showComposerError(null) }, icon('x')));
  }

  /* ---------- views ---------- */
  const hooks = {
    isLast: (v) => views[views.length - 1] === v,
    onRegenerate: (v) => regenerate(v),
    onRetry: (v) => regenerate(v),
    onContinue: () => send({ text: 'Continue', attachments: [], restore: () => {} }),
    onEdit: (v, text) => edit(v, text),
    onChange: () => scrollToBottom(false),
  };

  function refreshActions() { for (const v of views) if (v.role === 'assistant') v.updateActions(); }

  function addView(msg) {
    const v = new MessageView(msg, hooks);
    views.push(v);
    thread.append(v.el);
    emptyEl()?.remove();
    return v;
  }

  function removeViewsAfter(view) {
    const i = views.indexOf(view);
    for (const v of views.splice(i + 1)) v.el.remove();
  }

  function localMsg(role, extra = {}) {
    return { id: 'local-' + Math.random().toString(36).slice(2), role, content: '', status: role === 'assistant' ? 'streaming' : 'complete', error: null, model: null, stopReason: null, createdAt: new Date().toISOString(), attachments: [], toolEvents: [], usage: null, ...extra };
  }

  const emptyEl = () => thread.querySelector('.empty');

  function renderEmpty() {
    clear(thread);
    views = [];
    const list = h('ul', { class: 'starters' }, STARTERS.map((s) =>
      h('li', null, h('button', { type: 'button', class: 'starter', onClick: () => {
        composer.setMode(s.mode); prefs.set('mode', s.mode);
        if (conv) api.patchConversation(conv.id, { mode: s.mode }).catch(() => {});
        composer.setText(s.text);
      } }, h('span', { class: 'starter-title', text: s.title }), h('span', { class: 'starter-hint', text: s.hint })))));
    thread.append(h('div', { class: 'empty' },
      brandMark('empty-mark'),
      h('h2', { class: 'empty-title', text: `${greeting()}. What shall we work on?` }),
      h('p', { class: 'empty-sub', text: 'Ask anything, send a photo of a problem, or pick a starting point. Aster remembers what matters between chats.' }),
      list));
  }

  /* ---------- loading conversations ---------- */
  async function showNew() {
    abortStream();
    loadToken++;
    conv = null;
    pendingPrivate = false;
    state.activeId = null;
    showComposerError(null);
    renderEmpty();
    composer.setMode(prefs.get('mode', 'auto'));
    composer.setText('', { focus: false });
    renderHeader();
    emit('active');
    pinned = true;
    scroller.scrollTop = 0;
    jump.hidden = true;
    if (!matchMedia('(pointer: coarse)').matches) composer.focus();
  }

  async function show(id) {
    if (stream && conv && conv.id === id) return; // already live on screen
    abortStream();
    const token = ++loadToken;
    showComposerError(null);
    state.activeId = id;
    emit('active');
    clear(thread);
    views = [];
    thread.append(h('p', { class: 'thread-loading', text: 'Loading conversation…' }));
    try {
      const data = await api.getConversation(id);
      if (token !== loadToken) return;
      conv = data.conversation;
      clear(thread);
      views = [];
      for (const m of data.messages) addView(m);
      if (!views.length) renderEmpty();
      refreshActions();
      composer.setMode(conv.mode || 'auto');
      renderHeader();
      pinned = true;
      requestAnimationFrame(() => scrollToBottom(true));
      composer.setText('', { focus: false });
      if (!matchMedia('(pointer: coarse)').matches) composer.focus();
    } catch (e) {
      if (token !== loadToken) return;
      if (e.code === 'not_found') {
        toast('That conversation no longer exists.', { kind: 'error' });
        shell.navigate('/', { replace: true });
      } else if (e.code !== 'unauthenticated') {
        clear(thread);
        thread.append(h('div', { class: 'error-banner' }, icon('alert'), h('div', { class: 'error-text' }, h('strong', { text: describeError(e.code).title }), h('span', { text: ' ' + describeError(e.code, e.message).message })),
          h('button', { type: 'button', class: 'btn btn-sm', text: 'Try again', onClick: () => show(id) })));
      }
    }
  }

  async function resync() {
    if (!conv) return;
    const id = conv.id;
    try {
      const data = await api.getConversation(id);
      if (conv?.id !== id) return;
      conv = data.conversation;
      clear(thread);
      views = [];
      for (const m of data.messages) addView(m);
      if (!views.length) renderEmpty();
      refreshActions();
      renderHeader();
      scrollToBottom(true);
    } catch { /* leave the thread as it is */ }
  }

  /* ---------- turns ---------- */
  function abortStream() {
    if (stream) { stream.aborted = true; stream.ac.abort(); }
  }

  function stop() { abortStream(); }

  function send({ text, attachments, restore }) {
    if (stream) return;
    showComposerError(null);
    const userView = addView(localMsg('user', { content: text, attachments: attachments || [] }));
    const asstView = addView(localMsg('assistant'));
    refreshActions();
    scrollToBottom(true);
    const payload = {
      action: 'send',
      conversationId: conv ? conv.id : null,
      message: text,
      attachmentIds: (attachments || []).map((a) => a.id),
      mode: composer.getMode(),
      tz: Intl.DateTimeFormat().resolvedOptions().timeZone,
    };
    if (!conv && pendingPrivate) payload.memoryEnabled = false;
    return run(payload, { kind: 'send', userView, asstView, restore });
  }

  function regenerate(view) {
    if (stream || !conv) return;
    showComposerError(null);
    removeViewsAfter(view);
    view.restart();
    refreshActions();
    scrollToBottom(true);
    return run({ action: 'regenerate', conversationId: conv.id, messageId: view.msg.id, mode: composer.getMode(), tz: Intl.DateTimeFormat().resolvedOptions().timeZone }, { kind: 'regenerate', asstView: view });
  }

  function edit(userView, text) {
    if (stream || !conv) return;
    showComposerError(null);
    userView.setUserMessage({ ...userView.msg, content: text });
    removeViewsAfter(userView);
    const asstView = addView(localMsg('assistant'));
    refreshActions();
    scrollToBottom(true);
    return run({ action: 'edit', conversationId: conv.id, messageId: userView.msg.id, message: text, mode: composer.getMode(), tz: Intl.DateTimeFormat().resolvedOptions().timeZone }, { kind: 'edit', userView, asstView });
  }

  async function run(payload, ctx) {
    const ac = new AbortController();
    stream = { ac, aborted: false };
    composer.setBusy(true);
    el.classList.add('is-busy');
    const wasNew = !conv;
    const ctxState = { started: false, finished: false };
    const view = ctx.asstView;

    const onEvent = (name, d) => {
      switch (name) {
        case 'start': {
          ctxState.started = true;
          conv = { ...(conv || {}), ...d.conversation };
          if (wasNew || state.activeId !== conv.id) { state.activeId = conv.id; shell.navigate(`/c/${conv.id}`, { replace: true, silent: true }); emit('active'); }
          upsertConversation(conv, { moveToTop: true });
          renderHeader();
          if (d.userMessage && ctx.userView) ctx.userView.setUserMessage(d.userMessage);
          view.bind(d.assistantMessage);
          break;
        }
        case 'status':
          if (d.kind === 'retry') view.setRetryNotice(d.message, d.retryInMs);
          break;
        case 'delta':
          view.appendDelta(d.text);
          break;
        case 'tool':
          view.addToolEvent(d);
          break;
        case 'title':
          if (conv && d.conversationId === conv.id) { conv = { ...conv, title: d.title, titleSource: 'auto' }; renderHeader(); }
          upsertConversation({ id: d.conversationId, title: d.title, titleSource: 'auto' });
          break;
        case 'conversation':
          if (d.conversation) {
            if (conv && d.conversation.id === conv.id) { conv = { ...conv, ...d.conversation }; renderHeader(); if (d.conversation.memoryEnabled === false) toast('Memory is now off for this chat.', { kind: 'info' }); }
            upsertConversation(d.conversation);
          }
          break;
        case 'memory': {
          const verb = d.action === 'added' ? 'Saved to memory' : d.action === 'updated' ? 'Memory updated' : 'Removed from memory';
          const content = d.memory && d.memory.content ? `: ${truncate(d.memory.content, 90)}` : '';
          toast(verb + content, { kind: 'ok', action: { label: 'View memory', onClick: () => shell.navigate('/memory') }, timeout: 6500 });
          emit('memory-changed');
          break;
        }
        case 'error':
          ctxState.finished = true;
          ctxState.error = d;
          if (ctxState.started) view.setError({ code: d.code, message: d.message });
          break;
        case 'done':
          ctxState.finished = true;
          view.finalize(d.assistantMessage);
          announce('Response complete');
          break;
        default:
      }
      if (name === 'delta' || name === 'tool' || name === 'start') scrollToBottom(false);
    };

    try {
      await streamChat(payload, { signal: ac.signal, onEvent });
      if (!ctxState.finished) {
        view.setError({ code: 'network', message: 'The connection closed before the response finished.' });
      } else if (ctxState.error && !ctxState.started) {
        throw new ApiError(0, ctxState.error.code, ctxState.error.message);
      }
    } catch (e) {
      if (e && e.name === 'AbortError') {
        if (ctxState.started) { view.stopped(); }
        else { await resync(); if (!conv) showNew(); }
      } else {
        const err = e instanceof ApiError ? e : new ApiError(0, 'server', String(e && e.message || e));
        if (ctxState.started) {
          view.setError({ code: err.code, message: err.message });
        } else if (ctx.kind === 'send') {
          // Nothing was saved: take the optimistic messages back and give the text back to the user.
          for (const v of [ctx.userView, ctx.asstView]) { const i = views.indexOf(v); if (i !== -1) views.splice(i, 1); v.el.remove(); }
          if (!views.length) renderEmpty();
          ctx.restore && ctx.restore();
          showComposerError(err);
        } else if (ctx.kind === 'regenerate') {
          view.setError({ code: err.code, message: err.message });
        } else {
          showComposerError(err);
          await resync();
        }
      }
    } finally {
      stream = null;
      composer.setBusy(false);
      el.classList.remove('is-busy');
      refreshActions();
      scrollToBottom(false);
      if (!matchMedia('(pointer: coarse)').matches) composer.focus();
    }
  }

  // Per-code-block copy (event delegation).
  thread.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-action="copy-code"]');
    if (!btn) return;
    const code = btn.closest('.codeblock')?.querySelector('code');
    if (!code) return;
    const ok = await copyText(code.textContent);
    btn.textContent = ok ? 'Copied' : 'Copy failed';
    btn.classList.toggle('is-done', ok);
    setTimeout(() => { btn.textContent = 'Copy'; btn.classList.remove('is-done'); }, 1600);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && stream && el.offsetParent !== null && !document.querySelector('dialog[open]')) stop();
  });

  return {
    el,
    show,
    showNew,
    focusComposer: () => composer.focus(),
    isStreaming: () => !!stream,
    abort: abortStream,
    current: () => conv,
    applyConversation(c) { if (conv && conv.id === c.id) { conv = { ...conv, ...c }; renderHeader(); } },
    conversationRemoved(id) { if (conv && conv.id === id) shell.navigate('/', { replace: true }); },
  };
}
