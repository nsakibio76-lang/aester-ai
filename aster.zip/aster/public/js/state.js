/** Shared client state + a minimal event bus. */
export const state = {
  meta: null,
  settings: null,
  conversations: [],
  hasMore: false,
  archivedView: false,
  query: '',
  activeId: null,
  /** bumped on every local list mutation so in-flight list fetches can detect staleness */
  listVersion: 0,
};

const listeners = new Map();
export function on(evt, fn) {
  if (!listeners.has(evt)) listeners.set(evt, new Set());
  listeners.get(evt).add(fn);
  return () => listeners.get(evt).delete(fn);
}
export function emit(evt, data) {
  for (const fn of listeners.get(evt) || []) {
    try { fn(data); } catch (e) { console.error(`[aster] listener for "${evt}" failed`, e); }
  }
}

/** Insert or update a conversation in the sidebar list (moves it to the top of the active list). */
export function upsertConversation(conv, { moveToTop = false } = {}) {
  state.listVersion++;
  const i = state.conversations.findIndex((c) => c.id === conv.id);
  // Partial updates (e.g. the `title` event) may omit `archived`; only a definite value moves a chat between lists.
  if (conv.archived !== undefined && conv.archived !== state.archivedView) {
    if (i !== -1) state.conversations.splice(i, 1);
  } else if (i === -1) {
    // A partial object for a chat we do not hold cannot be shown; full objects always carry createdAt.
    if (conv.createdAt) state.conversations.unshift(conv);
  } else if (moveToTop) {
    const [prev] = state.conversations.splice(i, 1);
    state.conversations.unshift({ ...prev, ...conv });
  } else {
    state.conversations[i] = { ...state.conversations[i], ...conv };
  }
  emit('conversations');
}
