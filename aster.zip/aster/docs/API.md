# Aster HTTP API (v1)

All endpoints are under `/api`, JSON in / JSON out unless noted. Errors: HTTP status + `{"error":{"code":"...","message":"..."}}`.
Timestamps are ISO-8601 strings. IDs are opaque strings.
State-changing requests must be same-origin (the server checks `Origin`) and JSON requests must send `Content-Type: application/json`.

If `meta.authRequired && !meta.authenticated`, the UI must show a password form and `POST /api/auth/login`; every other endpoint answers `401 {error:{code:"unauthenticated"}}` until then.

## Types

```
Conversation = { id, title, titleSource: "default"|"auto"|"user", mode: "auto"|"math"|"study",
                 memoryEnabled: boolean, archived: boolean, createdAt, updatedAt,
                 snippet?: string  /* only in search results; contains <mark>…</mark> highlight tags, already HTML-escaped otherwise */ }
Attachment   = { id, name, kind: "image"|"pdf"|"text", mime, size, url }          // url = "/api/attachments/<id>"
ToolEvent    = { id, name, summary: string, ok: boolean }                           // name: calculate|memory_save|memory_update|memory_forget|memory_list|conversation_memory
Message      = { id, role: "user"|"assistant", content: string,
                 status: "complete"|"streaming"|"stopped"|"error",
                 error: {code, message} | null, model: string|null, stopReason: string|null,
                 createdAt, attachments: Attachment[], toolEvents: ToolEvent[],
                 usage: {inputTokens, outputTokens} | null }
Memory       = { id, category, content, source: "auto"|"explicit"|"manual", createdAt, updatedAt,
                 lastUsedAt: string|null, conversationId: string|null }
Settings     = { theme: "system"|"light"|"dark", autoMemory: boolean, model: string|null,
                 responseStyle: "concise"|"balanced"|"detailed",
                 explainLevel: "auto"|"beginner"|"intermediate"|"advanced",
                 language: string /* "" = reply in the user's language */, customInstructions: string /* <= 2000 chars */ }
```

Memory categories (fixed list, returned by `GET /api/memories` as `categories`):
`personal`, `preferences`, `education`, `learning_goals`, `interests`, `ambitions`, `projects`, `context`, `communication`.

## Endpoints

| Method & path | Body / query | Response |
|---|---|---|
| `GET /api/health` | – | `{ok:true}` (no auth) |
| `GET /api/meta` | – | `{appName, version, authRequired, authenticated, apiConfigured, provider:{id,name}, models:[{id,label}], defaultModel, limits:{maxMessageChars, maxAttachments, maxImageBytes, maxPdfBytes, maxTextBytes, imageTypes:[mime], textExtensions:[".txt",…]}}` (no auth) |
| `POST /api/auth/login` | `{password}` | `204` + cookie · `401 invalid_password` · `429 rate_limited` |
| `POST /api/auth/logout` | – | `204` |
| `GET /api/settings` | – | `Settings` |
| `PUT /api/settings` | partial `Settings` | `Settings` (422 on invalid values) |
| `GET /api/conversations` | `?archived=0\|1&q=&limit=50&offset=0` | `{conversations: Conversation[], hasMore}` (newest activity first; `q` searches titles and message text) |
| `POST /api/conversations` | `{title?, mode?, memoryEnabled?}` | `201 Conversation` |
| `GET /api/conversations/:id` | – | `{conversation, messages: Message[]}` |
| `PATCH /api/conversations/:id` | `{title?, archived?, memoryEnabled?, mode?}` | `Conversation` |
| `DELETE /api/conversations/:id` | – | `204` |
| `POST /api/uploads` | **raw bytes** body; headers `Content-Type: <mime>`, `X-File-Name: encodeURIComponent(name)` | `201 Attachment` (not attached to a message yet) · `413` · `415` |
| `DELETE /api/uploads/:id` | – | `204` (only while unattached) |
| `GET /api/attachments/:id` | – | file bytes (images inline, others as download) |
| `GET /api/memories` | `?q=&category=` | `{memories: Memory[], total, categories: string[]}` (newest update first) |
| `POST /api/memories` | `{content, category?}` | `201 Memory` · `422 sensitive_blocked` (secrets such as passwords/card numbers are refused) |
| `PATCH /api/memories/:id` | `{content?, category?}` | `Memory` |
| `DELETE /api/memories/:id` | – | `204` |
| `DELETE /api/memories` | `{confirm:true}` | `{deleted:n}` |
| `GET /api/export` | `?files=0\|1` | JSON file download (all conversations, messages, memories, settings; files base64 when `files=1`) |
| `DELETE /api/data` | `{confirm:"DELETE ALL MY DATA"}` | `{deleted:{conversations,messages,memories,attachments}}` |
| `POST /api/chat` | see below | `text/event-stream` |

## `POST /api/chat`

```
{ action?: "send"|"regenerate"|"edit",        // default "send"
  conversationId?: string|null,               // null/absent on "send" => new conversation
  message?: string,                           // send, edit  (1..maxMessageChars)
  attachmentIds?: string[],                   // send
  messageId?: string,                         // regenerate: assistant message id · edit: user message id
  mode?: "auto"|"math"|"study",               // applied to the conversation (new, or updated)
  memoryEnabled?: boolean,                    // only when creating a conversation ("private chat" = false)
  model?: string, tz?: string }               // optional per-request model override, IANA timezone
```

The response is Server-Sent Events: `event: <name>\ndata: <json>\n\n`. Events:

| event | data |
|---|---|
| `start` | `{conversation, userMessage: Message\|null, assistantMessage: Message}` (assistantMessage has status "streaming", empty content) |
| `status` | `{kind:"retry", message, retryInMs}` — provider is rate-limited/overloaded and retrying |
| `delta` | `{text}` — append to the assistant message |
| `tool` | `{id, name, phase:"start"\|"result", summary?, ok?}` |
| `title` | `{conversationId, title}` |
| `conversation` | `{conversation}` — flags changed (e.g. memory switched off by the assistant) |
| `memory` | `{action:"added"\|"updated"\|"deleted", memory}` |
| `error` | `{code, message, retryable}` — the turn failed; the assistant message is kept with status "error" and whatever text had streamed |
| `done` | `{assistantMessage: Message, stopReason}` — `stopReason` may be `"max_tokens"` (offer a Continue button) |

After `done`/`error` the stream may still emit `title` / `memory` / `conversation` events before it closes.
Aborting the fetch (AbortController) stops generation; the partial text is stored with status `"stopped"`.

Error codes: `not_configured, unauthenticated, auth, rate_limit, overloaded, context_too_long, invalid_request, not_found, permission, billing, network, timeout, aborted, server, refusal, validation, rate_limited, sensitive_blocked`.

## Message rendering contract (client libraries)

`public/js/lib/math.js`, `public/js/lib/markdown.js`, `public/js/lib/highlight.js` are pure ES modules (no DOM access) so they can be unit-tested in Node. See the headers of those files for their exports.

Assistant messages may contain Markdown, LaTeX (`$…$`, `$$…$$`, `\(…\)`, `\[…\]`) and two special fenced blocks the UI turns into interactive widgets:

````
```quiz
{"title":"Quadratics","questions":[{"q":"…","options":["A","B","C","D"],"answer":1,"explanation":"…"}]}
```
```flashcards
{"title":"Cell biology","cards":[{"front":"…","back":"…"}]}
```
````

`answer` is the zero-based index of the correct option. Text inside `q`, `options`, `explanation`, `front`, `back` may contain inline Markdown/LaTeX.
