import { test } from 'node:test';
import assert from 'node:assert/strict';
import { renderMarkdown, renderInline, renderPlainText, parseWidget } from '../../public/js/lib/markdown.js';

test('renders basic markdown with GFM tables wrapped for scrolling', () => {
  const html = renderMarkdown('# T\n\n**b** _i_ `c`\n\n| a | b |\n|---|---|\n| 1 | 2 |');
  assert.match(html, /<h1>T<\/h1>/);
  assert.match(html, /<strong>b<\/strong>/);
  assert.match(html, /<div class="table-wrap"><table>/);
});

test('math inside markdown is rendered and not mangled by emphasis rules', () => {
  const html = renderMarkdown('Let $a_1 * b_2$ and $$x_1 + y_2$$ done');
  assert.match(html, /class="katex"/);
  assert.ok(!html.includes('<em>'));
  assert.match(html, /katex-display/);
});

test('code blocks are highlighted, labelled and carry a copy button; math in code is untouched', () => {
  const html = renderMarkdown('```python\nprint("$x$")\n```');
  assert.match(html, /class="codeblock"/);
  assert.match(html, /data-action="copy-code"/);
  assert.match(html, /codeblock-lang">python</);
  assert.ok(!html.includes('katex'));
});

test('raw HTML and unsafe links are neutralised', () => {
  const html = renderMarkdown('<img src=x onerror=alert(1)> <script>x</script> [a](javascript:alert(1)) [b](https://ok.example) ![p](https://evil/x.png)');
  assert.ok(!/<img|<script/i.test(html));
  assert.ok(!html.includes('javascript:'));
  assert.match(html, /<a href="https:\/\/ok\.example" target="_blank" rel="noopener noreferrer">b<\/a>/);
  assert.match(html, /img-omitted/);
});

test('Final answer and Check sections become callouts', () => {
  const html = renderMarkdown('### Solution\n\nwork\n\n### Check\n\nok\n\n### Final answer\n\n$x=2$\n');
  assert.match(html, /<section class="callout callout-check"><h3>Check<\/h3>/);
  assert.match(html, /<section class="callout callout-answer"><h3>Final answer<\/h3>/);
  assert.ok(!/callout[^>]*><h3>Solution/.test(html));
  assert.match(renderMarkdown('## **Final Answer:** x'), /callout-answer/);
});

test('a callout ends at the next heading of the same or higher level', () => {
  const html = renderMarkdown('### Final answer\n\nA\n\n### Notes\n\nB');
  const answer = /<section class="callout callout-answer">([\s\S]*?)<\/section>/.exec(html)![1];
  assert.ok(answer.includes('A') && !answer.includes('B'));
});

test('quiz and flashcards fences become widgets with normalised specs', () => {
  const quiz = renderMarkdown('```quiz\n{"title":"Q","questions":[{"q":"2+2?","options":["3","4"],"answer":1,"explanation":"e"}]}\n```');
  assert.match(quiz, /class="widget widget-quiz" data-widget="quiz" data-spec="/);
  const cards = renderMarkdown('```flashcards\n{"cards":[{"front":"a","back":"b"}]}\n```');
  assert.match(cards, /widget-flashcards/);
});

test('invalid widget JSON falls back to a plain code block', () => {
  const bad = renderMarkdown('```quiz\n{not json\n```');
  assert.ok(!bad.includes('data-widget'));
  assert.match(bad, /class="codeblock"/);
  const wrong = renderMarkdown('```quiz\n{"questions":[{"q":"x","options":["a","b"],"answer":5}]}\n```');
  assert.ok(!wrong.includes('widget-quiz'));
});

test('parseWidget validates answer index, option count and coerces strings', () => {
  assert.equal(parseWidget('quiz', '{"questions":[{"q":"x","options":["a"],"answer":0}]}'), null);
  const ok = parseWidget('quiz', '{"questions":[{"q":"x","options":["a","b"],"answer":"1"},{"q":"bad","options":["a","b"],"answer":9}]}') as { questions: unknown[] };
  assert.equal(ok.questions.length, 1);
  assert.equal(parseWidget('flashcards', '{"cards":[{"front":"","back":"b"}]}'), null);
  assert.equal(parseWidget('flashcards', 'null'), null);
});

test('streaming: partial input never throws; widgets stay placeholders; open fences render as code', () => {
  const partials = [
    '```quiz\n{"questions":[{"q":"a","opt',
    '```quiz\n{"questions":[{"q":"a","options":["x","y"],"answer":1}]}\n```',
    '```python\nprint(1',
    'text $$\\frac{1}{',
    '| a | b |\n|---',
    '### Final ans',
    '**bold',
    '[link](http',
  ];
  for (const p of partials) assert.doesNotThrow(() => renderMarkdown(p, { streaming: true }), p);
  assert.match(renderMarkdown(partials[1], { streaming: true }), /widget-pending/);
  assert.match(renderMarkdown(partials[2], { streaming: true }), /codeblock-open[\s\S]*hljs-built_in">print<\/span>\(<span class="hljs-number">1<\/span><\/code>/);
  assert.match(renderMarkdown(partials[3], { streaming: true }), /math-pending/);
});

test('every prefix of a realistic answer renders without throwing', () => {
  const full = '### Given\n\nSolve $x^2-5x+6=0$.\n\n1. Factor:\n   $$(x-2)(x-3)=0$$\n2. So $x=2$ or $x=3$.\n\n```python\nimport sympy\n```\n\n### Final answer\n\n$x\\in\\{2,3\\}$\n\n```quiz\n{"questions":[{"q":"a","options":["x","y"],"answer":1}]}\n```\n';
  for (let i = 0; i <= full.length; i += 3) assert.doesNotThrow(() => renderMarkdown(full.slice(0, i), { streaming: true }));
});

test('renderInline has no paragraph wrapper; renderPlainText escapes', () => {
  const html = renderInline('**a** and $x^2$');
  assert.ok(!html.includes('<p>'));
  assert.match(html, /<strong>a<\/strong>/);
  assert.equal(renderPlainText('<b>x</b>\ny'), '&lt;b&gt;x&lt;/b&gt;<br>y');
});

test('a math token cannot be injected via link titles or hrefs', () => {
  const html = renderMarkdown('[a]($x$ "t$y$") and [b](https://e.com/$z$)');
  assert.ok(!/href="[^"]*katex/.test(html));
});
