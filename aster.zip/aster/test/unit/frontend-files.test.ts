import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateFile, classifyFile } from '../../public/js/lib/files.js';

const limits = { maxAttachments: 3, maxImageBytes: 5_000_000, maxPdfBytes: 10_000_000, maxTextBytes: 200_000, imageTypes: ['image/png', 'image/jpeg', 'image/webp'], textExtensions: ['.txt', '.md', '.py', '.csv'] };

test('classifies by mime type and extension', () => {
  assert.equal(classifyFile({ name: 'a.png', type: 'image/png' }, limits), 'image');
  assert.equal(classifyFile({ name: 'a.PDF', type: '' }, limits), 'pdf');
  assert.equal(classifyFile({ name: 'notes.MD', type: '' }, limits), 'text');
  assert.equal(classifyFile({ name: 'a.exe', type: 'application/x-msdownload' }, limits), null);
  assert.equal(classifyFile({ name: 'a.svg', type: 'image/svg+xml' }, limits), null);
});

test('enforces count, type, emptiness and per-kind size limits', () => {
  assert.deepEqual(validateFile({ name: 'a.png', size: 10, type: 'image/png' }, limits, 0), { ok: true, kind: 'image' });
  assert.equal(validateFile({ name: 'a.png', size: 10, type: 'image/png' }, limits, 3).ok, false);
  assert.equal(validateFile({ name: 'a.zip', size: 10, type: 'application/zip' }, limits).ok, false);
  assert.equal(validateFile({ name: 'a.txt', size: 0, type: 'text/plain' }, limits).ok, false);
  const big = validateFile({ name: 'a.txt', size: 300_000, type: 'text/plain' }, limits);
  assert.equal(big.ok, false);
  assert.match((big as { error: string }).error, /limit/);
});
