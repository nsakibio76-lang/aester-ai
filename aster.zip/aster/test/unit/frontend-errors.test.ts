import { test } from 'node:test';
import assert from 'node:assert/strict';
import { describeError, isAuthError, MEMORY_CATEGORIES } from '../../public/js/lib/errors.js';

const CODES = ['not_configured', 'unauthenticated', 'auth', 'rate_limit', 'overloaded', 'context_too_long', 'invalid_request', 'not_found', 'permission', 'billing', 'network', 'timeout', 'aborted', 'server', 'refusal', 'validation', 'rate_limited', 'sensitive_blocked'];

test('every documented error code has a specific, actionable message', () => {
  for (const c of CODES) {
    const d = describeError(c);
    assert.ok(d.title && d.message.length > 20, c);
    assert.notEqual(d.title, 'Something went wrong', c);
  }
});

test('not_configured tells the user how to fix it', () => {
  assert.match(describeError('not_configured').message, /ANTHROPIC_API_KEY/);
});

test('unknown codes fall back to the server message', () => {
  assert.equal(describeError('weird', 'custom text').message, 'custom text');
  assert.equal(describeError('weird').title, 'Something went wrong');
});

test('retryable flags and auth helper', () => {
  assert.equal(describeError('overloaded').retryable, true);
  assert.equal(describeError('billing').retryable, false);
  assert.equal(isAuthError('unauthenticated'), true);
  assert.equal(isAuthError('auth'), false);
});

test('memory categories match the API contract', () => {
  assert.deepEqual(MEMORY_CATEGORIES.map((c) => c.id), ['personal', 'preferences', 'education', 'learning_goals', 'interests', 'ambitions', 'projects', 'context', 'communication']);
});
