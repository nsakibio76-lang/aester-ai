import test from "node:test";
import assert from "node:assert/strict";
import { calculate, CalcError } from "../../server/tools/calculator.ts";

const v = (e: string) => calculate(e).text;

test("arithmetic precedence and exactness", () => {
  assert.equal(v("2+3*4"), "14");
  assert.equal(v("-2^2"), "-4");
  assert.equal(v("2^3^2"), "512");
  assert.equal(v("(1+2)*(3+4)"), "21");
  assert.equal(v("0.1+0.2"), "3/10 ≈ 0.3"); // exact decimals, no float drift
  assert.equal(v("1/3+1/6"), "1/2 ≈ 0.5");
  assert.equal(v("2^-3"), "1/8 ≈ 0.125");
});

test("big integers are exact", () => {
  assert.equal(v("2^100"), "1267650600228229401496703205376");
  assert.equal(v("20!"), "2432902008176640000");
  assert.equal(v("binom(50,25)"), "126410606437752");
});

test("roots, trig and logs", () => {
  assert.equal(v("sqrt(16)"), "4");
  assert.equal(v("8^(1/3)"), "2");
  assert.ok(Math.abs(Number(v("sqrt(2)")) - Math.SQRT2) < 1e-12);
  assert.equal(v("sind(30)"), "0.5");
  assert.equal(v("sin(pi)"), "0"); // cleaned float noise
  assert.equal(v("log(1000)"), "3");
  assert.equal(v("ln(e)"), "1");
  assert.equal(v("3pi").startsWith("9.4247779607"), true);
});

test("number theory and statistics helpers", () => {
  assert.equal(v("gcd(12,18)"), "6");
  assert.equal(v("lcm(4,6)"), "12");
  assert.equal(v("mod(-5,3)"), "1");
  assert.equal(v("mean(1,2,3,4)"), "5/2 ≈ 2.5");
  assert.equal(v("median(3,1,2,10)"), "5/2 ≈ 2.5");
  assert.equal(Number(v("stdev(2,4,4,4,5,5,7,9)")).toFixed(4), "2.1381");
  assert.equal(v("floor(-7/2)"), "-4");
  assert.equal(v("ceil(7/2)"), "4");
});

test("errors are explicit, never silent NaN", () => {
  for (const bad of ["7/0", "x+1", "(1+2", "sqrt(-1)", "ln(0)", "0^-1", "2 $ 3", "", "factorial(2000)", "tan(pi/2)", "(-8)^(1/2)"]) {
    assert.throws(() => calculate(bad), CalcError, bad);
  }
});

test("resource limits", () => {
  assert.throws(() => calculate("1+".repeat(400) + "1"), /too long/);
  assert.throws(() => calculate("(".repeat(100) + "1" + ")".repeat(100)), /nested/);
  const t0 = Date.now();
  assert.throws(() => calculate("9^9^9"), CalcError); // too large → clean error, must not hang
  assert.ok(Date.now() - t0 < 1000);
});
