// Integration tests: real HTTP server + real SQLite + real provider code ↔ mock Anthropic wire protocol.

import test from "node:test";
import assert from "node:assert/strict";
import { startTestApp, PNG_1x1 } from "../helpers/harness.ts";
import type { TestApp } from "../helpers/harness.ts";

async function withApp(fn: (t: TestApp) => Promise<void>, env: Record<string, string> = {}) {
  const t = await startTestApp(env);
  try { await fn(t); } finally { await t.stop(); }
}

test("streams a reply, persists both messages, generates a title, records usage", () => withApp(async (t) => {
  const r = await t.chat({ message: "please solve this math problem", mode: "math" });
  assert.equal(r.status, 200);
  assert.deepEqual(r.events.map((e) => e.event).filter((n) => n !== "delta"), ["start", "done", "title"]);
  assert.match(r.text, /### Final answer/);
  assert.match(r.text, /\\\$5/, "escaped dollar survives untouched");
  const start = r.of("start")[0]!.data;
  assert.equal(start.conversation.mode, "math");
  assert.equal(start.assistantMessage.status, "streaming");
  const done = r.of("done")[0]!.data;
  assert.equal(done.assistantMessage.status, "complete");
  assert.equal(done.assistantMessage.content, r.text);
  assert.equal(done.assistantMessage.usage.inputTokens, 42);
  assert.equal(r.of("title")[0]!.data.title, "Mock Conversation Title");

  const got = await t.api("GET", `/api/conversations/${start.conversation.id}`);
  assert.equal(got.body.messages.length, 2);
  assert.equal(got.body.conversation.title, "Mock Conversation Title");
  assert.equal(got.body.conversation.titleSource, "auto");
  // model got the system prompt with the math protocol + current date, key only in header
  const sent = t.mock.requests.find((q) => !JSON.stringify(q.body.system).includes("short conversation titles"))!;
  assert.match(sent.body.system[0].text, /Mathematics tutor protocol/);
  assert.deepEqual(sent.body.system[0].cache_control, { type: "ephemeral" });
  assert.match(sent.body.system[1].text, /Mode: MATH TUTOR/);
  assert.equal(sent.body.stream, true);
}));

test("conversation context is carried across follow-ups", () => withApp(async (t) => {
  const a = await t.chat({ message: "first question" });
  const id = a.of("start")[0]!.data.conversation.id;
  await t.chat({ conversationId: id, message: "follow-up question" });
  const q = t.mock.requests.filter((r) => !JSON.stringify(r.body.system).includes("short conversation titles")).at(-1)!;
  const texts = q.body.messages.map((m: any) => `${m.role}:${m.content.map((b: any) => b.text ?? "").join("")}`);
  assert.equal(q.body.messages.length, 3);
  assert.match(texts[0]!, /^user:first question/);
  assert.match(texts[1]!, /^assistant:This is a mock reply/);
  assert.match(texts[2]!, /^user:follow-up question/);
}));

test("regenerate replaces the assistant reply; edit rewrites history from that point", () => withApp(async (t) => {
  const a = await t.chat({ message: "hello original" });
  const id = a.of("start")[0]!.data.conversation.id;
  const assistantId = a.of("done")[0]!.data.assistantMessage.id;
  const regen = await t.chat({ action: "regenerate", conversationId: id, messageId: assistantId });
  assert.equal(regen.of("start")[0]!.data.userMessage, null);
  let msgs = (await t.api("GET", `/api/conversations/${id}`)).body.messages;
  assert.equal(msgs.length, 2);
  assert.notEqual(msgs[1].id, assistantId, "old reply is gone");

  await t.chat({ conversationId: id, message: "second turn" });
  msgs = (await t.api("GET", `/api/conversations/${id}`)).body.messages;
  assert.equal(msgs.length, 4);
  const edit = await t.chat({ action: "edit", conversationId: id, messageId: msgs[0].id, message: "hello EDITED" });
  assert.match(edit.text, /hello EDITED/);
  msgs = (await t.api("GET", `/api/conversations/${id}`)).body.messages;
  assert.equal(msgs.length, 2, "later turns were discarded");
  assert.equal(msgs[0].content, "hello EDITED");

  assert.equal((await t.chat({ action: "edit", conversationId: id, messageId: msgs[1].id, message: "x" })).status, 422, "cannot edit assistant message");
  assert.equal((await t.chat({ action: "regenerate", conversationId: id, messageId: msgs[0].id })).status, 422, "cannot regenerate a user message");
  assert.equal((await t.chat({ action: "regenerate", conversationId: id, messageId: "nope" })).status, 404);
}));

test("tool loop: calculate result is fed back to the model and shown as a tool event", () => withApp(async (t) => {
  const r = await t.chat({ message: "calc 2^10 + 5!" });
  const tools = r.of("tool").map((e) => e.data);
  assert.deepEqual(tools.map((x) => x.phase), ["start", "result"]);
  assert.equal(tools[1].ok, true);
  assert.match(tools[1].summary, /1144/);
  assert.match(r.text, /Tool said: 1144/);
  const done = r.of("done")[0]!.data.assistantMessage;
  assert.equal(done.toolEvents[0].name, "calculate");
  const second = t.mock.requests.find((q) => q.body.messages.at(-1).content[0].type === "tool_result")!;
  assert.equal(second.body.messages.at(-1).content[0].content, "1144");
  assert.equal(second.body.messages.at(-2).role, "assistant");
}));

test("memory: explicit 'remember' saves, persists across restart, and is injected into later conversations", () => withApp(async (t) => {
  const r = await t.chat({ message: "remember that I am preparing for the HSC exam in 2027" });
  assert.equal(r.of("memory")[0]!.data.action, "added");
  assert.equal(r.of("memory")[0]!.data.memory.source, "explicit");
  const list = (await t.api("GET", "/api/memories")).body;
  assert.equal(list.total, 1);

  await t.restart(); // process restart: same database file
  const after = (await t.api("GET", "/api/memories")).body;
  assert.equal(after.total, 1);
  assert.match(after.memories[0].content, /HSC exam/);

  await t.chat({ message: "a brand new conversation" });
  const q = t.mock.requests.filter((x) => !JSON.stringify(x.body.system).includes("short conversation titles")).at(-1)!;
  assert.match(q.body.system[1].text, /<stored_memories>[\s\S]*HSC exam in 2027[\s\S]*<\/stored_memories>/);
  assert.equal((await t.api("GET", "/api/memories")).body.memories[0].lastUsedAt !== null, true, "lastUsedAt updated");
  const convs = (await t.api("GET", "/api/conversations")).body.conversations;
  assert.equal(convs.length, 2, "conversations persisted across restart");
}));

test("memory: forget, update via API, 'what do you remember' reads real data", () => withApp(async (t) => {
  await t.chat({ message: "remember that my favourite subject is physics" });
  const ask = await t.chat({ message: "what do you remember about me?" });
  assert.match(ask.text, /favourite subject is physics/);
  const forget = await t.chat({ message: "forget physics" });
  assert.equal(forget.of("memory")[0]!.data.action, "deleted");
  assert.equal((await t.api("GET", "/api/memories")).body.total, 0);
  const none = await t.chat({ message: "forget astronomy" });
  assert.equal(none.of("tool").at(-1)!.data.ok, false);
  assert.match(none.text, /No matching memory/);
}));

test("memory: auto-memory OFF refuses non-explicit saves; explicit still works", () => withApp(async (t) => {
  assert.equal((await t.api("PUT", "/api/settings", { autoMemory: false })).status, 200);
  const auto = await t.chat({ message: "remember that auto I like jazz" }); // mock sends explicit=false for 'auto'
  assert.equal(auto.of("tool").at(-1)!.data.ok, false);
  assert.equal((await t.api("GET", "/api/memories")).body.total, 0);
  const q = t.mock.requests.filter((x) => !JSON.stringify(x.body.system).includes("short conversation titles"))[0]!;
  assert.match(q.body.system[1].text, /Automatic memory is OFF/);
  const explicit = await t.chat({ message: "remember that I like jazz" });
  assert.equal(explicit.of("memory")[0]!.data.action, "added");
}));

test("memory: secrets are refused even when the user asks; nothing stored; user is told", () => withApp(async (t) => {
  const r = await t.chat({ message: "remember that my password is hunter2abc" });
  const res = r.of("tool").at(-1)!.data;
  assert.equal(res.ok, false);
  assert.match(res.summary, /password/i);
  assert.equal((await t.api("GET", "/api/memories")).body.total, 0);
  assert.equal((await t.api("POST", "/api/memories", { content: "my card is 4111 1111 1111 1111" })).body.error.code, "sensitive_blocked");
}));

test("private chat: memory tools/injection are disabled; tool can switch a chat private mid-way", () => withApp(async (t) => {
  await t.chat({ message: "remember that I like chess" });
  const p = await t.chat({ message: "this is private", memoryEnabled: false });
  assert.equal(p.of("start")[0]!.data.conversation.memoryEnabled, false);
  const q = t.mock.requests.filter((x) => !JSON.stringify(x.body.system).includes("short conversation titles")).at(-1)!;
  assert.ok(!JSON.stringify(q.body.tools).includes("memory_save"));
  assert.ok(!q.body.system[1].text.includes("I like chess"), "no stored memories leaked into a private chat");
  assert.match(q.body.system[1].text, /Memory is OFF/);
  const mid = await t.chat({ message: "please keep this private" });
  assert.equal(mid.of("conversation")[0]!.data.conversation.memoryEnabled, false);
  const id = mid.of("start")[0]!.data.conversation.id;
  assert.equal((await t.api("GET", `/api/conversations/${id}`)).body.conversation.memoryEnabled, false);
}));

test("memory CRUD API: add, search, filter, edit, delete, clear-all needs confirmation", () => withApp(async (t) => {
  const a = (await t.api("POST", "/api/memories", { content: "Studies physics", category: "education" })).body;
  const b = (await t.api("POST", "/api/memories", { content: "Likes long walks", category: "interests" })).body;
  assert.equal(a.source, "manual");
  assert.equal((await t.api("GET", "/api/memories?q=physics")).body.total, 1);
  assert.equal((await t.api("GET", "/api/memories?category=interests")).body.memories[0].id, b.id);
  assert.equal((await t.api("GET", "/api/memories?category=bogus")).status, 422);
  const patched = (await t.api("PATCH", `/api/memories/${a.id}`, { content: "Studies physics and maths" })).body;
  assert.equal(patched.content, "Studies physics and maths");
  assert.ok(patched.updatedAt >= a.updatedAt);
  assert.equal((await t.api("PATCH", `/api/memories/${a.id}`, {})).status, 422);
  assert.equal((await t.api("DELETE", `/api/memories/${b.id}`)).status, 204);
  assert.equal((await t.api("DELETE", `/api/memories/${b.id}`)).status, 404);
  assert.equal((await t.api("DELETE", "/api/memories", {})).status, 422);
  assert.equal((await t.api("DELETE", "/api/memories", { confirm: true })).body.deleted, 1);
}));

test("provider errors surface as SSE `error` events with partial text kept; retryable errors retry first", () => withApp(async (t) => {
  const rate = await t.chat({ message: "trigger an error" });
  assert.equal(rate.of("status").length, 2, "two retry notices (ASTER_MAX_RETRIES=2)");
  assert.equal(rate.of("status")[0]!.data.kind, "retry");
  const err = rate.of("error")[0]!.data;
  assert.equal(err.code, "rate_limit");
  assert.equal(err.retryable, true);
  assert.equal(rate.of("done").length, 0);
  const convId = rate.of("start")[0]!.data.conversation.id;
  const stored = (await t.api("GET", `/api/conversations/${convId}`)).body;
  assert.equal(stored.messages[1].status, "error");
  assert.equal(stored.messages[1].error.code, "rate_limit");
  assert.equal(stored.conversation.title, "trigger an error", "fallback title so the sidebar isn't blank");

  const flaky = await t.chat({ message: "flaky request" });
  assert.equal(flaky.of("status").length, 1);
  assert.equal(flaky.of("done").length, 1);

  const mid = await t.chat({ message: "midstream failure" });
  assert.equal(mid.of("error")[0]!.data.code, "overloaded");
  const m = (await t.api("GET", `/api/conversations/${mid.of("start")[0]!.data.conversation.id}`)).body.messages[1];
  assert.equal(m.status, "error");
  assert.match(m.content, /Partial answer/, "partial text preserved");

  assert.equal((await t.chat({ message: "fatal" })).of("error")[0]!.data.code, "auth");
  assert.equal((await t.chat({ message: "toolong" })).of("error")[0]!.data.code, "context_too_long");
  assert.equal((await t.chat({ message: "please refuse" })).of("error")[0]!.data.code, "refusal");
}));

test("missing API key → clear `not_configured` error, conversation still saved", async () => {
  const t = await startTestApp({ ANTHROPIC_API_KEY: "" });
  try {
    assert.equal((await t.api("GET", "/api/meta")).body.apiConfigured, false);
    const r = await t.chat({ message: "hello" });
    assert.equal(r.of("error")[0]!.data.code, "not_configured");
    assert.match(r.of("error")[0]!.data.message, /ANTHROPIC_API_KEY/);
  } finally { await t.stop(); }
});

test("stopping mid-stream keeps the partial text with status 'stopped'; a second send is allowed after", () => withApp(async (t) => {
  const ctl = new AbortController();
  const res = await fetch(t.base + "/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ message: "slow answer" }), signal: ctl.signal });
  const reader = res.body!.getReader();
  let seen = "";
  while (!/event: delta/.test(seen)) { const { value } = await reader.read(); seen += new TextDecoder().decode(value); }
  await new Promise((r) => setTimeout(r, 400));
  ctl.abort();
  await new Promise((r) => setTimeout(r, 600));
  const convs = (await t.api("GET", "/api/conversations")).body.conversations;
  const msgs = (await t.api("GET", `/api/conversations/${convs[0].id}`)).body.messages;
  assert.equal(msgs[1].status, "stopped");
  assert.ok(msgs[1].content.length > 0);
  assert.notEqual(convs[0].title, "New conversation", "stopped chats still get a title");
  const again = await t.chat({ conversationId: convs[0].id, message: "continue please" });
  assert.equal(again.of("done").length, 1);
}));

test("concurrent generation in one conversation is rejected with 409", () => withApp(async (t) => {
  const first = await t.chat({ message: "hello" });
  const id = first.of("start")[0]!.data.conversation.id;
  const ctl = new AbortController();
  const slow = fetch(t.base + "/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ conversationId: id, message: "slow one" }), signal: ctl.signal });
  await new Promise((r) => setTimeout(r, 300));
  const second = await t.chat({ conversationId: id, message: "another" });
  assert.equal(second.status, 409);
  assert.equal((await t.api("DELETE", `/api/conversations/${id}`)).status, 409, "can't delete while generating");
  ctl.abort(); await slow.catch(() => {});
  await new Promise((r) => setTimeout(r, 500));
}));

test("images: upload → attach → model receives an image block; attachment bytes retrievable; cannot be reused", () => withApp(async (t) => {
  const up = await t.upload(PNG_1x1, "image/png", "problem.png");
  assert.equal(up.status, 201);
  assert.equal(up.body.kind, "image");
  const r = await t.chat({ message: "what is this problem?", attachmentIds: [up.body.id] });
  assert.match(r.text, /attached image/);
  const sent = t.mock.requests.find((q) => q.body.messages[0].content.some((b: any) => b.type === "image"))!;
  assert.equal(sent.body.messages[0].content[0].source.media_type, "image/png");
  assert.equal(Buffer.from(sent.body.messages[0].content[0].source.data, "base64").equals(PNG_1x1), true);
  const conv = (await t.api("GET", `/api/conversations/${r.of("start")[0]!.data.conversation.id}`)).body;
  assert.equal(conv.messages[0].attachments[0].name, "problem.png");
  const file = await fetch(t.base + conv.messages[0].attachments[0].url);
  assert.equal(file.headers.get("content-type"), "image/png");
  assert.equal(file.headers.get("x-content-type-options"), "nosniff");
  assert.match(file.headers.get("content-security-policy")!, /sandbox/);
  assert.equal((await t.chat({ message: "again", attachmentIds: [up.body.id] })).status, 422, "already-attached upload can't be reused");
  assert.equal((await t.api("DELETE", `/api/uploads/${up.body.id}`)).status, 404, "attached uploads can't be deleted via /uploads");
}));

test("uploads: rejects spoofed/executable/oversized files; unattached uploads are deletable; text files reach the model", () => withApp(async (t) => {
  assert.equal((await t.upload(Buffer.from("<svg/>"), "image/svg+xml", "a.svg")).status, 415);
  assert.equal((await t.upload(Buffer.from("MZ\x00\x00"), "application/octet-stream", "a.exe")).status, 415);
  assert.equal((await t.upload(Buffer.from("text pretending"), "image/png", "a.png")).status, 415);
  assert.equal((await t.upload(Buffer.alloc(0), "text/plain", "a.txt")).status, 422);
  const small = await startTestApp({ ASTER_MAX_TEXT_BYTES: "2048" });
  try { assert.equal((await small.upload(Buffer.alloc(5000, 97), "text/plain", "big.txt")).status, 413); } finally { await small.stop(); }
  const ok = await t.upload(Buffer.from("def f(): return 42"), "text/plain", "notes.py");
  assert.equal(ok.body.kind, "text");
  assert.equal((await t.api("DELETE", `/api/uploads/${ok.body.id}`)).status, 204);
  const again = await t.upload(Buffer.from("x = 1"), "text/plain", "x.py");
  await t.chat({ message: "explain this code", attachmentIds: [again.body.id] });
  const q = t.mock.requests.find((r) => JSON.stringify(r.body.messages).includes("attached_file"))!;
  assert.match(JSON.stringify(q.body.messages), /x = 1/);
  const six = await Promise.all([1, 2, 3, 4, 5, 6].map((i) => t.upload(Buffer.from("t" + i), "text/plain", `f${i}.txt`)));
  assert.equal((await t.chat({ message: "too many", attachmentIds: six.map((u) => u.body.id) })).status, 422);
}));

test("conversation management: list, search (bodies+titles), rename, archive, delete", () => withApp(async (t) => {
  const a = (await t.chat({ message: "tell me about photosynthesis" })).of("start")[0]!.data.conversation.id;
  const b = (await t.chat({ message: "something else entirely" })).of("start")[0]!.data.conversation.id;
  assert.equal((await t.api("GET", "/api/conversations")).body.conversations.length, 2);
  const found = (await t.api("GET", "/api/conversations?q=photosynthesis")).body.conversations;
  assert.deepEqual(found.map((c: any) => c.id), [a]);
  assert.match(found[0].snippet, /<mark>photosynthesis<\/mark>/);
  assert.equal((await t.api("PATCH", `/api/conversations/${a}`, { title: "Plants" })).body.titleSource, "user");
  assert.equal((await t.api("PATCH", `/api/conversations/${a}`, { title: "  " })).status, 422);
  await t.chat({ conversationId: a, message: "more" });
  assert.equal((await t.api("GET", `/api/conversations/${a}`)).body.conversation.title, "Plants", "user-chosen title is never overwritten");
  assert.equal((await t.api("PATCH", `/api/conversations/${b}`, { archived: true })).body.archived, true);
  assert.equal((await t.api("GET", "/api/conversations")).body.conversations.length, 1);
  assert.equal((await t.api("GET", "/api/conversations?archived=1")).body.conversations[0].id, b);
  assert.equal((await t.api("DELETE", `/api/conversations/${b}`)).status, 204);
  assert.equal((await t.api("GET", `/api/conversations/${b}`)).status, 404);
  assert.equal((await t.api("GET", "/api/conversations?limit=0")).status, 422);
}));

test("settings change the prompt the model receives", () => withApp(async (t) => {
  await t.api("PUT", "/api/settings", { responseStyle: "concise", explainLevel: "beginner", language: "Bengali", customInstructions: "Call me Sakib.", model: "claude-haiku-5-5" });
  await t.chat({ message: "hi there" });
  const q = t.mock.requests.filter((x) => !JSON.stringify(x.body.system).includes("short conversation titles"))[0]!;
  const dyn = q.body.system[1].text;
  assert.match(dyn, /concise/); assert.match(dyn, /BEGINNER/); assert.match(dyn, /Always reply in Bengali/); assert.match(dyn, /Call me Sakib/);
  assert.equal(q.body.model, "claude-haiku-5-5");
  assert.equal((await t.api("PUT", "/api/settings", { theme: "purple" })).status, 422);
}));

test("export contains everything; delete-all needs the exact phrase and wipes data", () => withApp(async (t) => {
  await t.chat({ message: "remember that I like chess" });
  const up = await t.upload(Buffer.from("hello"), "text/plain", "h.txt");
  await t.chat({ message: "with file", attachmentIds: [up.body.id] });
  const exp = await fetch(t.base + "/api/export?files=1");
  assert.match(exp.headers.get("content-disposition")!, /attachment; filename="aster-export-\d{4}-\d{2}-\d{2}\.json"/);
  const data = await exp.json() as any;
  assert.equal(data.memories.length, 1);
  assert.equal(data.conversations.length, 2);
  assert.equal(data.files.length, 1);
  assert.equal(Buffer.from(data.files[0].dataBase64, "base64").toString(), "hello");
  assert.ok(!JSON.stringify((await (await fetch(t.base + "/api/export")).json())).includes("dataBase64"), "files only when asked");

  assert.equal((await t.api("DELETE", "/api/data", { confirm: "yes" })).status, 422);
  assert.equal((await t.api("GET", "/api/memories")).body.total, 1, "nothing deleted by a wrong phrase");
  const del = await t.api("DELETE", "/api/data", { confirm: "DELETE ALL MY DATA" });
  assert.deepEqual(del.body.deleted, { conversations: 2, messages: 4, memories: 1, attachments: 1 });
  assert.equal((await t.api("GET", "/api/conversations")).body.conversations.length, 0);
  assert.equal((await t.api("GET", "/api/memories")).body.total, 0);
  assert.equal((await t.api("GET", "/api/conversations?q=chess")).body.conversations.length, 0, "search index is cleared too");
}));

test("validation: malformed chat requests are rejected with 4xx JSON, never 500", () => withApp(async (t) => {
  for (const body of [{}, { message: "" }, { message: 5 }, { message: "x".repeat(40000) }, { message: "a", mode: "evil" }, { message: "a", model: "bad model" }, { message: "a", attachmentIds: "x" }, { message: "a", action: "nuke" }, { message: "a", memoryEnabled: "no" }]) {
    const r = await t.chat(body as any);
    assert.ok(r.status >= 400 && r.status < 500, `${JSON.stringify(body).slice(0, 50)} → ${r.status}`);
    assert.ok(r.error?.error?.code);
  }
  assert.equal((await t.chat({ conversationId: "doesnotexist", message: "hi" })).status, 404);
  const bad = await fetch(t.base + "/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: "{not json" });
  assert.equal(bad.status, 400);
  const wrongType = await fetch(t.base + "/api/chat", { method: "POST", headers: { "content-type": "text/plain" }, body: "{}" .repeat(1) });
  assert.ok([200, 415].includes(wrongType.status));
  const huge = await fetch(t.base + "/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: "x".repeat(3 * 1024 * 1024) });
  assert.equal(huge.status, 413);
}));
