import { test } from 'node:test';
import assert from 'node:assert/strict';
import { extractMath, restoreMath, renderTeX, tokenFor } from '../../public/js/lib/math.js';

const texOf = (src: string, streaming = false) => extractMath(src, { streaming }).items.map((i: { tex: string }) => i.tex);

test('extracts all four delimiter styles', () => {
  const r = extractMath('a $x^2$ b $$\\int_0^1 x\\,dx$$ c \\(y\\) d \\[z\\] e');
  assert.deepEqual(r.items.map((i: { tex: string; display: boolean }) => [i.tex, i.display]), [
    ['x^2', false], ['\\int_0^1 x\\,dx', true], ['y', false], ['z', true],
  ]);
  assert.equal(r.text, `a ${tokenFor(0)} b ${tokenFor(1)} c ${tokenFor(2)} d ${tokenFor(3)} e`);
});

test('does not treat currency as math', () => {
  assert.deepEqual(texOf('It costs $5 and $10 in total.'), []);
  assert.deepEqual(texOf('From $20,000-$30,000 a year'), []);
  assert.deepEqual(texOf('Pay $5. Then $x=1$ later'), ['x=1']);
  assert.deepEqual(texOf('a lone $ sign'), []);
});

test('escaped dollars are literal', () => {
  assert.deepEqual(texOf('cost \\$5 and \\$6'), []);
  assert.deepEqual(texOf('\\$a\\$ and $b$'), ['b']);
});

test('leaves code fences and inline code untouched', () => {
  const src = 'before $a$\n```js\nconst s = "$x$"; // $$y$$\n```\nand `$z$` then $w$';
  assert.deepEqual(texOf(src), ['a', 'w']);
  const r = extractMath(src);
  assert.ok(r.text.includes('"$x$"') && r.text.includes('`$z$`'));
});

test('unclosed fence swallows the rest (streaming-safe)', () => {
  assert.deepEqual(texOf('x $a$\n```py\n$b$ still in code'), ['a']);
});

test('tilde fences and longer fences are respected', () => {
  assert.deepEqual(texOf('~~~\n$a$\n~~~\n$b$'), ['b']);
  assert.deepEqual(texOf('````\n```\n$a$\n````\n$b$'), ['b']);
});

test('no blank line inside inline math; multi-line display math is allowed', () => {
  assert.deepEqual(texOf('$a\n\nb$'), []);
  assert.deepEqual(texOf('$$\na = b\n$$'), ['\na = b\n']);
});

test('streaming: unterminated display math becomes a pending item; final mode leaves it literal', () => {
  const live = extractMath('so $$\\frac{a}{', { streaming: true });
  assert.equal(live.items.length, 1);
  assert.equal(live.items[0].pending, true);
  assert.match(restoreMath(live.text, live.items), /math-pending/);
  const done = extractMath('so $$\\frac{a}{', { streaming: false });
  assert.equal(done.items.length, 0);
  assert.equal(done.text, 'so $$\\frac{a}{');
});

test('never throws on hostile input', () => {
  for (const s of ['$', '$$', '\\[', '\\(', '`', '```', '$ $', '\\', '\uE000 0 \uE001', '$$$$', '$a$$b$']) {
    assert.doesNotThrow(() => extractMath(s, { streaming: true }));
    assert.doesNotThrow(() => extractMath(s, { streaming: false }));
  }
});

test('private-use token characters in the source are stripped, not trusted', () => {
  const r = extractMath('x \uE0000\uE001 y');
  assert.equal(r.items.length, 0);
  assert.ok(!r.text.includes('\uE000'));
});

test('renderTeX renders KaTeX and survives invalid TeX', () => {
  assert.match(renderTeX('\\frac{a}{b}'), /class="katex"/);
  assert.match(renderTeX('\\frac{a}{b}', true), /katex-display/);
  const bad = renderTeX('\\notamacro{');
  assert.ok(typeof bad === 'string' && bad.length > 0);
});

test('renderTeX does not enable trusted commands', () => {
  const html = renderTeX('\\href{javascript:alert(1)}{x}');
  assert.ok(!/href="javascript/i.test(html));
  assert.ok(!/<script/i.test(renderTeX('\\text{<script>alert(1)</script>}')));
});

test('restoreMath unwraps a paragraph that only holds display math', () => {
  const { text, items } = extractMath('$$x$$');
  const html = restoreMath(`<p>${text}</p>`, items);
  assert.ok(!html.startsWith('<p>'));
  assert.match(html, /katex-display/);
});
