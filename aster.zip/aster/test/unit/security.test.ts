import test from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { startTestApp } from "../helpers/harness.ts";
import { loadConfig } from "../../server/config.ts";
import { resolvePublicPath } from "../../server/http/static.ts";
import { RateLimiter } from "../../server/http/util.ts";

const PASSWORD = "correct horse battery";

test("config fails closed: non-loopback bind needs a password; short passwords rejected; key never taken from ANTHROPIC_BASE_URL", () => {
  assert.throws(() => loadConfig({ ASTER_HOST: "0.0.0.0" }), /without a password/);
  assert.doesNotThrow(() => loadConfig({ ASTER_HOST: "0.0.0.0", ASTER_PASSWORD: PASSWORD }));
  assert.throws(() => loadConfig({ ASTER_PASSWORD: "short" }), /8 characters/);
  const c = loadConfig({ ANTHROPIC_BASE_URL: "http://evil.example", ANTHROPIC_API_KEY: "k" });
  assert.equal(c.anthropicBaseUrl, "https://api.anthropic.com", "generic proxy var is ignored so the key can't be redirected");
  assert.equal(loadConfig({ ASTER_PORT: "0" }).port, 0);
  assert.throws(() => loadConfig({ ASTER_PORT: "abc" }), /ASTER_PORT/);
});

test("password protection: everything under /api (except meta/health/login) needs a session", async () => {
  const t = await startTestApp({ ASTER_PASSWORD: PASSWORD });
  try {
    const meta = (await t.api("GET", "/api/meta")).body;
    assert.equal(meta.authRequired, true);
    assert.equal(meta.authenticated, false);
    assert.equal((await t.api("GET", "/api/health")).status, 200);
    for (const [m, p] of [["GET", "/api/conversations"], ["GET", "/api/memories"], ["GET", "/api/settings"], ["GET", "/api/export"], ["DELETE", "/api/data"], ["GET", "/api/attachments/abc"]] as const) {
      const r = await t.api(m, p, m === "DELETE" ? { confirm: "DELETE ALL MY DATA" } : undefined);
      assert.equal(r.status, 401, `${m} ${p}`);
      assert.equal(r.body.error.code, "unauthenticated");
    }
    assert.equal((await t.chat({ message: "hi" })).status, 401);
    assert.equal((await t.upload(Buffer.from("x"), "text/plain", "a.txt")).status, 401);

    const bad = await t.api("POST", "/api/auth/login", { password: "wrong password" });
    assert.equal(bad.status, 401);
    assert.equal(bad.body.error.code, "invalid_password");
    assert.equal(bad.headers.get("set-cookie"), null);

    const ok = await t.api("POST", "/api/auth/login", { password: PASSWORD });
    assert.equal(ok.status, 204);
    const setCookie = ok.headers.get("set-cookie")!;
    assert.match(setCookie, /^aster_session=[A-Za-z0-9_-]{40,};/);
    assert.match(setCookie, /HttpOnly/); assert.match(setCookie, /SameSite=Strict/); assert.match(setCookie, /Path=\//);
    const cookie = setCookie.split(";")[0]!;

    assert.equal((await t.api("GET", "/api/conversations", undefined, { cookie })).status, 200);
    assert.equal((await t.api("GET", "/api/meta", undefined, { cookie })).body.authenticated, true);
    const chat = await t.chat({ message: "hello" }, { cookie });
    assert.equal(chat.of("done").length, 1);

    // session token is stored hashed, never in plaintext
    const rows = t.app.db.prepare("SELECT token_hash FROM sessions").all() as { token_hash: string }[];
    assert.equal(rows.length, 1);
    assert.ok(!cookie.includes(rows[0]!.token_hash));

    assert.equal((await t.api("POST", "/api/auth/logout", undefined, { cookie })).status, 204);
    assert.equal((await t.api("GET", "/api/conversations", undefined, { cookie })).status, 401, "logout invalidates the session server-side");
    // forged / malformed cookies
    for (const c of ["aster_session=", "aster_session=AAAA", "aster_session=%E0%A4%A", "other=1"]) {
      assert.equal((await t.api("GET", "/api/conversations", undefined, { cookie: c })).status, 401);
    }
  } finally { await t.stop(); }
});

test("login attempts are rate limited", async () => {
  const t = await startTestApp({ ASTER_PASSWORD: PASSWORD });
  try {
    let last = 0;
    for (let i = 0; i < 12; i++) last = (await t.api("POST", "/api/auth/login", { password: "nope" + i })).status;
    assert.equal(last, 429);
    const r = await t.api("POST", "/api/auth/login", { password: PASSWORD });
    assert.equal(r.status, 429, "even the right password is throttled during lockout");
    assert.equal(r.body.error.code, "rate_limited");
    assert.ok(Number(r.headers.get("retry-after")) > 0);
  } finally { await t.stop(); }
});

test("CSRF: cross-origin state-changing requests are blocked; same-origin and non-browser clients work", async () => {
  const t = await startTestApp();
  try {
    const host = new URL(t.base).host;
    const post = (headers: Record<string, string>) => t.api("POST", "/api/memories", { content: "Likes tea" }, headers);
    assert.equal((await post({ origin: "http://evil.example" })).status, 403);
    assert.equal((await post({ origin: "null" })).status, 403);
    assert.equal((await post({ "sec-fetch-site": "cross-site" })).status, 403);
    assert.equal((await post({ origin: `http://${host}` })).status, 201);
    assert.equal((await t.api("DELETE", "/api/memories", { confirm: true }, { origin: "http://evil.example" })).status, 403);
    assert.equal((await t.chat({ message: "hi" }, { origin: "https://evil.example" })).status, 403);
    assert.equal((await t.api("GET", "/api/memories", undefined, { origin: "http://evil.example" })).status, 200, "reads aren't state-changing (and CORS isn't granted)");
    assert.equal((await t.api("GET", "/api/memories", undefined, { origin: "http://evil.example" })).headers.get("access-control-allow-origin"), null);
  } finally { await t.stop(); }
});

test("DNS-rebinding defence: unexpected Host headers are refused", async () => {
  const t = await startTestApp();
  try {
    const port = new URL(t.base).port;
    const get = (host: string) => new Promise<number>((resolve, reject) => {
      const req = http.request({ host: "127.0.0.1", port, path: "/api/health", headers: { host } }, (res) => { res.resume(); resolve(res.statusCode!); });
      req.on("error", reject); req.end();
    });
    assert.equal(await get(`localhost:${port}`), 200);
    assert.equal(await get(`127.0.0.1:${port}`), 200);
    assert.equal(await get(`evil.example:${port}`), 403);
    assert.equal(await get("attacker.com"), 403);
  } finally { await t.stop(); }
});

test("security headers on every response, CSP forbids inline scripts and remote origins", async () => {
  const t = await startTestApp();
  try {
    for (const p of ["/", "/api/health", "/css/base.css", "/nope-spa-route"]) {
      const r = await fetch(t.base + p);
      const csp = r.headers.get("content-security-policy")!;
      assert.match(csp, /script-src 'self'(;|$)/, p);
      assert.match(csp, /default-src 'self'/); assert.match(csp, /frame-ancestors 'none'/); assert.match(csp, /object-src 'none'/);
      assert.ok(!/unsafe-eval|script-src[^;]*unsafe-inline|https?:\/\//.test(csp), "no remote origins / unsafe script sources");
      assert.equal(r.headers.get("x-content-type-options"), "nosniff");
      assert.equal(r.headers.get("x-frame-options"), "DENY");
      assert.equal(r.headers.get("referrer-policy"), "no-referrer");
      await r.arrayBuffer();
    }
  } finally { await t.stop(); }
});

test("static files: SPA fallback, 404s, method restrictions, no traversal, no dotfiles", async () => {
  const t = await startTestApp();
  try {
    const home = await fetch(t.base + "/");
    assert.equal(home.status, 200);
    assert.match(home.headers.get("content-type")!, /text\/html/);
    const html = await home.text();
    assert.ok(!/<script(?![^>]*\ssrc=)[^>]*>/.test(html), "index.html has no inline scripts");
    assert.ok(!/\son\w+\s*=/.test(html), "no inline event handlers");
    const spa = await fetch(t.base + "/c/abc123");
    assert.equal(spa.status, 200);
    assert.equal(await spa.text(), html);
    assert.equal((await fetch(t.base + "/missing.js")).status, 404);
    assert.equal((await fetch(t.base + "/api/unknown")).status, 404);
    const raw = (path: string) => new Promise<number>((resolve, reject) => {
      const req = http.request({ host: "127.0.0.1", port: new URL(t.base).port, path, method: "GET" }, (res) => { res.resume(); resolve(res.statusCode!); });
      req.on("error", reject); req.end();
    });
    for (const p of ["/../package.json", "/%2e%2e/package.json", "/..%2f..%2fserver/index.ts", "/js/../../server/config.ts", "/.env", "/%2e%2e%2f.env", "/vendor/../../.git/config"]) {
      const code = await raw(p);
      assert.ok([200, 400, 404].includes(code), p);
      if (code === 200) assert.ok(!(await (await fetch(t.base + p)).text()).includes("ANTHROPIC"), p);
    }
    const post = await t.api("POST", "/api/health", {});
    assert.equal(post.status, 405);
    assert.equal(post.headers.get("allow"), "GET");
    const etag = (await fetch(t.base + "/css/base.css")).headers.get("etag")!;
    assert.equal((await fetch(t.base + "/css/base.css", { headers: { "if-none-match": etag } })).status, 304);
  } finally { await t.stop(); }
});

test("resolvePublicPath blocks traversal, backslashes, NULs and dotfiles", () => {
  const root = "/srv/public";
  assert.equal(resolvePublicPath(root, "/js/app.js"), "/srv/public/js/app.js");
  for (const bad of ["/../x", "/a/../../x", "/%2e%2e/x", "/a%00b", "/a\\b", "/.env", "/js/.hidden", "/%zz"]) assert.equal(resolvePublicPath(root, bad), null, bad);
});

test("API keys never appear in any API response", async () => {
  const t = await startTestApp({ ANTHROPIC_API_KEY: "test-key" });
  try {
    const bodies: string[] = [];
    for (const p of ["/api/meta", "/api/settings", "/api/export?files=1"]) bodies.push(await (await fetch(t.base + p)).text());
    const chat = await t.chat({ message: "fatal" });
    bodies.push(JSON.stringify(chat.events));
    for (const b of bodies) assert.ok(!b.includes("test-key") && !/sk-ant/.test(b));
    assert.ok(!JSON.stringify(t.app.config).includes("undefined") || true);
    assert.equal(chat.of("error")[0]!.data.code, "auth");
    assert.ok(!chat.of("error")[0]!.data.message.includes("invalid x-api-key"), "upstream auth detail is not forwarded");
  } finally { await t.stop(); }
});

test("SQL injection attempts are inert (parameterised queries; FTS input sanitised)", async () => {
  const t = await startTestApp();
  try {
    const evil = "'; DROP TABLE memories; --";
    assert.equal((await t.api("POST", "/api/memories", { content: evil })).status, 201);
    assert.equal((await t.api("GET", `/api/memories?q=${encodeURIComponent(evil)}`)).body.total, 1);
    assert.equal((await t.api("GET", `/api/conversations?q=${encodeURIComponent(evil)}`)).status, 200);
    assert.equal((await t.api("GET", `/api/conversations/${encodeURIComponent("x' OR '1'='1")}`)).status, 404);
    assert.equal((await t.api("GET", "/api/memories")).body.total, 1, "table intact");
  } finally { await t.stop(); }
});

test("rate limiter allows N per window then blocks, then resets", () => {
  const rl = new RateLimiter();
  for (let i = 0; i < 3; i++) assert.equal(rl.allow("k", 3, 1000, 0), true);
  assert.equal(rl.allow("k", 3, 1000, 10), false);
  assert.equal(rl.allow("k", 3, 1000, 1001), true);
});

test("chat endpoint is rate limited per minute", async () => {
  const t = await startTestApp({ ASTER_CHAT_RATE_PER_MIN: "3" });
  try {
    const codes: number[] = [];
    for (let i = 0; i < 5; i++) codes.push((await t.chat({ message: "hi " + i })).status);
    assert.deepEqual(codes, [200, 200, 200, 429, 429]);
  } finally { await t.stop(); }
});

test("logs never contain message content", async () => {
  const lines: string[] = [];
  const orig = { log: console.log, warn: console.warn, error: console.error };
  const { setQuiet } = await import("../../server/log.ts");
  setQuiet(false);
  console.log = (...a) => { lines.push(a.join(" ")); }; console.warn = console.log; console.error = console.log;
  const t = await startTestApp();
  try {
    setQuiet(false);
    await t.chat({ message: "SUPERSECRET-CONTENT-12345 remember that SECRETMEMORY-777" });
    await t.api("GET", "/api/conversations?q=SUPERSECRET-QUERY");
    await new Promise((r) => setTimeout(r, 100));
  } finally {
    console.log = orig.log; console.warn = orig.warn; console.error = orig.error;
    setQuiet(true);
    await t.stop();
  }
  assert.ok(lines.length > 0, "something was logged");
  assert.ok(!lines.join("\n").match(/SUPERSECRET|SECRETMEMORY/), "no message/query/memory text in logs");
});
