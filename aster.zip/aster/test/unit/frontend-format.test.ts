import { test } from 'node:test';
import assert from 'node:assert/strict';
import { formatBytes, timeAgo, greeting, truncate } from '../../public/js/lib/format.js';

test('formatBytes', () => {
  assert.equal(formatBytes(512), '512 B');
  assert.equal(formatBytes(1536), '1.5 KB');
  assert.equal(formatBytes(2 * 1024 * 1024), '2 MB');
  assert.equal(formatBytes(-1), '');
});

test('timeAgo', () => {
  const now = Date.parse('2026-11-08T12:00:00Z');
  assert.equal(timeAgo('2026-11-08T11:59:50Z', now), 'just now');
  assert.equal(timeAgo('2026-11-08T11:30:00Z', now), '30 min ago');
  assert.equal(timeAgo('2026-11-08T09:00:00Z', now), '3 h ago');
  assert.equal(timeAgo('2026-11-06T12:00:00Z', now), '2 d ago');
  assert.equal(timeAgo('not a date', now), '');
});

test('greeting and truncate', () => {
  assert.equal(greeting(new Date(2026, 0, 1, 9)), 'Good morning');
  assert.equal(greeting(new Date(2026, 0, 1, 14)), 'Good afternoon');
  assert.equal(greeting(new Date(2026, 0, 1, 21)), 'Good evening');
  assert.equal(truncate('abcdef', 4), 'abc…');
  assert.equal(truncate('abc', 4), 'abc');
});
