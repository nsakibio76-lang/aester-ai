import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createSSEParser } from '../../public/js/lib/sse.js';

function collect(chunks: string[], flush = true) {
  const events: Array<{ event: string; data: string }> = [];
  const p = createSSEParser((e: { event: string; data: string }) => events.push(e));
  for (const c of chunks) p.push(c);
  if (flush) p.flush();
  return events;
}

test('parses events and JSON data', () => {
  const ev = collect(['event: delta\ndata: {"text":"Hi"}\n\nevent: done\ndata: {}\n\n']);
  assert.deepEqual(ev.map((e) => e.event), ['delta', 'done']);
  assert.equal(JSON.parse(ev[0].data).text, 'Hi');
});

test('handles arbitrary chunk boundaries', () => {
  const full = 'event: delta\ndata: {"text":"héllo"}\n\nevent: done\ndata: {"ok":true}\n\n';
  for (let cut = 1; cut < full.length; cut++) {
    const ev = collect([full.slice(0, cut), full.slice(cut)]);
    assert.equal(ev.length, 2, `cut at ${cut}`);
    assert.equal(ev[0].event, 'delta');
    assert.equal(JSON.parse(ev[1].data).ok, true);
  }
});

test('supports CRLF, multi-line data, comments and default event name', () => {
  const ev = collect([': keepalive\r\n\r\ndata: a\r\ndata: b\r\n\r\n']);
  assert.equal(ev.length, 1);
  assert.equal(ev[0].event, 'message');
  assert.equal(ev[0].data, 'a\nb');
});

test('CR split from its LF across chunks does not create an extra blank line', () => {
  const ev = collect(['event: x\r', '\ndata: 1\r', '\n\r', '\n']);
  assert.deepEqual(ev, [{ event: 'x', data: '1' }]);
});

test('flush dispatches a trailing event without blank line; no data means no event', () => {
  assert.equal(collect(['event: done\ndata: {}']).length, 1);
  assert.equal(collect(['event: done\ndata: {}'], false).length, 0);
  assert.equal(collect(['event: ping\n\n']).length, 0);
});
