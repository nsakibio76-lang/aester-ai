import test from "node:test";
import assert from "node:assert/strict";
import { buildRequestBody, createAnthropicProvider, mapApiError, parseSse } from "../../server/providers/anthropic.ts";
import { AppError } from "../../server/errors.ts";
import { classifyUpload, sanitizeFileName } from "../../server/http/uploads.ts";
import { buildContext } from "../../server/chat/context.ts";
import { loadConfig } from "../../server/config.ts";
import { PNG_1x1 } from "../helpers/harness.ts";
import { startMockAnthropic } from "../helpers/mock-anthropic.ts";
import { createAttachmentRepo } from "../../server/repo/messages.ts";
import { openDb } from "../../server/db.ts";
import type { Message } from "../../server/repo/types.ts";
import type { ProviderEvent, ProviderRequest } from "../../server/providers/types.ts";

const cfg = loadConfig({ ASTER_DATA_DIR: "/tmp/x" }, "/tmp");

// ---------- SSE ----------
test("parseSse handles CRLF, split chunks, comments and multi-line data", async () => {
  const enc = new TextEncoder();
  const parts = ["event: a\r\ndata: {\"x\":1}\r", "\n\r\n: ping\n\nevent: b\ndata: l1\ndata: l2\n\n", "data: tail\n\n"];
  const stream = new ReadableStream<Uint8Array>({ start(c) { for (const p of parts) c.enqueue(enc.encode(p)); c.close(); } });
  const got: { event: string; data: string }[] = [];
  for await (const e of parseSse(stream)) got.push(e);
  assert.deepEqual(got, [{ event: "a", data: '{"x":1}' }, { event: "b", data: "l1\nl2" }, { event: "message", data: "tail" }]);
});

// ---------- error mapping ----------
test("mapApiError covers auth, billing, context, rate limit, overload, server", () => {
  const code = (s: number, t?: string, m?: string) => mapApiError(s, t, m, null).code;
  assert.equal(code(401), "auth");
  assert.equal(code(403), "permission");
  assert.equal(code(404), "not_found");
  assert.equal(code(400, "invalid_request_error", "prompt is too long: 250000 tokens > 200000 maximum"), "context_too_long");
  assert.equal(code(413), "context_too_long");
  assert.equal(code(400, "invalid_request_error", "Your credit balance is too low"), "billing");
  assert.equal(code(400, "invalid_request_error", "messages: bad"), "invalid_request");
  assert.equal(code(429), "rate_limit");
  assert.equal(code(529), "overloaded");
  assert.equal(code(500), "server");
  assert.equal(mapApiError(429, "rate_limit_error", "x", 3000).retryAfterMs, 3000);
  assert.ok(mapApiError(429, undefined, undefined, null).retryable);
  assert.ok(!mapApiError(401, undefined, undefined, null).retryable);
  assert.ok(!mapApiError(401, undefined, "bad key sk-ant-SECRET", null).message.includes("SECRET"), "never echoes upstream text for auth errors");
});

test("buildRequestBody maps blocks, cache_control and tools", () => {
  const body = buildRequestBody({
    model: "m", maxTokens: 10,
    system: [{ text: "static", cache: true }, { text: "dyn" }],
    messages: [
      { role: "user", content: [{ type: "image", mediaType: "image/png", data: "QUJD" }, { type: "text", text: "hi" }] },
      { role: "assistant", content: [{ type: "tool_use", id: "t1", name: "calculate", input: { expression: "1+1" } }] },
      { role: "user", content: [{ type: "tool_result", toolUseId: "t1", content: "2" }] },
    ],
    tools: [{ name: "calculate", description: "d", inputSchema: { type: "object" } }],
  }) as any;
  assert.equal(body.stream, true);
  assert.deepEqual(body.system[0].cache_control, { type: "ephemeral" });
  assert.equal(body.system[1].cache_control, undefined);
  assert.equal(body.messages[0].content[0].source.media_type, "image/png");
  assert.equal(body.messages[2].content[0].tool_use_id, "t1");
  assert.equal(body.tools[0].input_schema.type, "object");
});

// ---------- provider against the mock wire protocol ----------
const req = (text: string): ProviderRequest => ({ model: "m", maxTokens: 100, system: [{ text: "s" }], messages: [{ role: "user", content: [{ type: "text", text }] }] });
async function collect(p: ReturnType<typeof createAnthropicProvider>, r: ProviderRequest, signal = new AbortController().signal): Promise<ProviderEvent[]> {
  const out: ProviderEvent[] = [];
  for await (const e of p.stream(r, signal)) out.push(e);
  return out;
}

test("provider streams text + tool_use + usage from the Messages wire format", async () => {
  const mock = await startMockAnthropic({ apiKey: "k" });
  try {
    const p = createAnthropicProvider({ apiKey: "k", anthropicBaseUrl: mock.url, streamIdleTimeoutMs: 5000 });
    const evs = await collect(p, req("remember that I like tea"));
    assert.equal(evs.filter((e) => e.type === "text").map((e) => (e as any).text).join(""), "Let me save that.");
    const tool = evs.find((e) => e.type === "tool_use") as any;
    assert.equal(tool.name, "memory_save");
    assert.deepEqual(tool.input, { content: "I like tea", category: "context", explicit: true });
    const end = evs.at(-1) as any;
    assert.equal(end.type, "end");
    assert.equal(end.stopReason, "tool_use");
    assert.equal(end.usage.inputTokens, 42);
    // key travels only in the header, never the body
    assert.equal(mock.requests[0]!.headers["x-api-key"], "k");
    assert.ok(!JSON.stringify(mock.requests[0]!.body).includes('"k"'));
  } finally { await mock.close(); }
});

test("provider maps HTTP errors, mid-stream errors, and missing key to AppError codes", async () => {
  const mock = await startMockAnthropic({ apiKey: "k" });
  try {
    const mk = (apiKey: string | null) => createAnthropicProvider({ apiKey, anthropicBaseUrl: mock.url, streamIdleTimeoutMs: 5000 });
    const codeOf = async (p: ReturnType<typeof mk>, text: string) => { try { await collect(p, req(text)); return "none"; } catch (e) { return (e as AppError).code; } };
    assert.equal(await codeOf(mk("wrong"), "hi"), "auth");
    assert.equal(await codeOf(mk("k"), "fatal"), "auth");
    assert.equal(await codeOf(mk("k"), "toolong"), "context_too_long");
    assert.equal(await codeOf(mk("k"), "error"), "rate_limit");
    assert.equal(await codeOf(mk("k"), "midstream"), "overloaded");
    assert.equal(await codeOf(mk(null), "hi"), "not_configured");
    assert.equal(await codeOf(createAnthropicProvider({ apiKey: "k", anthropicBaseUrl: "http://127.0.0.1:1", streamIdleTimeoutMs: 2000 }), "hi"), "network");
  } finally { await mock.close(); }
});

test("provider stops promptly when aborted", async () => {
  const mock = await startMockAnthropic({ apiKey: "k" });
  try {
    const p = createAnthropicProvider({ apiKey: "k", anthropicBaseUrl: mock.url, streamIdleTimeoutMs: 5000 });
    const ctl = new AbortController();
    const t0 = Date.now();
    let n = 0;
    await assert.rejects(async () => { for await (const e of p.stream(req("slow please"), ctl.signal)) { if (e.type === "text" && ++n === 3) ctl.abort(); } }, (e) => (e as AppError).code === "aborted");
    assert.ok(Date.now() - t0 < 2000);
  } finally { await mock.close(); }
});

// ---------- uploads ----------
test("uploads: sniffing decides the type, not the client's claim", () => {
  assert.deepEqual(classifyUpload(PNG_1x1, "image/png", "a.png", cfg), { kind: "image", mime: "image/png", name: "a.png" });
  assert.throws(() => classifyUpload(Buffer.from("<svg onload=alert(1)>"), "image/svg+xml", "x.svg", cfg), /Unsupported/);
  assert.throws(() => classifyUpload(Buffer.from("not really a png"), "image/png", "x.png", cfg), /Unsupported|corrupt/i);
  assert.throws(() => classifyUpload(PNG_1x1, "image/jpeg", "x.jpg", cfg), /match/);
  assert.equal(classifyUpload(Buffer.from("%PDF-1.7\n..."), "application/pdf", "d.pdf", cfg).kind, "pdf");
  assert.throws(() => classifyUpload(Buffer.from("hello"), "application/pdf", "d.pdf", cfg), /valid PDF/);
  assert.equal(classifyUpload(Buffer.from("print('hi')"), "application/octet-stream", "a.py", cfg).kind, "text");
  assert.throws(() => classifyUpload(Buffer.from("MZ\x00\x01"), "application/octet-stream", "evil.exe", cfg), /aren't supported/);
  assert.throws(() => classifyUpload(Buffer.from([0x68, 0x00, 0x69]), "text/plain", "bin.txt", cfg), /binary/);
  assert.throws(() => classifyUpload(Buffer.from([0xff, 0xfe, 0xfd]), "text/plain", "latin.txt", cfg), /UTF-8/);
  assert.throws(() => classifyUpload(new Uint8Array(0), "text/plain", "e.txt", cfg), /empty/);
});

test("uploads: size limits per kind", () => {
  const small = loadConfig({ ASTER_DATA_DIR: "/tmp/x", ASTER_MAX_IMAGE_BYTES: "2048", ASTER_MAX_TEXT_BYTES: "2048" }, "/tmp");
  const bigPng = Buffer.concat([PNG_1x1, Buffer.alloc(4000)]);
  assert.throws(() => classifyUpload(bigPng, "image/png", "big.png", small), (e) => (e as AppError).status === 413);
  assert.throws(() => classifyUpload(Buffer.alloc(3000, 97), "text/plain", "big.txt", small), (e) => (e as AppError).status === 413);
});

test("file names are sanitised (path traversal, control chars, length)", () => {
  assert.equal(sanitizeFileName("../../etc/passwd"), "passwd");
  assert.equal(sanitizeFileName("a\\b\\c.txt"), "c.txt");
  assert.equal(sanitizeFileName(encodeURIComponent("my file<>.png")), "my file.png");
  assert.equal(sanitizeFileName(""), "file");
  assert.ok(sanitizeFileName("x".repeat(500) + ".png").length <= 120);
});

// ---------- context building ----------
const msg = (id: string, role: "user" | "assistant", content: string, status: Message["status"] = "complete"): Message => ({
  id, role, content, status, error: null, model: null, stopReason: null, createdAt: "", attachments: [], toolEvents: [], usage: null,
});

test("context: merges same-role runs, drops empty replies, starts with user, ends with latest user", () => {
  const att = createAttachmentRepo(openDb(":memory:"));
  const h = [msg("1", "assistant", "orphan"), msg("2", "user", "q1"), msg("3", "assistant", "", "error"), msg("4", "user", "q1 again"), msg("5", "assistant", "partial", "stopped"), msg("6", "user", "q2")];
  const { messages } = buildContext(h, att, { budget: 100000, maxTextBytes: 1000 });
  assert.deepEqual(messages.map((m) => m.role), ["user", "assistant", "user"]);
  assert.equal(messages[0]!.content.length, 2, "q1 + q1 again merged");
});

test("context: trims oldest turns to budget but always keeps the latest user message", () => {
  const att = createAttachmentRepo(openDb(":memory:"));
  const long = "x".repeat(3200); // ≈1000 tokens
  const h = [msg("1", "user", long), msg("2", "assistant", long), msg("3", "user", long), msg("4", "assistant", long), msg("5", "user", "latest question")];
  const r = buildContext(h, att, { budget: 1500, maxTextBytes: 1000 });
  assert.ok(r.trimmed >= 3);
  assert.equal(r.messages[0]!.role, "user");
  const last = r.messages.at(-1)!;
  assert.equal((last.content[0] as any).text, "latest question");
});

test("context: attachments become image/document/text blocks", () => {
  const db = openDb(":memory:");
  const att = createAttachmentRepo(db);
  db.exec("INSERT INTO conversations (id,title,created_at,updated_at) VALUES ('c','t','x','x'); INSERT INTO messages (id,conversation_id,seq,role,content,created_at) VALUES ('m','c',1,'user','look','x')");
  const i = att.create({ name: "p.png", kind: "image", mime: "image/png", data: PNG_1x1 });
  const t = att.create({ name: "n.py", kind: "text", mime: "text/plain", data: new TextEncoder().encode("print(1)") });
  att.attach([i.id, t.id], "m");
  const { messages } = buildContext([msg("m", "user", "look")], att, { budget: 10000, maxTextBytes: 1000 });
  const types = messages[0]!.content.map((b) => b.type);
  assert.deepEqual(types, ["image", "text", "text"]);
  assert.match((messages[0]!.content[1] as any).text, /attached_file name="n.py"[\s\S]*print\(1\)/);
});
