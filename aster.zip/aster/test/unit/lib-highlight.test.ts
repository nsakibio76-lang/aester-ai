import { test } from 'node:test';
import assert from 'node:assert/strict';
import { highlightCode, normalizeLanguage } from '../../public/js/lib/highlight.js';

test('normalises aliases and rejects unknown languages', () => {
  assert.equal(normalizeLanguage('py'), 'python');
  assert.equal(normalizeLanguage('C++'), 'cpp');
  assert.equal(normalizeLanguage('sh'), 'bash');
  assert.equal(normalizeLanguage('yml'), 'yaml');
  assert.equal(normalizeLanguage('html'), 'xml');
  assert.equal(normalizeLanguage('brainfuck'), null);
  assert.equal(normalizeLanguage(''), null);
  assert.equal(normalizeLanguage(undefined), null);
});

test('highlights known languages with hljs spans', () => {
  const r = highlightCode('def f(x):\n    return x ** 2', 'python');
  assert.equal(r.language, 'python');
  assert.match(r.html, /<span class="hljs-keyword">def<\/span>/);
});

test('escapes HTML in code, highlighted or not', () => {
  assert.ok(!highlightCode('<script>alert(1)</script>', 'html').html.includes('<script>'));
  const plain = highlightCode('a < b && c > d', 'nonsense');
  assert.equal(plain.language, null);
  assert.equal(plain.html, 'a &lt; b &amp;&amp; c &gt; d');
});

test('handles empty and oversized input', () => {
  assert.equal(highlightCode('', 'js').html, '');
  const big = 'x'.repeat(70000) + '<';
  assert.ok(highlightCode(big, 'js').html.endsWith('&lt;'));
});
