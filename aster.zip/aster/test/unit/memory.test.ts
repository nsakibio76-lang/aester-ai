import test from "node:test";
import assert from "node:assert/strict";
import { openDb } from "../../server/db.ts";
import { createMemoryRepo } from "../../server/repo/memories.ts";
import { createMemoryService } from "../../server/memory/service.ts";
import { checkMemoryContent, detectSecret, detectSensitiveCategory } from "../../server/memory/sensitive.ts";
import { AppError } from "../../server/errors.ts";

const svc = (max = 500) => createMemoryService(createMemoryRepo(openDb(":memory:")), { maxMemories: max });

test("secrets are always refused (any source)", () => {
  const secrets = [
    "my password is hunter2abc",
    "api key: sk-ant-api03-abcdefghijklmnop",
    "card 4111 1111 1111 1111",
    "ssn 123-45-6789",
    "my passport number is A1234567",
    "account number: 1234567890123",
    "token ghp_abcdefghijklmnopqrstuvwxyz0123456789",
    "-----BEGIN RSA PRIVATE KEY-----",
  ];
  for (const s of secrets) {
    for (const src of ["auto", "explicit", "manual"] as const) assert.ok(checkMemoryContent(s, src), `${src}: ${s}`);
  }
  assert.equal(detectSecret("order number 1234 5678 9012 3456"), null, "non-Luhn digit run is not a card");
  assert.equal(detectSecret("I am learning calculus and prefer worked examples"), null);
});

test("sensitive categories are blocked for automatic memory only", () => {
  const s = "I was diagnosed with asthma last year";
  assert.ok(detectSensitiveCategory(s));
  assert.ok(checkMemoryContent(s, "auto"));
  assert.equal(checkMemoryContent(s, "explicit"), null, "explicit request is allowed");
  assert.equal(checkMemoryContent(s, "manual"), null);
});

test("save → dedupe/update instead of duplicating", () => {
  const m = svc();
  const a = m.save({ content: "Studies for the HSC exam in 2027", category: "education", source: "auto" });
  assert.equal(a.action, "added");
  const b = m.save({ content: "Is studying for the HSC exam in 2027", category: "education", source: "auto" });
  assert.equal(b.action, "updated");
  assert.equal(b.memory.id, a.memory.id);
  assert.equal(m.count(), 1);
  const c = m.save({ content: "Prefers explanations with diagrams", category: "preferences", source: "explicit" });
  assert.equal(c.action, "added");
  assert.equal(m.count(), 2);
});

test("validation: empty, too long, unknown category falls back, capacity", () => {
  const m = svc(2);
  assert.throws(() => m.save({ content: "   ", source: "manual" }), (e) => e instanceof AppError && e.code === "validation");
  assert.throws(() => m.save({ content: "x".repeat(501), source: "manual" }), (e) => e instanceof AppError && e.code === "validation");
  assert.equal(m.save({ content: "Likes tea", category: "nonsense", source: "manual" }).memory.category, "context");
  m.save({ content: "Lives in Dhaka", category: "personal", source: "manual" });
  assert.throws(() => m.save({ content: "Plays chess regularly online", source: "manual" }), /full/);
});

test("sensitive_blocked carries the right code", () => {
  const m = svc();
  assert.throws(() => m.save({ content: "my password is abc12345", source: "manual" }), (e) => e instanceof AppError && e.code === "sensitive_blocked");
  assert.equal(m.count(), 0);
});

test("forget by query: unique match deleted, ambiguous refused", () => {
  const m = svc();
  m.save({ content: "Favourite subject is physics", category: "interests", source: "manual" });
  m.save({ content: "Favourite colour is green", category: "preferences", source: "manual" });
  m.save({ content: "Favourite food is biryani", category: "preferences", source: "manual" });
  m.save({ content: "Favourite game is chess", category: "interests", source: "manual" });
  const amb = m.forget({ query: "favourite" });
  assert.equal(amb.deleted.length, 0);
  assert.equal(amb.ambiguous.length, 4);
  const one = m.forget({ query: "physics" });
  assert.equal(one.deleted.length, 1);
  assert.equal(m.count(), 3);
  assert.deepEqual(m.forget({ query: "nonexistent thing" }), { deleted: [], ambiguous: [] });
});

test("update re-validates content", () => {
  const m = svc();
  const { memory } = m.save({ content: "Likes algebra", source: "manual" });
  assert.throws(() => m.update(memory.id, { content: "password is secret123" }), (e) => e instanceof AppError && e.code === "sensitive_blocked");
  assert.equal(m.update(memory.id, { content: "Likes algebra and geometry", category: "interests" })!.category, "interests");
  assert.equal(m.update("missing", { content: "x y z" }), null);
});

test("retrieve: small stores in full; large stores prefer relevant items and mark last use", () => {
  const m = svc();
  for (let i = 0; i < 30; i++) m.save({ content: `Unrelated fact number ${i} about gardening topic${i}`, category: "interests", source: "manual" });
  m.save({ content: "Is preparing for the physics olympiad", category: "projects", source: "manual" });
  const picked = m.retrieve("help me with olympiad physics problems", 8);
  assert.equal(picked.length, 8);
  assert.ok(picked.some((x) => x.content.includes("olympiad")));
  assert.ok(m.get(picked[0]!.id)!.lastUsedAt, "lastUsedAt recorded");
});
