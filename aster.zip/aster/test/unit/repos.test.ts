import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { openDb } from "../../server/db.ts";
import { createConversationRepo } from "../../server/repo/conversations.ts";
import { createAttachmentRepo, createMessageRepo } from "../../server/repo/messages.ts";
import { createMemoryRepo } from "../../server/repo/memories.ts";
import { createSettingsRepo, validateSettingsPatch } from "../../server/repo/settings.ts";
import { AppError } from "../../server/errors.ts";

function setup() {
  const db = openDb(":memory:");
  return { db, conv: createConversationRepo(db), msg: createMessageRepo(db), att: createAttachmentRepo(db), mem: createMemoryRepo(db), set: createSettingsRepo(db) };
}

test("conversations: create, rename, archive, list ordering, delete cascades", () => {
  const { conv, msg, att, db } = setup();
  const a = conv.create({ title: "First", mode: "math" });
  const b = conv.create();
  assert.equal(a.titleSource, "user");
  assert.equal(b.title, "New conversation");
  assert.equal(b.titleSource, "default");
  msg.insert({ conversationId: a.id, role: "user", content: "hello" });
  const m2 = msg.insert({ conversationId: a.id, role: "assistant", content: "hi" });
  assert.equal(msg.list(a.id).map((m) => m.role).join(), "user,assistant");
  const up = att.create({ name: "x.txt", kind: "text", mime: "text/plain", data: new TextEncoder().encode("abc") });
  att.attach([up.id], m2.id);
  conv.touch(a.id);
  assert.equal(conv.list({ archived: false, limit: 10, offset: 0 }).conversations[0]!.id, a.id, "most recent activity first");
  conv.update(b.id, { archived: true });
  assert.equal(conv.list({ archived: true, limit: 10, offset: 0 }).conversations.length, 1);
  assert.equal(conv.list({ archived: false, limit: 10, offset: 0 }).conversations.length, 1);
  assert.ok(conv.delete(a.id));
  assert.equal((db.prepare("SELECT COUNT(*) AS n FROM messages").get() as { n: number }).n, 0, "messages cascade");
  assert.equal(att.count(), 0, "attachments cascade");
});

test("message seq increments, deleteFromSeq truncates, recoverStreaming marks stopped", () => {
  const { conv, msg } = setup();
  const c = conv.create();
  const m1 = msg.insert({ conversationId: c.id, role: "user", content: "q1" });
  const m2 = msg.insert({ conversationId: c.id, role: "assistant", content: "partial", status: "streaming" });
  msg.insert({ conversationId: c.id, role: "user", content: "q2" });
  assert.equal(msg.seqOf(m1.id), 1);
  assert.equal(msg.seqOf(m2.id), 2);
  assert.equal(msg.recoverStreaming(), 1);
  assert.equal(msg.get(m2.id)!.status, "stopped");
  assert.equal(msg.deleteFromSeq(c.id, 2), 2);
  assert.equal(msg.countIn(c.id), 1);
});

test("full-text search finds message bodies with escaped <mark> snippets, plus titles", () => {
  const { conv, msg } = setup();
  const a = conv.create({ title: "Chemistry notes" });
  const b = conv.create();
  msg.insert({ conversationId: b.id, role: "user", content: "Explain the quadratic formula <script>alert(1)</script> please" });
  const byBody = conv.list({ archived: false, q: "quadratic", limit: 10, offset: 0 }).conversations;
  assert.equal(byBody.length, 1);
  assert.equal(byBody[0]!.id, b.id);
  assert.match(byBody[0]!.snippet!, /<mark>quadratic<\/mark>/i);
  assert.ok(!byBody[0]!.snippet!.includes("<script>"), "snippet HTML-escaped");
  const byTitle = conv.list({ archived: false, q: "chem", limit: 10, offset: 0 }).conversations;
  assert.equal(byTitle[0]!.id, a.id);
  assert.match(byTitle[0]!.snippet!, /<mark>Chem<\/mark>istry/);
  assert.equal(conv.list({ archived: false, q: "nonexistentword", limit: 10, offset: 0 }).conversations.length, 0);
  // hostile FTS syntax must not throw
  assert.doesNotThrow(() => conv.list({ archived: false, q: `"" OR * NEAR( ) -- ' ;`, limit: 10, offset: 0 }));
  // search index follows edits and deletes
  const m = msg.list(b.id)[0]!;
  msg.update(m.id, { content: "now about photosynthesis" });
  assert.equal(conv.list({ archived: false, q: "quadratic", limit: 10, offset: 0 }).conversations.length, 0);
  assert.equal(conv.list({ archived: false, q: "photosynthesis", limit: 10, offset: 0 }).conversations.length, 1);
});

test("attachments: only unattached uploads can be deleted; bytes round-trip", () => {
  const { conv, msg, att } = setup();
  const c = conv.create();
  const m = msg.insert({ conversationId: c.id, role: "user", content: "x" });
  const bytes = new Uint8Array([1, 2, 3, 250]);
  const a = att.create({ name: "n.png", kind: "image", mime: "image/png", data: bytes });
  assert.deepEqual([...att.row(a.id)!.data], [1, 2, 3, 250]);
  att.attach([a.id], m.id);
  assert.equal(att.deleteUnattached(a.id), false);
  assert.equal(att.isUnattached(a.id), false);
  assert.equal(msg.get(m.id)!.attachments[0]!.url, `/api/attachments/${a.id}`);
});

test("settings: defaults, partial update, strict validation", () => {
  const { set } = setup();
  assert.equal(set.get().responseStyle, "balanced");
  assert.equal(set.update(validateSettingsPatch({ theme: "dark", autoMemory: false })).theme, "dark");
  assert.equal(set.get().autoMemory, false);
  for (const bad of [{ theme: "neon" }, { autoMemory: "yes" }, { model: "bad model!" }, { customInstructions: "x".repeat(2001) }, { nope: 1 }, []]) {
    assert.throws(() => validateSettingsPatch(bad), (e) => e instanceof AppError && e.code === "validation", JSON.stringify(bad));
  }
  assert.equal(validateSettingsPatch({ model: "" }).model, null);
});

test("DATA SURVIVES RESTART: reopening the database file keeps conversations, messages, memories, settings", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "aster-persist-"));
  const file = path.join(dir, "aster.db");
  try {
    const a = openDb(file);
    const c = createConversationRepo(a).create({ title: "Persist me" });
    createMessageRepo(a).insert({ conversationId: c.id, role: "user", content: "remember this" });
    createMemoryRepo(a).create({ category: "goals" as never, content: "Wants to learn linear algebra", source: "explicit" });
    createSettingsRepo(a).update({ theme: "dark" });
    a.close();

    const b = openDb(file);
    assert.equal(createConversationRepo(b).get(c.id)!.title, "Persist me");
    assert.equal(createMessageRepo(b).list(c.id)[0]!.content, "remember this");
    assert.equal(createMemoryRepo(b).list()[0]!.content, "Wants to learn linear algebra");
    assert.equal(createSettingsRepo(b).get().theme, "dark");
    assert.equal((b.prepare("PRAGMA user_version").get() as { user_version: number }).user_version, 1);
    b.close();
    assert.equal((fs.statSync(file).mode & 0o077), 0, "database file is private (0600)");
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
