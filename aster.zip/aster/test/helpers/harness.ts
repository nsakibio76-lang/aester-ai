// Test harness: boots the REAL Aster app (real SQLite file, real HTTP server, real Anthropic provider code)
// against the mock Anthropic wire-protocol server.

import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createApp } from "../../server/app.ts";
import type { App } from "../../server/app.ts";
import { loadConfig } from "../../server/config.ts";
import { setQuiet } from "../../server/log.ts";
import { startMockAnthropic } from "./mock-anthropic.ts";
import type { MockAnthropic } from "./mock-anthropic.ts";

setQuiet(true);

export interface SseEvent { event: string; data: any }

export interface TestApp {
  app: App;
  base: string;
  mock: MockAnthropic;
  dataDir: string;
  /** JSON request helper → { status, body, headers } */
  api(method: string, path: string, body?: unknown, headers?: Record<string, string>): Promise<{ status: number; body: any; headers: Headers }>;
  /** POST /api/chat and parse the whole SSE stream. Non-200 → { status, error }. */
  chat(body: Record<string, unknown>, headers?: Record<string, string>): Promise<{ status: number; events: SseEvent[]; error?: any; text: string; of(name: string): SseEvent[] }>;
  upload(bytes: Uint8Array, mime: string, name: string): Promise<{ status: number; body: any }>;
  restart(): Promise<void>;
  stop(): Promise<void>;
}

export function parseSse(raw: string): SseEvent[] {
  const out: SseEvent[] = [];
  for (const block of raw.replace(/\r\n/g, "\n").split("\n\n")) {
    let event = "message"; const data: string[] = [];
    for (const line of block.split("\n")) {
      if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) data.push(line.slice(5).trim());
    }
    if (data.length) out.push({ event, data: JSON.parse(data.join("\n")) });
  }
  return out;
}

export async function startTestApp(env: Record<string, string> = {}, opts: { dataDir?: string; mock?: MockAnthropic } = {}): Promise<TestApp> {
  const mock = opts.mock ?? await startMockAnthropic({ apiKey: "test-key" });
  const dataDir = opts.dataDir ?? fs.mkdtempSync(path.join(os.tmpdir(), "aster-test-"));
  const mkConfig = () => loadConfig({
    ASTER_PORT: "0", ASTER_HOST: "127.0.0.1", ASTER_DATA_DIR: dataDir,
    ANTHROPIC_API_KEY: "test-key", ASTER_ANTHROPIC_BASE_URL: mock.url,
    ASTER_RETRY_BASE_MS: "0", ASTER_MAX_RETRIES: "2",
    ...env,
  }, process.cwd());

  let app = createApp(mkConfig());
  let { url: base } = await app.listen();

  const t: TestApp = {
    app, base, mock, dataDir,
    async api(method, p, body, headers = {}) {
      const res = await fetch(t.base + p, {
        method,
        headers: { ...(body !== undefined ? { "content-type": "application/json" } : {}), ...headers },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
      const text = await res.text();
      let parsed: any = text;
      try { parsed = text ? JSON.parse(text) : null; } catch { /* not json */ }
      return { status: res.status, body: parsed, headers: res.headers };
    },
    async chat(body, headers = {}) {
      const res = await fetch(t.base + "/api/chat", { method: "POST", headers: { "content-type": "application/json", ...headers }, body: JSON.stringify(body) });
      if (!res.ok) return { status: res.status, events: [], error: await res.json().catch(() => null), text: "", of: () => [] };
      const events = parseSse(await res.text());
      const text = events.filter((e) => e.event === "delta").map((e) => e.data.text).join("");
      return { status: res.status, events, text, of: (n: string) => events.filter((e) => e.event === n) };
    },
    async upload(bytes, mime, name) {
      const res = await fetch(t.base + "/api/uploads", { method: "POST", headers: { "content-type": mime, "x-file-name": encodeURIComponent(name) }, body: bytes });
      const text = await res.text();
      let parsed: any = text; try { parsed = JSON.parse(text); } catch { /* ignore */ }
      return { status: res.status, body: parsed };
    },
    async restart() {
      await app.close();
      app = createApp(mkConfig());
      t.app = app;
      t.base = (await app.listen()).url;
    },
    async stop() {
      await t.app.close();
      if (!opts.mock) await mock.close();
      if (!opts.dataDir) fs.rmSync(dataDir, { recursive: true, force: true });
    },
  };
  return t;
}

export const PNG_1x1 = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==", "base64");
