// A TEST FIXTURE that imitates the Anthropic Messages API wire protocol (POST /v1/messages, SSE streaming,
// tool_use blocks, error statuses). Aster's real provider code talks to it over HTTP, so streaming, tool loops,
// retries and error mapping are exercised for real. It is never used by the production app.
//
// Behaviour is chosen by trigger words in the latest user message:
//   math/solve → worked quadratic · code · quiz · flashcards · remember X → memory_save tool call · forget X ·
//   "what do you remember" → memory_list · private → conversation_memory(false) · calc EXPR → calculate tool ·
//   slow → long slow stream · error → 429 · flaky → one 529 then OK · fatal → 401 · toolong → context error ·
//   midstream → text then stream error · refuse → stop_reason refusal.

import http from "node:http";
import type { AddressInfo } from "node:net";

export interface RecordedRequest { headers: http.IncomingHttpHeaders; body: any }
export interface MockAnthropic {
  url: string;
  port: number;
  requests: RecordedRequest[];
  close(): Promise<void>;
}

const MATH = `### Understanding the problem
We need to solve the quadratic equation $x^2 - 5x + 6 = 0$ (it costs \\$5 to print, but that is just a dollar sign).

### Given
The coefficients are $a = 1$, $b = -5$, $c = 6$.

### Concepts and method
Factorisation: look for two numbers with product $6$ and sum $-5$.

### Solution
1. Write the middle term using those numbers:
$$x^2 - 5x + 6 = (x-2)(x-3)$$
This works because $(-2)(-3) = 6$ and $(-2)+(-3) = -5$.
2. Apply the zero-product property: $x-2=0$ or $x-3=0$.

### Check
For $x = 2$: $4 - 10 + 6 = 0$ ✓. For $x = 3$: $9 - 15 + 6 = 0$ ✓.

### Final answer
$$x = 2 \\quad \\text{or} \\quad x = 3$$`;

const CODE = "Here is a small example:\n\n```python\ndef fib(n: int) -> int:\n    a, b = 0, 1\n    for _ in range(n):\n        a, b = b, a + b\n    return a\n\nprint(fib(10))  # 55\n```\n\nIt runs in linear time.";
const QUIZ = 'Here is a quick quiz:\n\n```quiz\n{"title":"Quadratics","questions":[{"q":"What are the roots of $x^2-5x+6=0$?","options":["1 and 6","2 and 3","-2 and -3","5 and 6"],"answer":1,"explanation":"$(x-2)(x-3)=0$."},{"q":"The discriminant of $x^2+2x+1$ is…","options":["0","1","4","-4"],"answer":0,"explanation":"$b^2-4ac=4-4=0$."}]}\n```';
const CARDS = 'Flashcards:\n\n```flashcards\n{"title":"Cell biology","cards":[{"front":"Powerhouse of the cell","back":"The mitochondrion"},{"front":"Where is DNA stored?","back":"The nucleus"}]}\n```';

type Plan =
  | { kind: "http-error"; status: number; type: string; message: string; headers?: Record<string, string> }
  | { kind: "stream"; text: string; tool?: { name: string; input: Record<string, unknown> }; stop?: string; delayMs?: number; failAfter?: boolean };

const lastUserText = (body: any): { text: string; hasImage: boolean; toolResult: string | null } => {
  const msgs: any[] = body.messages ?? [];
  const m = msgs[msgs.length - 1];
  if (!m || m.role !== "user") return { text: "", hasImage: false, toolResult: null };
  let text = "", hasImage = false, toolResult: string | null = null;
  for (const b of m.content ?? []) {
    if (b.type === "text") text += (text ? "\n" : "") + b.text;
    else if (b.type === "image") hasImage = true;
    else if (b.type === "tool_result") toolResult = typeof b.content === "string" ? b.content : JSON.stringify(b.content);
  }
  return { text, hasImage, toolResult };
};

export async function startMockAnthropic(opts: { apiKey?: string; chunkDelayMs?: number } = {}): Promise<MockAnthropic> {
  const apiKey = opts.apiKey ?? "test-key";
  const requests: RecordedRequest[] = [];
  const flakySeen = new Set<string>();

  const server = http.createServer((req, res) => {
    const chunks: Buffer[] = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", async () => {
      if (req.method !== "POST" || req.url !== "/v1/messages") { res.writeHead(404); res.end(); return; }
      let body: any;
      try { body = JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch { res.writeHead(400); res.end("{}"); return; }
      requests.push({ headers: req.headers, body });
      const jsonErr = (status: number, type: string, message: string, headers: Record<string, string> = {}) => {
        res.writeHead(status, { "content-type": "application/json", ...headers });
        res.end(JSON.stringify({ type: "error", error: { type, message } }));
      };
      if (req.headers["x-api-key"] !== apiKey) return jsonErr(401, "authentication_error", "invalid x-api-key");

      const sys = (body.system ?? []).map((s: any) => s.text).join("\n");
      const { text, hasImage, toolResult } = lastUserText(body);
      const t = text.toLowerCase();
      let plan: Plan;

      if (sys.includes("You write short conversation titles")) plan = { kind: "stream", text: "Mock Conversation Title" };
      else if (toolResult !== null) plan = { kind: "stream", text: `Done. Tool said: ${toolResult.slice(0, 200)}` };
      else if (/\bfatal\b/.test(t)) plan = { kind: "http-error", status: 401, type: "authentication_error", message: "invalid x-api-key" };
      else if (/\btoolong\b/.test(t)) plan = { kind: "http-error", status: 400, type: "invalid_request_error", message: "prompt is too long: 250000 tokens > 200000 maximum" };
      else if (/\berror\b/.test(t)) plan = { kind: "http-error", status: 429, type: "rate_limit_error", message: "rate limited", headers: { "retry-after": "0" } };
      else if (/\bflaky\b/.test(t) && !flakySeen.has(t)) { flakySeen.add(t); plan = { kind: "http-error", status: 529, type: "overloaded_error", message: "Overloaded" }; }
      else if (/\bmidstream\b/.test(t)) plan = { kind: "stream", text: "Partial answer before failure…", failAfter: true };
      else if (/\brefuse\b/.test(t)) plan = { kind: "stream", text: "", stop: "refusal" };
      else if (/\bslow\b/.test(t)) plan = { kind: "stream", text: "This is a long, slow answer. ".repeat(40), delayMs: 120 };
      else if (/what do you remember/.test(t)) plan = { kind: "stream", text: "Let me check.", tool: { name: "memory_list", input: {} } };
      else if (/\bremember\b/.test(t)) {
        const m = /remember(?: that)?\s+(.*)/is.exec(text);
        plan = { kind: "stream", text: "Let me save that.", tool: { name: "memory_save", input: { content: (m?.[1] ?? text).trim(), category: "context", explicit: !/\bauto\b/.test(t) } } };
      } else if (/\bforget\b/.test(t)) {
        const m = /forget(?: that)?\s+(.*)/is.exec(text);
        plan = { kind: "stream", text: "", tool: { name: "memory_forget", input: { query: (m?.[1] ?? "").trim() } } };
      } else if (/\bprivate\b/.test(t)) plan = { kind: "stream", text: "", tool: { name: "conversation_memory", input: { enabled: false } } };
      else if (/\bcalc\b/.test(t)) plan = { kind: "stream", text: "", tool: { name: "calculate", input: { expression: (/calc\s+(.*)/is.exec(text)?.[1] ?? "1+1").trim() } } };
      else if (hasImage) plan = { kind: "stream", text: "I can see an attached image. (mock) The visible question reads: $x^2 = 9$, so $x = \\pm 3$." };
      else if (/\bmath\b|\bsolve\b/.test(t)) plan = { kind: "stream", text: MATH };
      else if (/\bcode\b/.test(t)) plan = { kind: "stream", text: CODE };
      else if (/\bquiz\b/.test(t)) plan = { kind: "stream", text: QUIZ };
      else if (/\bflashcards\b/.test(t)) plan = { kind: "stream", text: CARDS };
      else plan = { kind: "stream", text: `This is a mock reply to: "${text.slice(0, 80)}"` };

      if (plan.kind === "http-error") return jsonErr(plan.status, plan.type, plan.message, plan.headers);

      res.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-cache" });
      const send = (event: string, data: unknown) => { if (!res.destroyed) res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); };
      const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
      const delay = plan.delayMs ?? opts.chunkDelayMs ?? 4;
      send("message_start", { type: "message_start", message: { id: "msg_mock", type: "message", role: "assistant", model: body.model, content: [], usage: { input_tokens: 42, output_tokens: 1 } } });
      send("ping", { type: "ping" });
      let idx = 0;
      if (plan.text) {
        send("content_block_start", { type: "content_block_start", index: idx, content_block: { type: "text", text: "" } });
        for (let i = 0; i < plan.text.length; i += 14) {
          if (res.destroyed) return;
          send("content_block_delta", { type: "content_block_delta", index: idx, delta: { type: "text_delta", text: plan.text.slice(i, i + 14) } });
          if (delay) await sleep(delay);
        }
        send("content_block_stop", { type: "content_block_stop", index: idx });
        idx++;
      }
      if (plan.failAfter) { send("error", { type: "error", error: { type: "overloaded_error", message: "Overloaded" } }); res.end(); return; }
      if (plan.tool) {
        send("content_block_start", { type: "content_block_start", index: idx, content_block: { type: "tool_use", id: "toolu_mock" + requests.length, name: plan.tool.name, input: {} } });
        const json = JSON.stringify(plan.tool.input);
        for (let i = 0; i < json.length; i += 9) send("content_block_delta", { type: "content_block_delta", index: idx, delta: { type: "input_json_delta", partial_json: json.slice(i, i + 9) } });
        send("content_block_stop", { type: "content_block_stop", index: idx });
      }
      send("message_delta", { type: "message_delta", delta: { stop_reason: plan.stop ?? (plan.tool ? "tool_use" : "end_turn") }, usage: { output_tokens: Math.ceil(plan.text.length / 4) + 5 } });
      send("message_stop", { type: "message_stop" });
      res.end();
    });
  });

  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const port = (server.address() as AddressInfo).port;
  return {
    url: `http://127.0.0.1:${port}`, port, requests,
    close: () => new Promise((resolve) => { server.closeAllConnections(); server.close(() => resolve()); }),
  };
}
